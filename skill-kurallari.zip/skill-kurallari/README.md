# Skill ve Beceri Kuralları

Bu depo, Claude'da kullanılan skill (beceri) ve kural dosyalarının tamamını iki biçimde içerir.

## Klasörler

- **`skills/`**: Her skill'in özgün klasörü. Ana kural dosyası `SKILL.md`, varsa yardımcı md dosyaları, betikler, şablonlar ve fontlar aynı klasördedir.
- **`birlesik/`**: Her skill için tek bir md dosyası. Klasördeki tüm md dosyaları (SKILL.md ve yardımcı md'ler) sırasıyla birleştirilmiştir. Dizin için `birlesik/000-ICINDEKILER.md` dosyasına bakılabilir.
- **`00-ICINDEKILER.md`**: Skill'lerin açıklamalı listesi.

## Kullanım

Tek bir skill'i Claude'a yeniden yüklemek için `skills/` altındaki ilgili klasör olduğu gibi kullanılır. Okumak, aramak ya da başka bir araca aktarmak için `birlesik/` altındaki tek md dosyaları daha pratiktir.
