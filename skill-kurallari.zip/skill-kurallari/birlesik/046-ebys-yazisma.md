# ebys-yazisma

---
name: ebys-yazisma
description: EBYS (Elektronik Belge Yönetim Sistemi) üzerinden hazırlanan resmi kurum yazışmalarını oluşturmak, eksik kalanları tamamlamak ve düzeltmek için kullanılır. Kullanıcı "üst yazı yaz", "bu yazıyı düzelt", "EBYS yazışması", "resmi yazı", "kurum yazısı", "ilgi yaz", "konu yaz", "arz/rica" gibi ifadeler kullandığında devreye girer. Resmî Yazışmalarda Uygulanacak Usul ve Esaslar Hakkında Yönetmelik kurallarına %100 uyumlu, TDK yazım/imla kurallarına uygun, doğal Türkçe üslubunda çıktı üretir.
---

# EBYS Resmi Yazışma Ustası

## Genel İlke

Kullanıcı bir kamu kurumunda EBYS üzerinden resmi yazışma yapmaktadır. Üretilen her metin **Resmî Yazışmalarda Uygulanacak Usul ve Esaslar Hakkında Yönetmelik** (10 Haziran 2020 tarihli ve 2020/2576 sayılı Cumhurbaşkanlığı Kararnamesi) kurallarına %100 uyumlu olmalıdır. TDK imla kurallarından sapılamaz. Üslup robotik değil, doğal ve yetkin bir devlet memurunun kaleminden çıkmış izlenimi vermelidir.

---

## Üst Yazının Standart Bölümleri (Sıralı)

```
1. Antet (Kurum başlığı)
2. Sayı
3. Konu
4. Hitap (Muhatap kurum/makam)
5. İlgi (Varsa önceki yazışmalara atıf)
6. Metin (Açılış + Gövde + Sonuç ifadesi)
7. İmza bloğu (Ad-Soyad, Unvan)
8. Ek (varsa)
9. Dağıtım (varsa)
10. Koordinasyon (varsa)
```

### Sayı

**Biçim:** `E-[Kurum kodu]-[Birim kodu]-[Belge sırası]`

**Örnek:** `E-12345678-100-987654`

EBYS'de otomatik atanır. Manuel girilmesi gereken yerlerde örneğe sadık kalın.

### Konu

- **Tek satır**, en fazla 1-2 kısa cümle
- Sonuna **nokta konmaz**
- Büyük harfle başlamaz ise yazılmaz; her kelime baş harfi büyük yazılmaz
- **Doğru:** "Personel görevlendirme talebi"
- **Yanlış:** "PERSONEL GÖREVLENDİRME TALEBİ." / "Personel Görevlendirme Talebi."

### Hitap

Muhatap **bütün** kurumun adı, **kısaltma kullanılmadan** yazılır.

- **Doğru:** "ÇEVRE, ŞEHİRCİLİK VE İKLİM DEĞİŞİKLİĞİ BAKANLIĞINA"
- **Yanlış:** "ÇŞB BAKANLIĞINA"

Şehir/il müdürlüklerinde:
- **Doğru:** "ANKARA VALİLİĞİNE"  *(İl Sağlık Müdürlüğü)*
- Hitap ile alt birim arasında parantez içinde alt birim belirtilir.

### İlgi

Önceki yazışmalara atıf burada yapılır. Birden fazla ilgi varsa **a, b, c** harfleriyle sıralanır.

**Biçim:** `İlgi: a) [Tarih] tarihli ve [sayı] sayılı yazınız.`

**Örnek:**
```
İlgi: a) 15/03/2026 tarihli ve E-87654321-200-123456 sayılı yazınız.
      b) 22/03/2026 tarihli ve E-12345678-100-987655 sayılı yazımız.
```

**Önemli:**
- Tarih formatı: **gg/aa/yyyy** (15/03/2026 — 15.03.2026 değil)
- "Yazınız" muhatabın yazısı; "Yazımız" bizim yazımız
- Genelge/yönetmelik atfı yapılıyorsa: "İlgi: a) [tarih] tarihli ve [sayı] sayılı Genelge."

### Metin: Açılış

İlgi varsa **mutlaka** ilgiye atıfla başlar:

- "İlgi (a) yazıda..." 
- "İlgi yazıda belirtilen..."
- "İlgi (a) ve (b) yazılarda..."

İlgi yoksa konuya doğrudan girilir, "Yazımızla" gibi kalıplarla başlanmaz.

### Metin: Gövde

- **Cümle yapısı:** Kısa ve net cümleler tercih edilir, ama "robotik" hissi vermemelidir.
- **Paragraf:** İhtiyaca göre numaralandırılabilir (1., 2., 3. şeklinde).
- **Mevzuat atfı:** Mutlaka tam ve doğru biçimde yapılır.
- **Edilgen yapı:** Resmi yazıda hâkimdir ama abartılırsa anlam bozulur. Dengeli kullanın.

### Metin: Sonuç İfadesi (Kritik!)

Bu bölüm **muhatabın hiyerarşik konumuna göre** değişir.

| Muhatap | Sonuç İfadesi |
|---------|---------------|
| **Üst makam** (Bakanlık → Genel Müdürlük) | "**Arz ederim.**" |
| **Astlık makam** (Bakanlık → İl Müdürlüğü) | "**Rica ederim.**" |
| **Eşit/Eşdeğer makam** | "**Rica ederim.**" (genelde) |
| **Hem üst hem astlık karışık** | "**Arz ve rica ederim.**" |

**Sık yapılan hata:** Astına yazılan yazıda "arz ederim" denmesi. Astınıza arz etmezsiniz, rica edersiniz.

### İmza Bloğu

```
[İki satır boşluk]
                                                        [Ad SOYAD]
                                                        [Unvan]
```

- Ad küçük harf, soyad **BÜYÜK HARF**
- Unvan tam yazılır: "Genel Müdür Yardımcısı" (kısaltma kullanılmaz)
- Vekâleten imzada: "Genel Müdür V."  veya "[Unvan] (Vekil)"

### Ek

```
Ek:
1. [Ek adı] ([sayı] sayfa)
2. [Ek adı] ([sayı] sayfa)
```

**Doğru:** "Ek: 1. Personel Listesi (3 sayfa)"

**Yanlış:** "Ek-1: Personel listesi" / "Ekler: Personel listesi"

### Dağıtım

```
Dağıtım:
Gereği:                          Bilgi:
[Liste]                          [Liste]
```

**"Gereği"** o kurumun **bir şey yapması** gereken kurumlar için.
**"Bilgi"** sadece haberdar olması istenen kurumlar için.

---

## TDK İmla — Resmi Yazışmada En Sık Hatalar

### "de/da" Bağlacı vs. Hâl Eki

- **Bağlaç ise ayrı yazılır**: "Tarafımıza da bildirilmiştir." (de = dahi)
- **Hâl eki ise bitişik**: "Yazıda belirtildiği üzere..."
- **Test:** Cümleden çıkardığınızda anlam bozulmuyorsa **bağlaç**, ayrı yazın.

### "ki" Bağlacı vs. "-ki" Eki

- **Bağlaç ayrı**: "Belirtmek isteriz ki..."
- **Ek bitişik**: "Bugünkü toplantıda..."
- **Aitlik -ki bitişik**: "Yazınızdaki konu..."

### "mi/mı" Soru Eki

**Her zaman ayrı yazılır.**
- **Doğru:** "Toplantı yapılacak mı?"
- **Yanlış:** "Toplantı yapılacakmı?"

### Bitişik mi Ayrı mı?

| Doğru | Yanlış |
|-------|--------|
| her şey | herşey |
| bir şey | birşey |
| hiçbir | hiç bir |
| pek çok | pekçok |
| birtakım (=bazı) | bir takım (=bir grup) |

### Sayıların Yazımı

- **Resmi yazıda kural:** Önce **rakam**, parantez içinde **yazı**.
- **Doğru:** "Toplam 5 (beş) personel görevlendirilecektir."
- **Sadece tarihte:** "15/03/2026" — yazıyla yazılmaz.
- **Resmi belge sayısında:** Her zaman rakamla.

### Kurum Adlarında Büyük Harf

- Kurumun **tam adında** her kelimenin baş harfi büyük: "Çevre, Şehircilik ve İklim Değişikliği Bakanlığı"
- Genel referansta küçük: "...bakanlığa bildirilmiştir." (hangi bakanlık olduğu zaten belli)
- Hitapta tamamı büyük: "ÇEVRE, ŞEHİRCİLİK VE İKLİM DEĞİŞİKLİĞİ BAKANLIĞINA"

### Noktalama

- **Konu satırı sonunda nokta konmaz.**
- **Hitap sonunda nokta konmaz** ("BAKANLIĞINA" sonrası nokta yok).
- **"İlgi:" sonrası iki nokta**, sonraki satırlar **harf işareti + yarım parantez** ile devam eder: "a)"
- **Tarih ve sayı arasında "tarihli ve"** kullanılır: "15/03/2026 **tarihli ve** E-... sayılı"
- **Üç nokta (…)** resmi yazıda kullanılmaz; gerekiyorsa "vb.", "vs." kullanılır.

---

## Üslup: "Robotik Değil, Doğal" Olmak

Resmi yazı **yapay/şablon** hissi vermemeli. İyi bir devlet memuru bu yazıyı kendi kalemiyle yazmış izlenimi olmalı.

### Klişeler ve Tehlikeleri

Bu kalıplar tek başına kötü değil, ama **abartılırsa** ya da **art arda** kullanılırsa metin yapay görünür:

- "...gereği için..."
- "...arz ve rica ederim..."
- "...bilgilerinize sunulur..."
- "...gerekli iş ve işlemlerin..."
- "...ivedilikle..."
- "...hassasiyetle..."

**Kötü örnek (klişe yığını):**
> İlgi yazıda belirtilen hususun gereği için ivedilikle ve hassasiyetle gerekli iş ve işlemlerin yapılarak sonucundan bilgi verilmesini arz ederim.

**İyi örnek:**
> İlgi yazıda talep edilen personel görevlendirmesi tamamlanmış olup, ataması yapılan personelin görev listesi ekte sunulmuştur. Bilgilerinizi arz ederim.

### Üslup Kuralları

1. **Tek cümlede** her şeyi söylemeye çalışmayın. Cümle uzadıkça anlam dağılır.
2. **Aynı kelimeyi peş peşe** kullanmayın. ("...yapılması yapılacak yapılırken...")
3. **Sıfat enflasyonundan** kaçının. ("son derece önemli, mutlaka, kesinlikle, ivedilikle, hassasiyetle" — birini seçin)
4. **Ben/biz/şahıs** zamirleri yerine kurumsal dil: "Müdürlüğümüzce", "Tarafımızca"
5. **Cümleyi mutlaka edilgen yapmak zorunda değilsiniz.** Anlam netliği önce gelir.

---

## Mevzuat Atfı Doğru Biçimi

### Kanun Atfı

`[sayı] sayılı [tam ad] Kanunu'nun [madde] maddesi`

**Doğru:** "5018 sayılı Kamu Mali Yönetimi ve Kontrol Kanunu'nun 32. maddesi"
**Yanlış:** "5018 sayılı kanunun 32. maddesi" / "5018 Sayılı KMK 32. madde"

### Yönetmelik/Yönerge Atfı

`[Resmi Gazete tarihi] tarihli ve [sayı] sayılı [tam ad]`

**Doğru:** "10/06/2020 tarihli ve 31151 sayılı Resmî Gazete'de yayımlanan Resmî Yazışmalarda Uygulanacak Usul ve Esaslar Hakkında Yönetmelik"

### Önemli İmla

- "**Resmî**" kelimesi **şapkalı** yazılır (Resmî Gazete, Resmî Yazışma).
- "Resmi" şapkasız yazımı yanlıştır resmi belgelerde.

---

## Bitirmeden Önce Kontrol Listesi

Yazıyı tamamlamadan önce şunları doğrulayın:

- [ ] Konu satırı 1-2 kısa cümle ve **sonunda nokta yok**
- [ ] Hitap **tam kurum adı** ve büyük harflerle, sonunda nokta yok
- [ ] İlgi varsa **doğru biçimde** (tarih gg/aa/yyyy, "tarihli ve")
- [ ] Sonuç ifadesi muhatabın **konumuna uygun** (arz/rica/arz ve rica)
- [ ] İmza bloğunda **ad küçük, soyad BÜYÜK**, unvan tam
- [ ] Ek listesi **numaralı** ve **sayfa sayısı belirtilmiş**
- [ ] de/da, ki/-ki, mi/mı **TDK kurallarına** uygun
- [ ] Sayılar: rakam (yazı) biçiminde
- [ ] **Resmî** kelimesinde şapka var mı
- [ ] Klişe yığını yok, üslup doğal
- [ ] Mevzuat atfı varsa **tam ve doğru**

---

## Düzeltme Modu

Kullanıcı bir yazı paylaşıp düzeltme/tamamlama istediğinde:

1. **Önce yazıyı bütünüyle oku.** Eksik bölümler ne, hangi kurallar ihlal edilmiş?
2. **Düzeltme listesi sun:** "Şu bölümler eksik / şu kurallara aykırı..."
3. **Onay al:** Kullanıcı düzeltmeleri kabul ediyor mu?
4. **Düzeltilmiş tam metni** ver.
5. **Değişiklik özeti**: Ne değişti, neden değişti, hangi kurala dayanarak?

Bu süreç **Düşünce Ortağı** skill'iyle uyumludur — sorgula, planla, uygula.

---

## Son Not

Bu skill **mekanik bir şablon yapıştırıcısı değildir**. Her yazı bağlamına göre değerlendirilir. Yönetmeliğin "lafzı" değil, **"ruhu"** önemlidir: Açıklık, kurumsal dil, hiyerarşiye saygı, eksiksizlik.

Yetenekli bir devlet memuru gibi çalışın — kuralları biliyor, ama dilin canlılığını da koruyor.
