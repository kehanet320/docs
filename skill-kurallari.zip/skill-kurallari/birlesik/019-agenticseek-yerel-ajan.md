# agenticseek-yerel-ajan

---
name: "agenticseek-yerel-ajan"
description: "Tamamen yerel çalışan, web'de gezinen ve kod yazan otonom ajan agenticSeek'i kurma, yapılandırma ve çalıştırma istendiğinde kullanmak için."
---

# agenticSeek Kurulum Rehberi

agenticSeek (Fosowl/agenticSeek), Manus benzeri, yerel çalışan özel bir ajandır. Web'de gezinebilir, kod yazabilir ve dosya sisteminde işlem yapabilir. Yerel modeller kullanıldığında veriler bilgisayardan dışarı çıkmaz. Lisansı GPL-3.0'dır. Hem yerel hem bulut tabanlı model sağlayıcıları desteklenir.

## Ne zaman kullanılır
- Kullanıcı internet ve API ücreti olmadan, kendi bilgisayarında çalışan bir ajan kurmak istediğinde.
- Kurulum, donanım gereksinimi, model sağlayıcı seçimi ya da çalıştırma konusunda yardım istendiğinde.

## Çalışma ilkeleri
1. Proje kullanıcının kendi donanımında çalışır, Claude'un çalışma alanında çalıştırılamaz. Komutları ve kontrol listesini hazırla, kurulumu kullanıcı yapar.
2. Yerel model için güçlü bir ekran kartı gerekir. Donanım gereksinimi tablosunu depodaki README'den oku ve kullanıcının donanımını öğrenmeden çalışacak diye söz verme. Donanım yetersizse bulut tabanlı sağlayıcı seçeneğini, bunun veri gizliliği ve ücret sonuçlarıyla birlikte anlat.
3. Proje geliştirilme aşamasındadır. Kurulum adımlarını vermeden önce güncel README'yi kontrol et (https://github.com/Fosowl/agenticSeek).
4. Ajan dosya sisteminde çalışır. Çalışma klasörünü (work_dir) önemli belgelerden ayrı bir klasör olarak ayarlamasını öner.

## Ön koşullar
- Git, Python ve Docker. Gerekli sürümleri README'den doğrula.
- Docker'ın çalıştığını `docker info` ile kontrol et.

## Kurulum
1. `git clone https://github.com/Fosowl/agenticSeek.git`
2. `cd agenticSeek`
3. `mv .env.example .env`
4. Çalışma klasörünü ve model sağlayıcısını README'deki yönergeye göre ayarla.
5. Servisleri başlat: `./start_services.sh`
6. Bağımlılıkları kurıp (`pip3 install -r requirements.txt`) komut satırı kipinde çalıştır: `python3 cli.py`
7. Web arayüzü için `python3 api.py` çalıştırıp `localhost:3000` adresini aç.

Adaşlık kipinde istem işareti (>>>) görünür, talimatı yazınca ajan göreve en uygun alt ajanı seçer. Kurulum sırasında sorun çıkarsa depodaki sorun kayıtlarına ve README'deki sorun giderme bölümüne bak.
