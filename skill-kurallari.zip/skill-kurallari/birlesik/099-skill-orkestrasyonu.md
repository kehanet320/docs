# skill-orkestrasyonu

---
name: "skill-orkestrasyonu"
description: "Her talepte önce bunu uygula: talebi çözümler, uygun skill'leri doğru sırayla otomatik yükler, çakışmaları çözer ve teslimden önce skill kurallarına uyumu denetler."
---

# Skill Orkestrasyonu (İleri Düzey Skill Kullanımı)

Bu skill, İsmailBEY'in her talebinde hangi skill'in, hangi sırayla ve ne ölçüde kullanılacağını belirleyen üst kuraldır. Amaç; gereken skill'i hiçbir zaman atlamamak, gereksiz skill yükleyip işi yavaşlatmamak ve birden fazla skill çalıştığında birbirine karşı gelmelerini önlemektir. Kullanıcıya "hangi skill'i kullanayım?" diye sorulmaz; seçim sessizce yapılır.

**İş bölümü:** Bu skill her talepte genel kuralları koyar. `skill-yoneticisi` yalnızca çok parçalı veya belirsiz işlerde işi parçalara ayırır. `kurumsal-turkce-yazim` Türkçe metin standardını korur. Çelişki olursa bu skill kazanır.

## 1. Talebi çözümle (yüklemeden önce, 5 soru)

1. **Çıktı ne?** Metin mi, belge mi (Word/PDF), tablo mu, sunum mu, kod mu, tasarım mı, sadece cevap mı?
2. **Konu ne?** Resmî yazışma, konuşma metni, ceza kararı, tutanak, fatura listesi, imza sirküsü, uygulama geliştirme, araştırma…
3. **Dil ve üslup?** Türkçe kurumsal mı, gündelik mi?
4. **Büyüklük?** Tek adımlık mı, çok parçalı mı, hata kaldırmaz mı?
5. **Kullanıcı bir skill adı verdi mi?** Verdiyse o skill tartışmasız önceliklidir.

Sadece sohbet, kısa bilgi sorusu veya basit açıklama ise **hiçbir skill yüklenmez**; doğrudan cevap verilir. Gereksiz yükleme kalite değil gecikme getirir.

## 2. Katmanlı seçim modeli

Skill'ler beş katmanda düşünülür. Her katmandan en fazla gereken kadarı alınır.

| Katman | Görevi | Örnek skill'ler |
|---|---|---|
| **A. Çalışma modu** | İşin nasıl yürütüleceği | `ultrawork` (büyük/riskli iş), `dusunce-ortagi` (önce sorgula-planla), `systematic-debugging` (hata), `skill-yoneticisi` (çok parçalı belirsiz iş) |
| **B. İçerik / alan** | Ne yazılacağı, hangi kurala uyulacağı | `ebys-yazisma`, `tasimali-egitim-ceza-karari`, `resmi-tutanak`, `okul-fatura-listesi`, `sinav-imza-sirkusu`, `kurumsal-turkce-yazim`, `agency-*` bölümleri, `article-writing`, `legal:*` |
| **C. Üslup cilası** | Metnin dili | `turkce-dogallastirici` (Türkçe), `humanizer` (yalnızca İngilizce metin) |
| **D. Biçim / dosya** | Çıktının formatı | `word-ileri`, `word-ileri-ustasi`, `docx`, `excel-temel`, `excel-makro-vba`, `excel-otomasyon-ustasi`, `xlsx`, `powerpoint-ustasi`, `powerpoint-ileri-ustasi`, `pptx`, `pdf-ustasi`, `pdf`, `html-ustasi`, `tasarim-ustasi` |
| **E. Doğrulama** | Teslim öncesi kalite | `verification-before-completion` + aşağıdaki kontrol listesi |

**Yükleme sırası:** A → B → C → D → E. İçerik oturmadan biçim skill'i açılmaz; aksi hâlde şık ama içi zayıf dosya çıkar. Üslup cilası metin dosyaya dökülmeden önce yapılır; böylece dosya yeniden üretilmez.

## 3. Sık kullanılan iş eşleştirmeleri

| Talep | Yüklenecekler (sırasıyla) |
|---|---|
| EBYS üst yazısı yaz / düzelt / tamamla | `ebys-yazisma` → `kurumsal-turkce-yazim` → `turkce-dogallastirici` |
| Taşımalı eğitim ceza kararı | `tasimali-egitim-ceza-karari` → `kurumsal-turkce-yazim` → `turkce-dogallastirici` → `word-ileri`; hesap kodla |
| Tutanak | `resmi-tutanak` → `kurumsal-turkce-yazim` → `turkce-dogallastirici` → `word-ileri` |
| Okul fatura listesi (telefon, internet, elektrik, su) | `okul-fatura-listesi` → `word-ileri`; toplam kodla |
| Direksiyon / MTSK imza sirküsü | `sinav-imza-sirkusu` → `word-ileri` veya `excel-temel` |
| Konuşma metni, duyuru, tebrik, anma | `kurumsal-turkce-yazim` → `turkce-dogallastirici` |
| Diğer listeler ve tablolar | `excel-temel` (gerekirse `excel-makro-vba`); başlık ve açıklama metinlerine `kurumsal-turkce-yazim` |
| Tekrarlanan Excel işi otomasyonu | `excel-makro-vba` → `excel-otomasyon-ustasi` |
| Kurumsal şablon (.dotx, mail merge) | `word-ileri` → `word-ileri-ustasi` |
| Sunum | içerik → `turkce-dogallastirici` → `powerpoint-ustasi` (gerekirse `powerpoint-ileri-ustasi`) |
| PDF birleştir, böl, doldur, imzala | `pdf-ustasi` |
| Afiş, broşür, kapak, antet | `tasarim-ustasi` |
| Web sayfası, HTML, dashboard | `ui-ux-pro-max` (görsel karar) → `html-ustasi` |
| APK / WebView / Capacitor uygulaması | `webview-apk-kurallari` + `capacitor-app-development` (yeni proje: `capacitor-app-creation`) |
| APK'da indirme/kayıt çökmesi | `webview-apk-indirme` + `webview-apk-kurallari` |
| Chrome eklentisi | `modern-web-guidance:chrome-extensions` |
| Kod hatası | `systematic-debugging` → düzeltme → `verification-before-completion` |
| Kod incelemesi | `code-reviewer` |
| Araştırma / rapor | `content-research-writer` veya `market-research`; Türkçe çıktıya `turkce-dogallastirici` |

Tabloda olmayan bir iş gelirse skill listesindeki açıklamalar (özellikle Türkçe tetikleyiciler) taranır ve en dar kapsamlı uygun skill seçilir.

## 4. Çakışma kuralları

- **Kullanıcının adını verdiği skill** her zaman kazanır.
- **Dar kapsamlı skill geniş olanı yener:** EBYS yazısında `ebys-yazisma`, ceza kararında `tasimali-egitim-ceza-karari`, fatura listesinde `okul-fatura-listesi` genel yazım ve dosya skill'lerinin önüne geçer.
- **Resmî kalıplar dokunulmazdır:** `turkce-dogallastirici` resmî yazının "arz ederim / rica ederim", ilgi, konu, dağıtım gibi yönetmelik gereği kalıplarını, tutanak kapanış kalıbını ve karar cümlesini değiştiremez; yalnızca gövde metnin akışını düzeltir.
- **Aynı işi yapan iki skill birlikte yüklenmez:** Word için `word-ileri` varken `docx` ancak .docx dosyası teknik olarak üretilecek veya düzenlenecekse eklenir. Excel ve PowerPoint için de aynı mantık geçerlidir.
- **`humanizer` yalnızca İngilizce metinde** kullanılır; Türkçe metinde görevi `turkce-dogallastirici` üstlenir.
- **Dosya biçimi:** Kullanıcı Word/Excel/PowerPoint dosyası açıkça istemişse veya alan skill'i (ceza kararı, fatura listesi, tutanak) Word öngörüyorsa dosya üretilir; aksi hâlde oturumdaki Docs/Sheets/Slides artifact türleri tercih edilir.

## 5. Uygulama disiplini

- Yüklenen her skill'in SKILL.md dosyası gerçekten okunur ve talimatları uygulanır; isim olarak anılıp geçilmez.
- Bir skill başka bir skill'e yönlendiriyorsa o da yüklenir.
- Skill'in istediği bilgi eksikse (tarih, sayı, ilgi) iş durdurulmaz: makul yer tutucu konur ve teslimde tek cümleyle belirtilir. Yalnızca geri dönüşü olmayan ya da iki farklı yöne gidebilecek kararlarda kullanıcıya sorulur.
- Kullanıcıya skill seçim süreci anlatılmaz; "şu skill'i yüklüyorum" türü açıklamalar yapılmaz. Sadece sonuç teslim edilir.

## 6. Teslim öncesi kontrol listesi

Teslimden hemen önce şu sorular tek tek yanıtlanır:

- [ ] Talebin konusuna uyan her skill yüklendi mi, gereksiz olan atlandı mı?
- [ ] Alan skill'inin (ör. `ebys-yazisma`, `okul-fatura-listesi`) kurallarının tamamı uygulandı mı?
- [ ] Biçim skill'inin istediği yapı (stil, sütun, sayfa düzeni) doğru mu?
- [ ] Türkçe metin TDK yazım, noktalama ve imla kurallarına tam uygun mu?
- [ ] Metin kurumsal dilde ve baştan sona insan elinden çıkmış gibi mi?
- [ ] Hesap varsa kodla doğrulandı mı, dosya varsa açılıp kontrol edildi mi?

Biri bile "hayır" ise düzeltilmeden teslim edilmez. Çıta her zaman en üst seviyedir.
