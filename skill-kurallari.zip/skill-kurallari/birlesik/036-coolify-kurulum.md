# coolify-kurulum

---
name: "coolify-kurulum"
description: "Vercel, Heroku ve Netlify'a açık kaynaklı alternatif Coolify'ı kendi sunucuda kurma, ilk yapılandırma ve uygulama dağıtımı istendiğinde kullanmak için."
---

# Coolify Kurulum Rehberi

Coolify (coollabsio/coolify), statik siteleri, veritabanlarını ve tam yığın uygulamaları kendi sunucuna dağıtmayı sağlayan, kendi sunucuda barındırılabilen açık kaynaklı bir PaaS'tir. Yönetilen bulut sürümü de vardır (Coolify Cloud), onda kurulum gerekmez.

## Ne zaman kullanılır
- Kullanıcı kendi sunucusunda uygulama ve site dağıtım platformu kurmak istediğinde.
- Kurulum, ilk yapılandırma, alan adı bağlama ya da yedekleme konusunda yardım istendiğinde.

## Çalışma ilkeleri
1. Coolify, SSH erişimi olan ayrı bir sunucuya kurulur. Claude'un çalışma alanında kurulamaz. Komutları ve kontrol listesini hazırla, kurulumu kullanıcı yapar.
2. Kurulum betiğini çalıştırmadan önce kaynak kodunu okumayı öner. Betik sunucuda sistem düzeyinde değişiklik yapar.
3. Gereksinimleri ve komutları vermeden önce resmî belgeyi kontrol et (https://coolify.io/docs/get-started/installation).

## Ön koşullar
- SSH erişimi olan bir sunucu (VPS, ayrı bir sunucu ya da ev laboratuvarı makinesi).
- Otomatik betik yalnızca Ubuntu LTS sürümlerinde (20.04, 22.04, 24.04) çalışır. Başka bir sürümde ya da betik sorun çıkarırsa el ile kurulum gerekir.
- Temiz (yeni) bir sunucu önerilir. Minimum donanım gereksinimini resmî belgeden doğrula. Coolify'ın kendisiyle aynı sunucuda derleme yapılıyorsa kaynak kullanımı izlenmelidir.
- Docker Snap ile kuruluysa önce kaldırılır, betik Docker Engine'i kendisi kurar.

## Hızlı kurulum
`curl -fsSL https://cdn.coollabs.io/coolify/install.sh | sudo bash`
(root kullanıcı değilse `sudo` ile)

Betik bağımlılıkları ve Docker Engine'i kurar, `/data/coolify` altında dizinleri oluşturur, SSH anahtarlarını yapılandırır ve Coolify'ı başlatır.

## Kurulumdan sonra
1. Betik, Coolify adresini gösterir. Biçim: `http://sunucu-ip:8000`
2. **Yönetici hesabını hemen oluştur.** Hesabı başka biri önce oluşturursa sunucunun denetimi onun eline geçer.
3. Kurulum sırasında üretilen gizli bilgileri (örneğin veritabanı değerlerini şifreleyen APP_KEY) yedekle. Bu değerleri sonradan değiştirmek kurulumu bozabilir.
4. Üretim kullanımında bir alan adı bağla: sunucu IP'sine işaret eden bir A kaydı oluştur ve alan adını Coolify ayarlarına gir.
5. İlk dağıtım için Coolify'ın kurulu olduğu sunucuyu (localhost) seçip bir GitHub deposundan uygulama ekle.
