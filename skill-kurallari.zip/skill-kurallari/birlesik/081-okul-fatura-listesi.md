# okul-fatura-listesi

---
name: "okul-fatura-listesi"
description: "Nurhak İlçe MEM adına okulların telefon, internet, elektrik veya su fatura listesini hazırlarken kullan; onaylı editoryal tasarımı ve tür simgesini uygular."
---

# Okul Fatura Listesi

Telefon, internet, elektrik ve su faturalarının hepsi **aynı düzende ve aynı tasarımda** hazırlanır. Referans: Ekim 2026 elektrik listesi, editoryal ("Fable 5.1") tasarım + tür simgesi (kullanıcı tarafından onaylandı, bundan sonraki standart tasarım). Eski sade düzene, lacivert 3. sürüme ve alttaki boş imza kutularına dönülmez.

Birlikte çalışan skill'ler: başlık ve "Yalnız" satırı için `kurumsal-turkce-yazim`; dosya için `word-ileri-ustasi` / `docx`.

## 1. Girdi

Kullanıcı fatura görsellerini, PDF'lerini veya bir döküm verir. Her faturadan şunlar okunur: okul adı, abone no (telefonda telefon numarası, elektrikte ABONENO), fatura no, fatura tarihi, son ödeme tarihi, tutar (ödenecek tutar).

Kullanıcı taramaları kendisi atmadıkça taramalara dokunulmaz.

**Fatura no önek denetimi** (okunan değer bu kurala uymuyorsa yakınlaştırıp yeniden bak; yine uymuyorsa faturada basılı hâliyle yaz ve kullanıcıya tek satırla işaret et):

| Tür | Fatura no |
|---|---|
| Telefon (Türk Telekom) | `P01` ile başlar |
| İnternet | `A16` ile başlar |
| Elektrik | `ABN` ile başlar (bazı faturalar `AB1` ile basılıyor; basılı hâliyle yazılır) |
| Su | Harf öneki yok, rakamla başlar (faturada "Fatura No" yazan alan) |

Okul adı faturada farklı yazılıysa kullanıcının söylediği ad esas alınır (ör. "Tatlar İlkokulu"). Faturada geçmiş dönem borcu veya gecikme zammı varsa tutar sütununa yalnızca o faturanın ödenecek tutarı yazılır; borç ve gecikme kullanıcıya ayrıca bildirilir.

## 2. Belge düzeni

Word, **A4 yatay**, **tek sayfa**, kenar boşlukları sağ/sol 1000 DXA, üst 1000, alt 850 (satır sayısı 6'yı aşarsa sıkı mod: üst 700, alt 600, daha küçük başlık, simge ve satır yüksekliği). Yazı tipleri: **Calibri** (gövde), **Cambria** (başlık ve genel toplam), **Consolas** (sıra no, abone no, fatura no). Renkler: mürekkep `1B1F2A`, gri `6B7280`, vurgu turkuaz `0B5563`, ince çizgi `E3E6EC`.

1. **Üst başlık:** `T.C.  ·  NURHAK KAYMAKAMLIĞI` (küçük, kalın, aralıklı, turkuaz) ve altında `İLÇE MİLLÎ EĞİTİM MÜDÜRLÜĞÜ` (küçük, aralıklı, gri).
2. **Başlık satırı (kenarlıksız iki hücreli tablo):** solda **tür simgesi**, sağda `Okulların {Tür} Faturası Listesi` (Cambria, 30 pt; sıkı modda 24 pt).
3. **Tür simgesi:** yuvarlatılmış açık turkuaz (`E3EFF1`) kutu içinde turkuaz çizgi simge, 58 px (sıkı modda 46 px). Elektrik = şimşek, Telefon = ahize, İnternet = globe, Su = damla. Simgeler PNG olarak hazırdır (scratchpad `icons/`); yoksa Feather tarzı SVG'den Chromium ile üretilir. Simge hücresinin kenar boşlukları sıfırdır ki sol kenara hizalansın.
4. Başlığın altında kısa **turkuaz çizgi** (900 DXA genişlik).
5. **Meta satırı:** `Fatura dönemi Ekim 2026 · Fatura adedi N · Genel toplam X TL` (etiketler gri, değerler kalın; toplam turkuaz).
6. **Tablo**, sütunlar bu sırayla: No · Abonelik Türü · Okul Adı · Abone No (telefonda: Telefon No) · Fatura No · Fatura Tarihi · Son Ödeme Tarihi · Tutar (TL). Tutar her zaman son sütun, sağa hizalı. Başlık satırı küçük harf aralıklı gri büyük harf, altında kalın mürekkep çizgi; satırlar arası ince çizgi; sıra no `01` biçiminde turkuaz Consolas; okul adı ve tutar kalın. Sütun genişlikleri: 600, 2450, 3000, 1900, 2450, 1400, 1450, 1550 (toplam 14800).
7. **GENEL TOPLAM** satırı: üstte çizgi, `GENEL TOPLAM` aralıklı gri etiket, tutar sağda Cambria 17 pt kalın turkuaz. Etiket 6 sütun, tutar son 2 sütun üzerinde birleştirilir; aksi hâlde tutar alt satıra kırılır.
8. Altında **"Yalnız … Türk lirası … kuruştur."** (kuruş yoksa "…lirasıdır.") italik gri Cambria tek satır.
9. **İmza bloğu, imza kutusu veya başka hiçbir şey eklenmez.**

## 3. Biçim kuralları

- Tarihler `GG.AA.YYYY`.
- Tutarlar `1.234,56`; TL simgesi başlıkta ("Tutar (TL)").
- Okul adları resmî adlarıyla, büyük harf kuralına uygun.
- Satırlar kullanıcının verdiği sırayla dizilir; kullanıcı "ilk sıra X" derse o okul başa alınır.
- Liste tek sayfaya sığmazsa sıkı mod devreye girer; yine sığmazsa kullanıcıya bildirilir.
- Toplam tutar tamsayı kuruş üzerinden kodla hesaplanır, "Yalnız" satırı bu toplamla aynı olmalıdır; sayılar TDK'ya uygun bitişik yazılır.

## 4. Teslim öncesi kontrol

- [ ] Genel toplam kodla hesaplandı ve satırların toplamıyla birebir aynı
- [ ] "Yalnız" satırı genel toplamla aynı tutarı söylüyor
- [ ] Fatura no önekleri türe uygun (uymayan varsa kullanıcıya bildirildi)
- [ ] Sütun sırası doğru, tutar son sütunda
- [ ] Başlıkta türe uygun simge var
- [ ] Genel toplam tutarı tek satırda
- [ ] Altta imza bloğu/kutusu yok
- [ ] Tek sayfa, yatay A4
- [ ] Dosya açılıp görsel olarak kontrol edildi
- [ ] Vadesi geçmiş borç, gecikme zammı veya yakın son ödeme tarihi varsa kullanıcıya bildirildi
