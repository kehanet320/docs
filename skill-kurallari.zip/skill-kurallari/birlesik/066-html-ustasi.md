# html-ustasi

---
name: html-ustasi
description: Modern HTML/CSS/JavaScript ile profesyonel web sayfaları, dashboard'lar ve email şablonları oluşturma ustası. Kullanıcı "HTML sayfası", "web sayfası", "landing page", "tek sayfa site", "kurumsal site", "dashboard", "veri görselleştirme", "grafik", "Chart.js", "interaktif tablo", "email şablonu", "HTML email", "newsletter", "outlook uyumlu", "responsive", "mobil uyumlu", "CSS", "Tailwind", "modern web", "animasyon", "form tasarımı" gibi ifadeler kullandığında devreye girer. Üç ana modülü kapsar: modern web sayfaları, veri dashboard'ları, email HTML.
---

# HTML/Web Ustası — Kapsamlı Rehber

## Genel İlke

Web tasarımı bir **iş aracıdır**. "Güzel görünmesi" yetmez, **mesajını iletmesi**, **hızlı yüklenmesi**, **mobilde çalışması**, **erişilebilir olması** gerekir. Bu skill üç farklı senaryoyu kapsar:

1. [Modern Web Sayfaları](#bölüm-1-modern-web-sayfaları) — Landing page, kurumsal site, portfolio
2. [Veri Dashboard'ları](#bölüm-2-veri-dashboardları) — Grafik, tablo, etkileşim
3. [Email HTML Şablonları](#bölüm-3-email-html-şablonları) — Outlook, Gmail uyumlu

Her bölüm bağımsız çalışır, ihtiyaca göre ilgili bölüme atla.

Bu skill `frontend-design` resmi skill'iyle birlikte çalışır: O **AI klişelerinden uzak estetik** verir, bu skill **teknik altyapı** ve **modüler kullanım** sağlar.

---

## ⚠️ Tasarım Felsefesi: AI Klişelerinden Kaçın

AI'ın varsayılan ürettiği şey, **öngörülebilir ve sıkıcıdır**:

❌ **Inter / Roboto fontu** (her yerde)
❌ **Beyaz arka plan + mor degrade**
❌ **Yuvarlatılmış kartlar** (her şey card)
❌ **Pastel renk paletleri**
❌ **Lucide ikonlar her köşede**
❌ **"Hero section + 3 feature card + footer" kalıbı**

**Onun yerine:**
- Belirgin bir **estetik yön** seç (brutalist, editoryal, retro-fütüristik, minimal)
- **Belirli bir font** ile karakter ver (Playfair, Bebas Neue, Space Mono, vb.)
- **Bir** anahtar renk kullan, vurgu yap
- **Cesur** yerleşim yap (asimetri, beyaz alan, ölçek farkı)

---

## BÖLÜM 1: Modern Web Sayfaları

### 1.1 HTML5 İskeleti

```html
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Sayfa açıklaması (SEO için kritik)">
    <title>Sayfa Başlığı</title>
    
    <!-- Sosyal Medya Kartı -->
    <meta property="og:title" content="Paylaşım başlığı">
    <meta property="og:description" content="Paylaşım açıklaması">
    <meta property="og:image" content="paylaşım-görseli.jpg">
    
    <!-- Favicon -->
    <link rel="icon" type="image/svg+xml" href="favicon.svg">
    
    <!-- Stil -->
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>...</header>
    <main>...</main>
    <footer>...</footer>
    
    <script src="script.js"></script>
</body>
</html>
```

**Önemli:** `lang="tr"` — Türkçe içerik için. Erişilebilirlik ve SEO için gerekli.

### 1.2 Anlamsal HTML (Semantic)

`<div>` yığını yapmayın. **Anlamlı etiketler** kullanın:

| Etiket | Kullanım |
|--------|----------|
| `<header>` | Sayfa/bölüm başlığı |
| `<nav>` | Navigasyon menüsü |
| `<main>` | Ana içerik (sayfada **bir tane**) |
| `<article>` | Bağımsız içerik (blog yazısı, ürün) |
| `<section>` | Konu bölümü |
| `<aside>` | Kenar içerik |
| `<footer>` | Alt bilgi |
| `<figure>` + `<figcaption>` | Resim + açıklama |
| `<time>` | Tarih `<time datetime="2026-05-08">` |

**Niye?** Erişilebilirlik (ekran okuyucu), SEO, kod okunabilirliği.

### 1.3 Modern CSS

#### CSS Custom Properties (Değişkenler)

```css
:root {
    /* Renkler */
    --renk-ana: #1a1a1a;
    --renk-vurgu: #ff4500;
    --renk-arkaplan: #fafafa;
    --renk-metin: #2d2d2d;
    
    /* Tipografi */
    --font-baslik: 'Playfair Display', serif;
    --font-metin: 'Inter', system-ui, sans-serif;
    
    /* Boşluk */
    --bosluk-xs: 0.5rem;
    --bosluk-sm: 1rem;
    --bosluk-md: 2rem;
    --bosluk-lg: 4rem;
    --bosluk-xl: 8rem;
    
    /* Geçişler */
    --gecis: 0.3s ease;
}
```

Değişiklik tek yerden: `--renk-vurgu` değiştirsen **tüm sitede** vurgu rengi değişir.

#### CSS Grid

Layout için en güçlü araç:

```css
.izgara {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
    gap: 2rem;
}
```

`auto-fit` + `minmax`: Otomatik **responsive** ızgara — ekran daraldıkça sütun azalır.

#### Flexbox

Yatay/dikey hizalama için:

```css
.flex {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 1rem;
    flex-wrap: wrap;  /* Mobilde kırılsın */
}
```

#### Container Queries (Modern)

Element kendi boyutuna göre stillenir:

```css
.kart {
    container-type: inline-size;
}

@container (min-width: 400px) {
    .kart-icerik {
        flex-direction: row;
    }
}
```

### 1.4 Responsive Tasarım

#### Mobile-First Yaklaşım

**Önce mobil için yaz, sonra büyük ekran için ekle.** Tersi zordur.

```css
/* Mobil (varsayılan) */
.baslik {
    font-size: 1.75rem;
}

/* Tablet (768px+) */
@media (min-width: 768px) {
    .baslik {
        font-size: 2.5rem;
    }
}

/* Masaüstü (1024px+) */
@media (min-width: 1024px) {
    .baslik {
        font-size: 4rem;
    }
}
```

#### Akıcı Tipografi (Fluid Typography)

**Klasik:** Belirli boyutlarda zıplama.
**Modern:** `clamp()` ile **akıcı** geçiş:

```css
h1 {
    font-size: clamp(2rem, 5vw, 5rem);
}
```

`clamp(min, ideal, max)` — Ekrana göre 2rem ile 5rem arası **kaygan** geçiş.

### 1.5 Tipografi (Görsel Hiyerarşi)

#### Font Eşleştirmesi

İyi font kombinasyonları (her ikisi de Türkçe destekli):

| Karakter | Başlık | Metin |
|----------|--------|-------|
| **Klasik / Editoryal** | Playfair Display | Lora |
| **Modern Profesyonel** | Montserrat (kalın) | Open Sans |
| **Brutalist** | Space Grotesk | IBM Plex Mono |
| **Lüks / Premium** | Cormorant Garamond | Inter |
| **Teknolojik** | Space Grotesk | Space Mono |

Google Fonts üzerinden:
```html
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=Lora&display=swap" rel="stylesheet">
```

#### Hiyerarşi Kuralı

En az **3 boyut farkı** olmalı:

```css
h1 { font-size: clamp(2.5rem, 5vw, 5rem); line-height: 1.1; }
h2 { font-size: clamp(1.75rem, 3vw, 2.5rem); line-height: 1.2; }
h3 { font-size: clamp(1.25rem, 2vw, 1.5rem); line-height: 1.3; }
p  { font-size: 1rem; line-height: 1.6; }
```

`line-height` (satır yüksekliği): Başlık dar (1.1), metin geniş (1.6).

### 1.6 Renk

#### Kontrast (Erişilebilirlik)

Metin ve arka plan arasında **WCAG AA standardı** için en az **4.5:1** kontrast olmalı.

Kontrol araçları:
- WebAIM Contrast Checker
- Chrome DevTools (otomatik kontrol var)

#### Renk Paleti Stratejisi

**60-30-10 Kuralı:**
- %60 — Baskın renk (genelde nötr)
- %30 — İkincil renk (tema)
- %10 — Vurgu rengi (canlı)

**Örnek (Editoryal):**
```css
:root {
    --siyah: #0a0a0a;
    --beyaz: #fafafa;
    --gri: #e5e5e5;
    --vurgu: #d4541d;  /* turuncu kırmızı */
}
```

### 1.7 Animasyon ve Geçiş

#### Hover Geçişleri

```css
.dugme {
    background: var(--renk-vurgu);
    color: white;
    padding: 1rem 2rem;
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.dugme:hover {
    transform: translateY(-2px);
    box-shadow: 0 10px 30px rgba(0,0,0,0.2);
}
```

#### Scroll Animasyonları

```css
.eleman {
    opacity: 0;
    transform: translateY(30px);
    transition: opacity 0.8s, transform 0.8s;
}

.eleman.gorunur {
    opacity: 1;
    transform: translateY(0);
}
```

```javascript
const gozlemci = new IntersectionObserver(entries => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.classList.add('gorunur');
        }
    });
}, { threshold: 0.1 });

document.querySelectorAll('.eleman').forEach(el => gozlemci.observe(el));
```

#### Animasyonsuz Tercih (Erişilebilirlik)

```css
@media (prefers-reduced-motion: reduce) {
    * {
        animation: none !important;
        transition: none !important;
    }
}
```

### 1.8 Performans

**Hızlı yüklenmeyen site = ölü site.** Kontrol noktaları:

- **Resim formatı:** WebP veya AVIF (JPG/PNG'ye göre %30-50 küçük)
- **Lazy loading:** `<img loading="lazy">` — görünmeyen resimler yüklenmez
- **CSS/JS minify** — boşlukları sil, küçült
- **Font preload:** `<link rel="preload" as="font">`
- **CDN:** Tailwind, Bootstrap için CDN kullan
- **Lighthouse skoru:** Chrome DevTools → Lighthouse → 90+ hedefle

### 1.9 Tek Sayfalık Modern Site Şablonu

```html
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kurum Adı</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;700&family=Inter:wght@400;500&display=swap" rel="stylesheet">
    <style>
        :root {
            --siyah: #0a0a0a;
            --beyaz: #fafafa;
            --vurgu: #d4541d;
            --bosluk: clamp(2rem, 5vw, 6rem);
        }
        
        * { margin: 0; padding: 0; box-sizing: border-box; }
        
        body {
            font-family: 'Inter', system-ui, sans-serif;
            background: var(--beyaz);
            color: var(--siyah);
            line-height: 1.6;
        }
        
        h1, h2, h3 {
            font-family: 'Space Grotesk', sans-serif;
            font-weight: 700;
            letter-spacing: -0.02em;
        }
        
        h1 { font-size: clamp(3rem, 8vw, 8rem); line-height: 0.95; }
        h2 { font-size: clamp(2rem, 4vw, 3.5rem); line-height: 1.1; }
        
        .konteyner {
            max-width: 1400px;
            margin: 0 auto;
            padding: 0 var(--bosluk);
        }
        
        section {
            padding: var(--bosluk) 0;
            border-bottom: 1px solid rgba(0,0,0,0.1);
        }
        
        .vurgu { color: var(--vurgu); }
        
        nav {
            position: sticky;
            top: 0;
            background: rgba(250,250,250,0.95);
            backdrop-filter: blur(10px);
            padding: 1rem 0;
            z-index: 100;
        }
        
        nav ul {
            display: flex;
            gap: 2rem;
            list-style: none;
            justify-content: flex-end;
        }
        
        a { color: inherit; text-decoration: none; }
        a:hover { color: var(--vurgu); }
        
        @media (max-width: 768px) {
            nav ul { gap: 1rem; flex-wrap: wrap; }
        }
    </style>
</head>
<body>
    <nav>
        <div class="konteyner">
            <ul>
                <li><a href="#hakkinda">Hakkında</a></li>
                <li><a href="#hizmetler">Hizmetler</a></li>
                <li><a href="#iletisim">İletişim</a></li>
            </ul>
        </div>
    </nav>
    
    <section>
        <div class="konteyner">
            <h1>Cesur. <span class="vurgu">Net.</span> Akıllı.</h1>
            <p style="font-size: 1.5rem; max-width: 600px; margin-top: 2rem;">
                Sıradanlığa savaş açtık. İşinizi öne çıkaran çözümler.
            </p>
        </div>
    </section>
    
    <section id="hizmetler">
        <div class="konteyner">
            <h2>Ne Yapıyoruz</h2>
            <!-- İçerik -->
        </div>
    </section>
</body>
</html>
```

---

## BÖLÜM 2: Veri Dashboard'ları

### 2.1 Dashboard Felsefesi

İyi dashboard:
- **Tek bakışta** durumu söyler
- **En önemli 3-5 metriği** öne çıkarır
- **Detaya inmeyi** ister kullanıcıya seçim verir
- **Mobilde de çalışır** (yöneticiler telefondan bakar)

### 2.2 Dashboard Düzeni

#### KPI Kartları (Üst)

En önemli sayılar **en üstte**:

```html
<div class="kpi-grid">
    <div class="kpi-kart">
        <div class="kpi-baslik">Toplam Kullanıcı</div>
        <div class="kpi-deger">12.847</div>
        <div class="kpi-degisim artis">+12% geçen aya göre</div>
    </div>
    <!-- 3-5 KPI kartı -->
</div>
```

```css
.kpi-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
    gap: 1.5rem;
    margin-bottom: 2rem;
}

.kpi-kart {
    background: white;
    padding: 1.5rem;
    border-radius: 12px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.05);
    border-left: 4px solid var(--renk-vurgu);
}

.kpi-deger {
    font-size: 2.5rem;
    font-weight: 700;
    margin: 0.5rem 0;
}

.kpi-degisim {
    font-size: 0.875rem;
}

.artis { color: #16a34a; }
.azalis { color: #dc2626; }
```

### 2.3 Chart.js — En Pratik Grafik Kütüphanesi

CDN'den yüklemek yeter:

```html
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0"></script>
<canvas id="grafik"></canvas>
<script>
new Chart(document.getElementById('grafik'), {
    type: 'line',
    data: {
        labels: ['Oca', 'Şub', 'Mar', 'Nis', 'May'],
        datasets: [{
            label: '2026 Satışlar',
            data: [12, 19, 15, 25, 22],
            borderColor: '#d4541d',
            backgroundColor: 'rgba(212, 84, 29, 0.1)',
            fill: true,
            tension: 0.4
        }]
    },
    options: {
        responsive: true,
        plugins: {
            legend: { display: true, position: 'top' }
        }
    }
});
</script>
```

#### Chart Türleri

| Tip | Ne için |
|-----|---------|
| `line` | Zaman serisi |
| `bar` | Kategori karşılaştırma |
| `pie` / `doughnut` | Pay dağılımı |
| `radar` | Çoklu boyut karşılaştırma |
| `scatter` | İki değişken ilişkisi |
| `bubble` | Üç boyutlu (x, y, boyut) |

#### Profesyonel Chart İpuçları

```javascript
options: {
    responsive: true,
    maintainAspectRatio: false,  // Kendi boyutunu zorla
    plugins: {
        legend: { 
            position: 'bottom',
            labels: { font: { size: 12 } }
        },
        tooltip: {
            backgroundColor: 'rgba(0,0,0,0.9)',
            padding: 12,
            cornerRadius: 8,
            callbacks: {
                label: (ctx) => `${ctx.dataset.label}: ${ctx.parsed.y.toLocaleString('tr-TR')} ₺`
            }
        }
    },
    scales: {
        y: {
            beginAtZero: true,
            ticks: {
                callback: (val) => val.toLocaleString('tr-TR')
            }
        }
    }
}
```

### 2.4 Etkileşimli Tablolar

Büyük tablolar için **arama, sıralama, sayfalama**:

#### Saf JavaScript ile

```html
<input type="search" id="ara" placeholder="Ara...">
<table id="tablo">
    <thead>
        <tr>
            <th data-sirala="0">Ad</th>
            <th data-sirala="1">Şehir</th>
            <th data-sirala="2">Tutar</th>
        </tr>
    </thead>
    <tbody>
        <!-- satırlar -->
    </tbody>
</table>

<script>
// Arama
document.getElementById('ara').addEventListener('input', (e) => {
    const arama = e.target.value.toLowerCase();
    document.querySelectorAll('#tablo tbody tr').forEach(satir => {
        const metin = satir.textContent.toLowerCase();
        satir.style.display = metin.includes(arama) ? '' : 'none';
    });
});

// Sıralama
document.querySelectorAll('th[data-sirala]').forEach(baslik => {
    baslik.addEventListener('click', () => {
        const idx = parseInt(baslik.dataset.sirala);
        const tbody = document.querySelector('#tablo tbody');
        const satirlar = Array.from(tbody.querySelectorAll('tr'));
        
        satirlar.sort((a, b) => {
            const av = a.children[idx].textContent;
            const bv = b.children[idx].textContent;
            return av.localeCompare(bv, 'tr');
        });
        
        satirlar.forEach(s => tbody.appendChild(s));
    });
});
</script>
```

#### Hazır kütüphane: DataTables

Daha gelişmiş özellik isteniyorsa:

```html
<link rel="stylesheet" href="https://cdn.datatables.net/2.1.0/css/dataTables.dataTables.min.css">
<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script src="https://cdn.datatables.net/2.1.0/js/dataTables.min.js"></script>

<script>
new DataTable('#tablo', {
    language: {
        url: 'https://cdn.datatables.net/plug-ins/2.1.0/i18n/tr.json'
    }
});
</script>
```

Bedavaya: arama, sıralama, sayfalama, dışa aktarma.

### 2.5 Tam Dashboard Şablonu (Kısaltılmış)

```html
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Yönetim Paneli</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0"></script>
    <style>
        :root {
            --renk-arka: #f8f9fa;
            --renk-kart: #ffffff;
            --renk-ana: #2563eb;
            --renk-yesil: #16a34a;
            --renk-kirmizi: #dc2626;
        }
        body {
            font-family: system-ui, sans-serif;
            background: var(--renk-arka);
            margin: 0;
            padding: 2rem;
        }
        .baslik { font-size: 2rem; margin-bottom: 1rem; }
        .grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }
        .kart {
            background: var(--renk-kart);
            padding: 1.5rem;
            border-radius: 12px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.06);
        }
        .kpi { border-left: 4px solid var(--renk-ana); }
        .kpi-deger { font-size: 2rem; font-weight: 700; margin: 0.5rem 0; }
        .grafik-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
            gap: 1.5rem;
        }
        .grafik-konteyner {
            background: var(--renk-kart);
            padding: 1.5rem;
            border-radius: 12px;
        }
    </style>
</head>
<body>
    <h1 class="baslik">Yönetim Paneli</h1>
    
    <div class="grid">
        <div class="kart kpi">
            <div>Toplam Satış</div>
            <div class="kpi-deger">₺ 1.245.000</div>
            <div style="color: var(--renk-yesil)">+12% bu ay</div>
        </div>
        <!-- Diğer KPI'lar -->
    </div>
    
    <div class="grafik-grid">
        <div class="grafik-konteyner">
            <canvas id="grafik1"></canvas>
        </div>
        <div class="grafik-konteyner">
            <canvas id="grafik2"></canvas>
        </div>
    </div>
    
    <script>
        new Chart(document.getElementById('grafik1'), {
            type: 'line',
            data: { /* veriler */ }
        });
    </script>
</body>
</html>
```

---

## BÖLÜM 3: Email HTML Şablonları

### 3.1 Email HTML'in Acımasız Gerçeği

**Email HTML, web HTML'inden 20 yıl geride.** Sebep: Outlook (özellikle Windows) hâlâ **Word HTML motoru** kullanıyor. Modern CSS'in çoğu çalışmaz.

**Yasaklılar:**
- ❌ Flexbox
- ❌ CSS Grid
- ❌ `position: absolute/fixed`
- ❌ JavaScript
- ❌ Gömülü font dosyaları
- ❌ Background image (kısmen — Outlook'ta sorunlu)
- ❌ CSS değişkenleri (`--renk`)
- ❌ Modern renk fonksiyonları (`hsl()`, `rgba()` çoğunda)

**Kullanılabilirler:**
- ✅ HTML tablolar (`<table>`)
- ✅ Inline CSS (`style="..."`)
- ✅ Web-safe fontlar
- ✅ `padding`, `margin` (sınırlı)

### 3.2 Tablo-Tabanlı Düzen

Email'de **tüm düzen tablolarla** yapılır.

```html
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0">
    <tr>
        <td align="center">
            <table role="presentation" width="600" cellpadding="0" cellspacing="0" border="0">
                <!-- Email genişliği max 600px -->
                <tr>
                    <td>
                        İçerik buraya
                    </td>
                </tr>
            </table>
        </td>
    </tr>
</table>
```

**Niye 600px?** Çoğu email istemcisi 600px civarı görüntüler.

### 3.3 Inline CSS Zorunluluğu

Email'lerde `<style>` blokları **silinir** veya yok sayılır (Gmail). Tüm stiller **inline** olmalı:

```html
<!-- KÖTÜ -->
<style>.metin { color: red; }</style>
<p class="metin">Yazı</p>

<!-- İYİ -->
<p style="color: red;">Yazı</p>
```

**İpucu:** Önce `<style>` ile yaz (geliştirme kolaylığı), sonra **inliner aracıyla** inline'a çevir:
- premailer.dialect.ca
- inliner.cm
- mjml.io (otomatik üretir)

### 3.4 Web-Safe Fontlar

```css
font-family: Arial, Helvetica, sans-serif;
font-family: Georgia, 'Times New Roman', serif;
font-family: Verdana, sans-serif;
font-family: 'Courier New', monospace;
font-family: Tahoma, sans-serif;
```

Google Fonts **çalışmaz** (Outlook). Custom fontlar için `font-family` zinciri yaz, **fallback** kesin olsun.

### 3.5 Görsel ve Logo

```html
<img src="https://kurum.com/logo.png" 
     alt="Kurum Logosu" 
     width="200" 
     height="60"
     style="display: block; max-width: 100%; height: auto;">
```

**Kurallar:**
- **Tam URL** kullan (https://...) — relatif yol çalışmaz
- **Width/height attribute** mutlaka belirt — Outlook için
- `display: block` — alttaki boşluğu engeller
- `alt` attribute — görsel yüklenmediğinde görünür (çoğu kullanıcı görselleri kapatır!)

### 3.6 "Bullet-proof" Buton

Email'de buton tasarlama (Outlook dahil çalışan):

```html
<table role="presentation" cellpadding="0" cellspacing="0" border="0">
    <tr>
        <td align="center" 
            bgcolor="#1a73e8" 
            style="border-radius: 6px;">
            <a href="https://example.com" 
               target="_blank"
               style="display: inline-block; 
                      padding: 14px 28px; 
                      font-family: Arial, sans-serif; 
                      font-size: 16px; 
                      color: #ffffff; 
                      text-decoration: none; 
                      border-radius: 6px;">
                Buton Metni
            </a>
        </td>
    </tr>
</table>
```

### 3.7 Outlook Özel Conditional Comment

Outlook için özel kod:

```html
<!--[if mso]>
<table>...</table>
<![endif]-->

<!--[if !mso]><!-->
<div>Modern istemciler</div>
<!--<![endif]-->
```

### 3.8 Tam Email Şablonu

```html
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html lang="tr" xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Email Başlığı</title>
    <!--[if mso]>
    <noscript>
        <xml>
            <o:OfficeDocumentSettings>
                <o:PixelsPerInch>96</o:PixelsPerInch>
            </o:OfficeDocumentSettings>
        </xml>
    </noscript>
    <![endif]-->
</head>
<body style="margin: 0; padding: 0; background-color: #f4f4f4; font-family: Arial, Helvetica, sans-serif;">
    
    <!-- Önizleme metni (gelen kutusunda görünür) -->
    <div style="display: none; max-height: 0; overflow: hidden;">
        Email önizleme metni — gelen kutusunda görünür
    </div>
    
    <!-- Ana konteyner -->
    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="background-color: #f4f4f4;">
        <tr>
            <td align="center" style="padding: 40px 20px;">
                
                <!-- 600px genişliğinde içerik -->
                <table role="presentation" width="600" cellpadding="0" cellspacing="0" border="0" style="background-color: #ffffff; border-radius: 8px; overflow: hidden;">
                    
                    <!-- Header -->
                    <tr>
                        <td style="padding: 30px 40px; background-color: #1a73e8; text-align: center;">
                            <img src="https://kurum.com/logo-beyaz.png" alt="Kurum" width="180" style="display: block; margin: 0 auto;">
                        </td>
                    </tr>
                    
                    <!-- İçerik -->
                    <tr>
                        <td style="padding: 40px;">
                            <h1 style="margin: 0 0 20px; font-size: 24px; color: #1a1a1a; font-family: Arial, sans-serif;">
                                Sayın İlgili,
                            </h1>
                            <p style="margin: 0 0 16px; font-size: 16px; line-height: 1.6; color: #4a4a4a;">
                                Bu email'in içeriği buraya yazılır. Resmi bir email için resmi üslup, samimi için samimi üslup.
                            </p>
                            <p style="margin: 0 0 24px; font-size: 16px; line-height: 1.6; color: #4a4a4a;">
                                İkinci paragraf burada devam eder.
                            </p>
                            
                            <!-- Buton -->
                            <table role="presentation" cellpadding="0" cellspacing="0" border="0" style="margin: 30px 0;">
                                <tr>
                                    <td align="center" bgcolor="#1a73e8" style="border-radius: 6px;">
                                        <a href="https://example.com" target="_blank" style="display: inline-block; padding: 14px 32px; font-family: Arial, sans-serif; font-size: 16px; color: #ffffff; text-decoration: none; font-weight: bold;">
                                            Detayları Gör
                                        </a>
                                    </td>
                                </tr>
                            </table>
                            
                            <p style="margin: 0; font-size: 14px; line-height: 1.6; color: #888;">
                                Saygılarımla,<br>
                                Kurum Adı
                            </p>
                        </td>
                    </tr>
                    
                    <!-- Footer -->
                    <tr>
                        <td style="padding: 24px 40px; background-color: #f8f9fa; text-align: center; border-top: 1px solid #e5e5e5;">
                            <p style="margin: 0 0 8px; font-size: 12px; color: #888;">
                                Bu email kurumumuzdan otomatik gönderilmiştir.
                            </p>
                            <p style="margin: 0; font-size: 12px; color: #888;">
                                © 2026 Kurum Adı. Tüm hakları saklıdır.
                            </p>
                        </td>
                    </tr>
                    
                </table>
            </td>
        </tr>
    </table>
    
</body>
</html>
```

### 3.9 Email Test Etme

Email göndermeden önce **birden fazla istemcide** test:

- **Litmus** (ücretli, en iyi) — 90+ istemcide görünüm
- **Email on Acid** (alternatif)
- **Mailtrap** (test gönderimi)
- **Manuel test:** Kendine gönder → Gmail (web), Outlook (Windows), iPhone Mail, Yahoo, Yandex'te aç

### 3.10 Email Kontrol Listesi

- [ ] **Tüm CSS inline** mi?
- [ ] **600px genişlik** sınırı tutturuldu mu?
- [ ] **Tablo-tabanlı** düzen mi?
- [ ] Görsellerin **alt** attribute'u var mı?
- [ ] Görsellerde **width/height** belirtildi mi?
- [ ] **Buton** tablo ile yapıldı mı (sadece `<button>` değil)?
- [ ] **Outlook'ta** test edildi mi?
- [ ] **Mobilde** okunaklı mı (font ≥ 14px)?
- [ ] **Önizleme metni** (preview text) eklendi mi?
- [ ] **Unsubscribe (abonelik iptal)** linki var mı (yasal!)?
- [ ] **Spam tetikleyici kelimeler** ("BEDAVA!", "ŞİMDİ TIKLA") yok mu?

---

## Genel Karar Tablosu

| İhtiyaç | Yaklaşım |
|---------|----------|
| Tek sayfalık modern site | Modern HTML5 + CSS Grid + Vanilla JS |
| Etkileşimli dashboard | HTML + Chart.js + DataTables |
| Email kampanya | Tablo-tabanlı email HTML + Inline CSS |
| Kurumsal landing page | HTML + CSS + minimal JS, mobile-first |
| Çok sayfalı site | Statik site üreticisi (Astro, 11ty) önerilir |
| Veri ağırlıklı uygulama | React/Vue önerilir (bu skill'in dışı) |

---

## Erişilebilirlik (Accessibility)

Tüm web çalışmalarında dikkat edilecekler:

- **Semantic HTML** kullan
- Resimlere **alt** attribute
- Formlara **label** ekle
- **Renk körlüğü** test et (kontrast, sadece renkle bilgi verme)
- **Klavyeyle gezinilebilir** olmalı
- **ARIA** etiketleri karmaşık component'larda
- **Heading sırası** mantıklı (h1 → h2 → h3, atlamadan)

```html
<!-- KÖTÜ -->
<div onclick="ac()">Aç</div>

<!-- İYİ -->
<button type="button" onclick="ac()" aria-label="Menüyü aç">Aç</button>
```

---

## SEO İlkeleri

- **`<title>`** her sayfada benzersiz, anlamlı
- **`<meta description>`** 150-160 karakter, açıklayıcı
- **Heading hiyerarşisi** (h1 tek tane)
- **Anlamlı URL'ler** (`/hizmetler` değil `/sayfa-12`)
- **Open Graph tags** (sosyal medya paylaşımı)
- **Schema.org markup** (yapısal veri)
- **Mobil uyum**
- **Hız** (Google sıralama faktörü)

---

## Son Söz

Web tasarımı **gelişmeye devam eden bir disiplin**. Bu skill, **2026 itibariyle** modern, profesyonel, **AI klişelerinden uzak** üretim yapmak için derlenmiştir.

Her zaman sor: **Bu sayfa, kullanıcıya ne kadar zamanda ne kadar değer verir?** Cevap "çok az" ise tasarımı yeniden düşün.
