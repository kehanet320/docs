# openvoice-ses-klonlama

---
name: "openvoice-ses-klonlama"
description: "Açık kaynaklı anlık ses klonlama modeli OpenVoice'u kurma ve kullanma istendiğinde, özellikle kullanıcının kendi sesi ya da izinli sesler için kullanmak üzere."
---

# OpenVoice Kurulum ve Kullanım Rehberi

OpenVoice (myshell-ai/OpenVoice), MyShell tarafından geliştirilen, MIT lisanslı bir anlık ses klonlama modelidir. Kısa bir ses örneğinden sesin ton rengini çıkarır ve bu sesle birden çok dilde konuşma üretebilir. Duygu, vurgu, ritim ve duraklama gibi ses üslubu özellikleri de denetlenebilir.

## Ne zaman kullanılır
- Kullanıcı bir ses örneğinden ses klonlamak ya da klonlanan sesle başka bir dilde konuşma üretmek istediğinde.
- Kurulum, model dosyaları ya da örnek kullanım konusunda yardım istendiğinde.

## Çalışma ilkeleri
1. **İzin ve kötüye kullanım sınırı:** Yalnızca kullanıcının kendi sesi ya da sahibinin açık izni olan sesler için yardım et. Başka birinin sesini izinsiz taklit etmeye, dolandırıcılığa, aldatmaya ya da kimlik takınmaya yönelik istekleri reddet. Üretilen sesin yapay olduğunun belirtilmesini öner.
2. Proje, bir ekran kartıyla Linux'ta araştırmacılar ve geliştiriciler için tarif edilmiştir. Kullanıcının işletim sistemi ve donanımını öğrenmeden çalışacağı sözünü verme. Windows ve macOS için resmî belgede topluluğun yazdığı resmî olmayan kurulum rehberleri bulunur.
3. Kurulum adımlarını vermeden önce resmî belgeyi kontrol et (https://github.com/myshell-ai/OpenVoice/blob/main/docs/USAGE.md), bağımlılık sürümleri değişebilir.
4. Proje kullanıcının kendi bilgisayarında çalışır. Claude'un çalışma alanında model çalıştırılamaz. Komutları ve kontrol listesini hazırla.

## Hızlı deneme (kurulumsuz)
MyShell'in barındırdığı hazır web hizmetleri ve Hugging Face demo alanı bulunur. Hızlı denemek isteyen ve yüksek kalite ya da kararlılık beklemeyen kullanıcıya bunu öner. Bağlantıları resmî belgeden al.

## Yerel kurulum (Linux)
1. `conda create -n openvoice python=3.9`
2. `conda activate openvoice`
3. `git clone https://github.com/myshell-ai/OpenVoice.git`
4. `cd OpenVoice`
5. `pip install -e .`
6. Model dosyalarını (checkpoint) resmî belgedeki bağlantıdan indir ve `checkpoints` klasörüne çıkar. V1 ve V2 için kurulum aynıdır, model dosyaları ayrıdır.
7. V2 için MeloTTS'i kur: `pip install git+https://github.com/myshell-ai/MeloTTS.git`
8. Örnek kullanım için depodaki `demo_part1.ipynb` ve `demo_part2.ipynb` dosyalarına bak.

## Notlar
- Kuruluma bağlı olarak bazı paket sürümleri sıkı sıkıya sabittir (örneğin eski numpy ve gradio). Sorun çıkarsa temiz bir conda ortamında yeniden dene.
- MyShell, üretilen sesin OpenVoice ile üretilip üretilmediğini tespit etme hakkını saklı tutar. Bu bilgiyi gerektiğinde kullanıcıya aktar.
