# documenso-kurulum

---
name: "documenso-kurulum"
description: "Açık kaynaklı e-imza ve belge imzalama platformu Documenso'yu kendi sunucuda kurma, Docker ile ayağa kaldırma ve yapılandırma istendiğinde kullanmak için."
---

# Documenso Kurulum Rehberi

Documenso, DocuSign'a açık kaynaklı bir alternatiftir. Sözleşmeler gönderilir, imzalanır ve denetim izi korunur. Çekirdek özellikler AGPL-3.0 lisansı altındadır. SSO ve beyaz etiket gibi kurumsal özellikler lisans anahtarı ister.

## Ne zaman kullanılır
- Kullanıcı kendi sunucusunda belge imzalama hizmeti kurmak istediğinde.
- Kurulum, Docker, ortam değişkenleri, SMTP, veritabanı ya da yedekleme konusunda yardım istendiğinde.

## Çalışma ilkeleri
1. Documenso sürekli açık duran bir sunucu uygulamasıdır. Claude'un geçici çalışma alanında kalıcı olarak barındırılamaz. Kurulum kullanıcının kendi bilgisayarında ya da sunucusunda yapılır, Claude komutları ve yapılandırma dosyalarını hazırlar.
2. Elektronik imzanın hukuki geçerliliği ve kurumsal belge süreçlerine uygunluğu mevzuata bağlıdır. Bu konuda kesin hüküm verme, olgusal bilgi ver. Kurumsal kullanım için hukuk birimine ve kurumun belge yönetim sistemine danışılmasını öner.
3. Kurulum adımlarını kullanmadan önce resmî belgeden doğrula (https://docs.documenso.com/docs/self-hosting).

## Hızlı deneme (yerel)
- Docker ve Docker Compose kurulu olmalıdır.
- `git clone https://github.com/documenso/documenso.git`
- `cd documenso`
- `cp .env.example .env`
- `docker compose -f docker/development/compose.yml up -d`
- Tarayıcıda `http://localhost:3000` adresini aç.

## Kalıcı kurulum seçenekleri
- **Docker Compose:** PostgreSQL dahil, küçük ekipler için hazır üretim kurulumu.
- **Tek Docker kapsayıcısı:** Docker 20.10 ya da üstü ve erişilebilir bir PostgreSQL 14+ veritabanı gerekir. Görüntü: `documenso/documenso` (DockerHub) ya da `ghcr.io/documenso/documenso`.
- **Railway** (yönetilen) ve **Kubernetes** (yüksek erişilebilirlik) seçenekleri de vardır.

## Yapılandırmada dikkat edilecekler
- Veritabanı bağlantı adresleri, SMTP (bildirim e-postaları) ve imza sertifikası (.p12) ayarlanmalıdır.
- Kapsayıcı durumsuzdur, veriler veritabanında tutulur. Yedeği veritabanı için al.
- Güncellemede yeni görüntüyü çekip kapsayıcıyı aynı yapılandırmayla yeniden başlat. Veritabanı geçişleri başlangıçta otomatik çalışır.
