# powerpoint-ileri-ustasi

---
name: powerpoint-ileri-ustasi
description: PowerPoint'in profesyonel otomasyon ve şablon mimarisi için kullanılır. Kullanıcı "PowerPoint makro", "PowerPoint VBA", "Slayt otomasyonu", ".potx şablon", ".potm", "Slide Master tasarım", "Layout tasarım", "Section yönetimi", "Custom Show", "Motion Path", "Animation Pane", "Trigger animasyon", "kompleks animasyon", "köprü eylem", "Action button", "Hyperlink slayt", "Object align", "SmartArt iç yapı", "embedded media", "Designer", "PowerPoint Add-in", "Ribbon özelleştir" ifadelerinden birini kullandığında devreye girer. Mevcut powerpoint-ustasi skill'inin üzerine kurulan uzman katman: kurumsal şablon mimarisi, makroyla otomatik sunum üretimi, kompleks animasyon zincirleri, interaktif sunum tasarımı, dağıtılabilir tema paketleri.
---

# PowerPoint İleri Ustası

## Genel İlke

**Bir sunumu yapmak başka, bir sunum sistemini kurmak başka.**

Bu skill, mevcut **powerpoint-ustasi** skill'inin üzerine inşa edilir. Önkoşul: o skill'in sunum tasarımı, tipografi, renk, akış ve genel kurallarına hâkim olmak. Burada anlatılanlar **gerçek üretim ortamı** içindir: bir kurumun aylık raporları için tek tıkla üretilen 80 sayfalık sunum, kompleks animasyon zincirleriyle yapılmış eğitim sunumları, makroyla Excel verisinden otomatik grafik sunumu, kurumun tüm bilgisayarlarında çalışan tema paketi.

**Hedef seviye:** Tek sunum yapmak değil; **sunum üretimini sisteme bağlamak**. "Aynı raporu her ay sunulacak şekilde elle yapma" zamanını bitirmek.

---

## Bu Skill Ne Zaman Devreye Girer?

| Durum | Bu skill mi, powerpoint-ustasi mı? |
|-------|-----------------------------------|
| "İyi sunum nasıl tasarlanır" | **powerpoint-ustasi** |
| "Slayt başına kaç madde olmalı" | **powerpoint-ustasi** |
| "Slide Master'ı temel düzeyde kullanmak" | **powerpoint-ustasi** (Bölüm 8) |
| "Slide Master'da kendi düzen tasarlamak" | **bu skill** (Bölüm 1) |
| "Animasyon zincirinde tetikleyici (trigger)" | **bu skill** (Bölüm 4) |
| "PowerPoint makro yazmak" | **bu skill** (Bölüm 5) |
| "Excel verisinden otomatik sunum üretme" | **bu skill** (Bölüm 5.6) |
| "İnteraktif (klikli) eğitim sunumu" | **bu skill** (Bölüm 6) |
| "Kurum geneline tema dağıtmak" | **bu skill** (Bölüm 7) |
| "Section ile büyük sunumu yönetmek" | **bu skill** (Bölüm 2) |

---

## BÖLÜM 1: Slide Master ve Layout Tasarımı

### 1.1 Slide Master Hiyerarşisi

Çoğu kullanıcı Slide Master'ı **tek bir slayt** sanır. Aslında üç seviyeli yapıdır:

```
TEMA (.thmx)
  └─ SLIDE MASTER (sunumun anası)
       ├─ Title Slide Layout (kapak)
       ├─ Title and Content Layout (en sık kullanılan)
       ├─ Two Content Layout (iki sütun)
       ├─ Section Header Layout (bölüm girişi)
       └─ ... diğer layout'lar
```

**Master**: Tüm layout'ların **ortak** öğelerini tanımlar (kurum logosu, sayfa numarası).
**Layout**: Belirli slayt tipinin yapısını tanımlar (başlık nerede, içerik nerede).
**Slayt**: Bir layout'tan türetilir.

**Pratik fark:** Logoyu Master'a koyarsan **tüm layout'larda** görünür. Belirli bir layout'a (örn. kapak) koyarsan sadece o layout'tan türeyen slaytlarda görünür.

### 1.2 Master'ı Açma ve Düzenleme

**Görünüm → Slayt Ana Sayfası (Slide Master)**

Sol panelde Master ve altında layout'lar. **En üstteki büyük olan** Master'dır.

### 1.3 Yeni Layout Tasarlama — Profesyonel İş Akışı

Senaryo: Kurum sunumlarınız için "Veri Slaytı" layout'u tasarla. Solda 1/3'lük başlık/açıklama, sağda 2/3'lük grafik alanı, altta kaynak bilgisi.

**Adımlar:**

1. **Görünüm → Slayt Ana Sayfası**.
2. Sol panelde **Layout Ekle** düğmesine bas (Insert Layout). Yeni boş layout açılır.
3. Sağ tık → **Adlandır** → "Veri Slaytı".
4. **Yer Tutucu (Placeholder) ekle**:
   - **Master Layout → Yer Tutucu Ekle → Metin** → solda 1/3 alana çiz
   - Yer tutucunun **Properties**'inden başlık stili ata
5. **Yer Tutucu → Resim/İçerik** → sağda 2/3 alana çiz (grafiğin geleceği yer)
6. **Yer Tutucu → Metin** → altta dar şerit (kaynak için)
7. Master'ı kapat. **Yeni Slayt → Veri Slaytı** seçeneği gelir. Slayt eklendiğinde aynı düzen otomatik gelir.

### 1.4 Yer Tutucu Türleri

| Tür | Ne için |
|-----|---------|
| **Title** | Slayt başlığı |
| **Content** | Genel içerik (metin, tablo, grafik, video alabilir) |
| **Text** | Sadece metin |
| **Picture** | Resim |
| **Chart** | Grafik |
| **Table** | Tablo |
| **SmartArt** | SmartArt diyagram |
| **Media** | Video/ses |

İlk üçü ana kullanım. Diğerleri özelleşmiş layout'lar için.

### 1.5 Tema (.thmx) Oluşturma

Slide Master tek bir sunum içinde geçerli. **Tema** = Slide Master + renkler + fontlar + efektler paketinin **dışa aktarılmış** hâli. Başka sunumlarda kullanılabilir.

**Tasarım → Temalar → Geçerli Temayı Kaydet** → `.thmx` dosyası oluşur.

Tema dosyası şuralarda kullanılabilir:
- Yeni sunum açarken "Tema" olarak seç
- Mevcut sunumda **Tasarım → Tema → Tema Ara** ile uygula
- Word ve Excel'de de aynı renk/fontlarla çalış (Office tema dosyası evrensel)

### 1.6 Renk Şeması (Color Scheme)

Slide Master içinde **Renkler**: 12 ayrılmış renk vardır (Office standartı):

- 4 metin/arka plan rengi
- 6 vurgu rengi (Accent 1-6)
- 2 köprü rengi (Hyperlink, Followed Hyperlink)

Bu sistemin gücü: Slaytta bir grafiği "Accent 1" rengiyle çizdiysen, **renk şemasını değiştirdiğinde** grafik otomatik yeni renge döner. Manuel renk koyduysan değişmez.

**Kural:** Slaytta renk seçerken **doğrudan RGB değer girme** — Tema renklerinden seç. Şema değiştiğinde tüm sunum uyumlu kalır.

### 1.7 Font Şeması

Slide Master → **Fontlar** sekmesi. İki font tanımlanır:
- **Heading Font** (başlık) — örn. Montserrat
- **Body Font** (gövde) — örn. Open Sans

Sunumda yer tutucular **"+Heading"** ve **"+Body"** olarak tanımlıdır (özel ad gibi). Font şemasını değiştirdiğinde tüm slaytlar yeni fonta döner.

---

## BÖLÜM 2: Section (Bölüm) Yönetimi

### 2.1 Nedir?

50 slaytlık sunumda navigasyon zor. **Section** = slaytları **mantıksal gruplara** ayırır. Sol slayt panelinde gruplar görünür, açılır/kapanır.

### 2.2 Ekleme

Sol panelde iki slayt arasında **sağ tık → Bölüm Ekle (Add Section)**.

Bölüme ad ver:
- "Giriş"
- "Bulgular"
- "Mali Veriler"
- "Sonuçlar"
- "Ek Materyaller"

### 2.3 Kullanım Avantajları

- **Bölümleri sırala**: Tüm bir bölümü tek hamlede yeniden konumlandır
- **Bölümü gizle**: Sunumda gösterme (ama sil de)
- **Bölümü genişlet/daralt**: Slaytları hızlı gezin
- **Belirli bölümü sun**: F5 yerine sağ tık → "Bölümü Başlat"

### 2.4 Section + Custom Show

Section'ları **Custom Show** ile birleştirince güçlü olur (aşağıda Bölüm 6.3).

---

## BÖLÜM 3: SmartArt Ustalığı

### 3.1 SmartArt Nedir?

Şekiller + bağlantılar + otomatik düzen = SmartArt. Organizasyon şeması, süreç akışı, hiyerarşi, döngü için kullanılır.

### 3.2 Ekleme

**Ekle → SmartArt**. Kategoriler:
- **List** (sıralı liste)
- **Process** (süreç)
- **Cycle** (döngü)
- **Hierarchy** (organizasyon şeması)
- **Relationship** (ilişki)
- **Matrix** (matris)
- **Pyramid** (piramit)
- **Picture** (resim entegre)

### 3.3 İçerik Düzenleme — Doğru Yöntem

SmartArt eklendikten sonra solda **Metin Bölmesi** açılır. Burası SmartArt'ın **özüdür**.

- Madde yaz → bir şekil oluşur
- Tab tuşu → o şekli **alt seviyeye** indir
- Shift+Tab → üst seviyeye çıkar
- Enter → aynı seviyede yeni şekil

**Şekiller üzerinde tıklayıp tek tek yazma yöntemi yavaş ve hataya açık.** Metin bölmesini kullan.

### 3.4 Veriden SmartArt Üretme — Metin Listesinden Dönüşüm

Klasörde Word/PowerPoint'te hazır madde işaretli bir listen var mı? Direkt SmartArt'a dönüştür:

1. Listedeki maddeleri seç
2. **Giriş sekmesi → Madde işareti yanındaki ok → SmartArt'a Dönüştür**
3. Hangi düzen istediğini seç → otomatik şekiller oluşur

### 3.5 SmartArt'ın Renk ve Stilini Tema'ya Bağlı Tutma

SmartArt seçili → **SmartArt Tasarımı → Renkler** → "Temayla Uyumlu" seçeneklerinden birini al. Tema rengi değiştiğinde SmartArt da değişir.

### 3.6 SmartArt'tan Şekil Grubuna Dönüştürme

SmartArt'ın **yapısı kısıtlı** — istediğin gibi taşıyamazsın, biçimleyemezsin. İstediğin görünüme yaklaşınca:

SmartArt'a **sağ tık → Şekle Dönüştür**.

Artık her şekil tek tek seçilebilir, taşınabilir, biçimlenebilir. **Dezavantaj:** SmartArt mantığı kaybolur, otomatik düzen artık çalışmaz.

**İpucu:** Önce SmartArt ile **kabaca yap**, sonra şekle dönüştürüp **ince ayarı yap**. En verimli yaklaşım.

---

## BÖLÜM 4: Kompleks Animasyon

### 4.1 Animation Pane (Animasyon Bölmesi)

**Animasyonlar → Animasyon Bölmesi**. Slaytın tüm animasyonlarını **zaman çizgisi** üzerinde görür, sırayla düzenlersin.

Her animasyon bir satır. Sıra, başlangıç (tıkla, önceki ile, sonra), gecikme, süre, döngü ayarlanır.

### 4.2 Animasyon Türleri

| Tür | Renk | Ne yapar |
|-----|------|----------|
| **Entrance** (Giriş) | Yeşil | Nesnenin görünmesini sağlar |
| **Emphasis** (Vurgu) | Sarı | Mevcut nesneyi vurgular (büyüt, döndür) |
| **Exit** (Çıkış) | Kırmızı | Nesneyi gizler |
| **Motion Path** (Hareket Yolu) | Gri | Nesneyi belirlenmiş yolda hareket ettirir |

### 4.3 Trigger (Tetikleyici) — Etkileşimli Animasyon

Bir animasyonu **tıklamaya bağlı** çalıştırma. Tıklanan başka bir nesneyi tetikleyebilir.

**Senaryo:** Slayta 4 düğme koy. Her düğmeye tıklayınca farklı bir bilgi kutusu açılsın.

**Adımlar:**

1. 4 düğme + 4 bilgi kutusu çiz.
2. 4 bilgi kutusunu **gizle**: Her birine "Fade In" entrance animasyonu, sonra "Fade Out" exit animasyonu ekle.
3. Bilgi Kutusu 1'in entrance animasyonu seç → **Animasyon Bölmesi'nde sağ tık → Tetikleyici → Tıklama → Düğme 1**.
4. Bu durumda animasyon **sadece Düğme 1 tıklandığında** çalışır.
5. Aynı işlemi 4 kombinasyon için yap.

Sunum dururken kullanıcı **istediği düğmeye** tıklar, ilgili bilgi açılır. Sıralı değil, **etkileşimli** sunum.

### 4.4 Motion Path — Hareket Yolu

Nesneyi belirlediğin yol üzerinde hareket ettir.

**Animasyonlar → Daha Fazla Hareket Yolu** → eğri, daire, sekiz şekli vs.

**Özel yol çizmek:** "Custom Path" → fareyle çiz, çift tıklayıp bitir.

**Pratik kullanım:**
- Bir okun şehirden şehre uçtuğunu göstermek (Türkiye haritası üzerinde)
- Bir sayının grafikte hareket ettiğini göstermek
- Bir araba ikonu yola gitsin

### 4.5 Animasyon Zinciri — Üst Düzey Senaryo

Tek bir tıklamayla **birden fazla animasyon arka arkaya** çalışsın:

Animasyonları "**Tıklama**" yerine "**Önceki ile**" veya "**Sonraki olarak**" başlat. Tıklayınca zincir başlar:

1. Başlık görünür (0.5 sn)
2. Hemen ardından grafik (1 sn)
3. Sonra ok beliriyor (0.5 sn)
4. Ok grafiğin üzerinde sallanıyor (Emphasis, 1 sn)
5. Sayı yukarı çıkıyor (Motion Path, 1 sn)

Toplam 4 saniyelik canlandırma, tek tıklama. **Eğitim ve TED tipi sunumlar** bu mantıkla yapılır.

### 4.6 Animasyon Yasakları (Tekrarla)

- **Spin (Döndürme)** — başınızı döndürür
- **Bounce (Zıplama)** — çocuksu
- **Pulse aşırı kullanım** — gözü yorar
- **Tüm slayttaki nesneye animasyon** — kaos

**Profesyonel kural:** Bir slaytta **en fazla 3-4** animasyon. Daha fazlası anlamı boğar.

### 4.7 Animasyonu Kopyalama

Bir nesneye verdiğin animasyonu başka nesneye uygulama:

1. Animasyonlu nesneyi seç
2. **Animasyon Boyacısı** (Animasyonlar → Animasyon Boyacısı) düğmesine tıkla
3. Hedef nesneye tıkla → animasyon kopyalanır

Aynı slaytta 10 nesneye aynı animasyon vermek için: ilkini ayarla, **Animasyon Boyacısı'na çift tıkla** (kilitler), 10 nesneye tıkla, Esc'le bırak.

---

## BÖLÜM 5: PowerPoint VBA

### 5.1 Geliştirici Sekmesi ve Editor

Word ve Excel ile aynı:

**Dosya → Seçenekler → Şeridi Özelleştir → Geliştirici** açık.
**Alt+F11** ile VBA Editör.

### 5.2 PowerPoint Nesne Modeli

```vba
' Aktif sunum
ActivePresentation
ActivePresentation.Slides.Count

' Slayt
ActivePresentation.Slides(1)
ActivePresentation.Slides(1).Shapes.Count

' Slaytdaki şekil
ActivePresentation.Slides(1).Shapes(1).TextFrame.TextRange.Text

' Yeni slayt ekle
Dim s As Slide
Set s = ActivePresentation.Slides.Add(1, ppLayoutTitle)
```

### 5.3 Toplu Şekil Ayarı — Pratik

Senaryo: Sunumda tüm başlık fontunu değiştirmek istiyorsun, ama Slide Master'a dokunamayacaksın (eski sunum). Tek seferde:

```vba
Sub TumBasliklarFontuDegistir()
    Dim s As Slide
    Dim sh As Shape
    
    For Each s In ActivePresentation.Slides
        For Each sh In s.Shapes
            If sh.HasTextFrame Then
                If sh.TextFrame.HasText Then
                    ' Yer tutucu mu ve Title mı?
                    If sh.Type = msoPlaceholder Then
                        If sh.PlaceholderFormat.Type = ppPlaceholderTitle Or _
                           sh.PlaceholderFormat.Type = ppPlaceholderCenterTitle Then
                            sh.TextFrame.TextRange.Font.Name = "Montserrat"
                            sh.TextFrame.TextRange.Font.Bold = msoTrue
                        End If
                    End If
                End If
            End If
        Next sh
    Next s
End Sub
```

### 5.4 Bul ve Değiştir (Toplu)

```vba
Sub TopluDegistir()
    Dim s As Slide
    Dim sh As Shape
    
    For Each s In ActivePresentation.Slides
        For Each sh In s.Shapes
            If sh.HasTextFrame Then
                If sh.TextFrame.HasText Then
                    sh.TextFrame.TextRange.Text = _
                        Replace(sh.TextFrame.TextRange.Text, _
                                "[KURUM]", "Genel Müdürlük")
                End If
            End If
        Next sh
    Next s
End Sub
```

### 5.5 Slayt Notlarını Toplu İşleme

```vba
Sub NotlariYazdir()
    Dim s As Slide
    For Each s In ActivePresentation.Slides
        Debug.Print "Slayt " & s.SlideIndex & ": " & _
            s.NotesPage.Shapes.Placeholders(2).TextFrame.TextRange.Text
    Next s
End Sub
```

### 5.6 Excel'den PowerPoint Üretme — Otomatik Rapor

EBYS bağlamında en kıymetli senaryo. Excel'de aylık veriler — her ay otomatik 20 slaytlık sunum üretiliyor.

```vba
Sub AylikRaporUret()
    On Error GoTo HataYakala
    
    ' Şablon
    Dim sablonYolu As String
    sablonYolu = "C:\Sablonlar\AylikRaporSablonu.potx"
    
    ' Excel verisi
    Dim xlApp As Object, xlKitap As Object, xlSayfa As Object
    Set xlApp = CreateObject("Excel.Application")
    Set xlKitap = xlApp.Workbooks.Open("C:\Veriler\AylikVeri.xlsx")
    Set xlSayfa = xlKitap.Worksheets("Ozet")
    
    ' Yeni sunum şablondan
    Dim sunum As Presentation
    Set sunum = Presentations.Open(sablonYolu, untitled:=msoTrue)
    
    ' --- Slayt 1: Kapak ---
    Dim s As Slide
    Set s = sunum.Slides(1)
    s.Shapes.Title.TextFrame.TextRange.Text = _
        xlSayfa.Range("B1").Value & " Aylık Rapor"
    
    ' Tarih
    s.Shapes("Tarih").TextFrame.TextRange.Text = Format(Date, "dd MMMM yyyy")
    
    ' --- Slayt 2: Özet sayılar ---
    Set s = sunum.Slides(2)
    s.Shapes("SayiToplam").TextFrame.TextRange.Text = _
        Format(xlSayfa.Range("B5").Value, "#,##0")
    s.Shapes("SayiAylik").TextFrame.TextRange.Text = _
        Format(xlSayfa.Range("B6").Value, "#,##0")
    s.Shapes("Yuzde").TextFrame.TextRange.Text = _
        Format(xlSayfa.Range("B7").Value, "0.0%")
    
    ' --- Slayt 3: Veri tablosu (Excel'den kopyala) ---
    xlSayfa.Range("A10:E25").Copy
    sunum.Slides(3).Shapes.PasteSpecial DataType:=ppPasteEnhancedMetafile
    
    ' --- Slayt 4: Grafik ---
    xlSayfa.ChartObjects(1).Activate
    xlSayfa.ChartObjects(1).Chart.ChartArea.Copy
    sunum.Slides(4).Shapes.PasteSpecial DataType:=ppPasteEnhancedMetafile
    
    ' Kaydet
    Dim cikti As String
    cikti = "C:\Raporlar\" & Format(Date, "yyyy-mm") & "_Aylik_Rapor.pptx"
    sunum.SaveAs cikti
    
    xlKitap.Close False
    xlApp.Quit
    Set xlApp = Nothing
    
TemizCikis:
    MsgBox "Aylık rapor üretildi: " & cikti, vbInformation
    Exit Sub

HataYakala:
    MsgBox "Hata: " & Err.Description, vbCritical
    Resume TemizCikis
End Sub
```

**Şablonun anahtar fikri:** Şablon hazırlanırken her doldurulacak yer tutucuya **özel ad** verilir (sağ tıktan **Shape Adı** > Seçim Bölmesi (Alt+F10) ile görünür). Makro o adla bulur, içeriği yazar.

### 5.7 PDF ve Video Çıktı

```vba
' PDF olarak kaydet
sunum.ExportAsFixedFormat _
    Path:="C:\Cikti\Rapor.pdf", _
    FixedFormatType:=ppFixedFormatTypePDF

' MP4 video olarak (sunum çalan video)
sunum.CreateVideo _
    FileName:="C:\Cikti\Rapor.mp4", _
    UseTimingsAndNarrations:=True, _
    DefaultSlideDuration:=5, _
    VertResolution:=1080, _
    FramesPerSecond:=30, _
    Quality:=85
```

### 5.8 Slayt Üretme — Dinamik

Tek bir layout'tan **Excel'deki satır sayısı kadar** slayt üretme:

```vba
Sub PersonelSlaytlariUret()
    Dim xlApp As Object, xlKitap As Object, xlSayfa As Object
    Set xlApp = CreateObject("Excel.Application")
    Set xlKitap = xlApp.Workbooks.Open("C:\Veriler\Personel.xlsx")
    Set xlSayfa = xlKitap.Worksheets("Liste")
    
    Dim sonSatir As Long
    sonSatir = xlSayfa.Cells(xlSayfa.Rows.Count, 1).End(-4162).Row
    
    Dim sunum As Presentation
    Set sunum = ActivePresentation
    
    ' Slayt 1 zaten var (şablon olarak), kalanları üret
    Dim layout As CustomLayout
    Set layout = sunum.Slides(1).CustomLayout
    
    Dim i As Long
    For i = 2 To sonSatir
        Dim s As Slide
        Set s = sunum.Slides.AddSlide(sunum.Slides.Count + 1, layout)
        
        ' Yer tutucuları doldur
        s.Shapes.Title.TextFrame.TextRange.Text = _
            xlSayfa.Cells(i, 2).Value & " " & xlSayfa.Cells(i, 3).Value
        
        ' Diğer şekiller — adla erişim
        On Error Resume Next
        s.Shapes("Unvan").TextFrame.TextRange.Text = xlSayfa.Cells(i, 4).Value
        s.Shapes("Birim").TextFrame.TextRange.Text = xlSayfa.Cells(i, 5).Value
        s.Shapes("Sicil").TextFrame.TextRange.Text = xlSayfa.Cells(i, 6).Value
        On Error GoTo 0
    Next i
    
    xlKitap.Close False
    xlApp.Quit
    
    MsgBox (sonSatir - 1) & " personel slaytı üretildi", vbInformation
End Sub
```

---

## BÖLÜM 6: İnteraktif Sunum Tasarımı

### 6.1 Hyperlink (Köprü)

Bir nesneyi tıklayınca başka slayda atlat:

1. Nesneyi seç
2. **Ekle → Köprü** (veya Ctrl+K)
3. **Bu Belge** sekmesi → hedef slaydı seç
4. Tamam

Tıklanabilir öğeler: Metin kutusu, şekil, resim, düğme.

### 6.2 Action Buttons (Eylem Düğmeleri)

Hazır navigasyon düğmeleri (önceki, sonraki, ev, geri):

**Ekle → Şekiller → Eylem Düğmeleri** → seç → slayda çiz → otomatik dialog: "Tıklayınca → İlk Slaytı Göster" vb.

Eğitim sunumlarında "Ana Menüye Dön" düğmesi olmazsa olmaz.

### 6.3 Custom Show

50 slaytlık sunumdan **alt kümeler** oluştur:

**Slayt Gösterisi → Özel Slayt Gösterisi → Yeni**

Hangi slaytları dahil edeceğini seç, ad ver: "Yöneticilere Sunum" — 12 slayt.

**Pratik:**
- Bütün veriyi tek sunumda topla
- Farklı dinleyici için farklı custom show
- Tek dosya, çoklu sunum

Hyperlink ile custom show'a bağlanır: Köprü → "Bu Belge" → "Özel Slayt Gösterileri" → biri seç.

### 6.4 Karar Ağacı Sunumu (Branching)

Eğitim modülünde "Doğru mu Yanlış mı?" tipi:

```
Soru 1: ... (Slayt 3)
   ├ Doğru   → Slayt 4 (tebrik)
   └ Yanlış  → Slayt 5 (açıklama + Slayt 3'e dön)
```

Her cevap düğmesinin hyperlink'i farklı slayda. Slayt 5'te "Tekrar Dene" düğmesi → Slayt 3'e döner.

**Üst düzey kullanım:** PowerPoint'i interaktif e-öğrenme aracına çevirir. **Articulate Storyline** veya **iSpring** gibi araçların yaptığı işin temelini PowerPoint zaten sağlar.

### 6.5 Kiosk Modu (Sürekli Tıklamasız Sunum)

Stand'da çalışan, kendi kendine ilerleyen sunum:

**Slayt Gösterisi → Slayt Gösterisi Ayarla → Bir Kioskta İncelendi (tam ekran)**.

Her slaytın **otomatik geçiş süresi** ayarlı olmalı (Geçişler → Süre → 5 saniye).

Sunum sonsuza kadar döngüde çalar. Fuar, müze, lobi ekranı için kullanılır.

### 6.6 Ses ve Video Gömme

**Ekle → Video** → seç → **Slaytta** veya **Dosyaya Bağla**.

| Yöntem | Avantaj | Dezavantaj |
|--------|---------|------------|
| **Slaytta** (Gömülü) | Sunum tek dosyada taşınabilir | Dosya büyür |
| **Bağlı** | Sunum dosyası küçük | Video yoksa çalışmaz |

**Kurumsal sunum için:** Gömülü tercih edilir. Sunum dosyasını başka bilgisayara taşıdığında video da geliyor.

**Sıkıştırma:** **Dosya → Bilgi → Medyayı Sıkıştır** → düşük kalite seç (sunum için yeterli).

---

## BÖLÜM 7: Şablon ve Tema Dağıtımı

### 7.1 .potx vs .potm

| Uzantı | İçerir | Kullanım |
|--------|--------|----------|
| **.pptx** | Normal sunum | Çıktı |
| **.potx** | Şablon (içerik + biçim) | Kullanıcı türetir |
| **.potm** | Şablon + makro | Otomasyonlu şablon |
| **.thmx** | Sadece tema (renk, font, master) | Office geneli kullanılır |

### 7.2 Kurumsal Şablon Hazırlama

1. Yeni sunum aç
2. **Slide Master**'ı kurumsal kimliğe göre tasarla:
   - Logo yerleştir
   - Renk şeması seç (kurumsal renkler)
   - Font şeması seç
   - Layout'ları tasarla (kapak, içerik, bölüm girişi, veri slaytı, kapanış)
3. Birkaç **örnek slayt** ekle (kullanıcıya rehber olsun)
4. **Dosya → Farklı Kaydet → Tür: PowerPoint Şablonu (.potx)**

### 7.3 Şablon Yerleşim Klasörü

`%AppData%\Microsoft\Templates\` — Kullanıcının kişisel şablonları.

Kurumsal:
- Ortak ağ paylaşımı: `\\sunucu\sablonlar\KurumSablonu.potx`
- Ya da her kullanıcının yereline kopyala (logon script, GPO)

### 7.4 Tema Dağıtımı

Tema (.thmx) Office'in tüm uygulamalarında geçerli:

1. PowerPoint'te tasarla (Slide Master + renkler + fontlar)
2. **Tasarım → Geçerli Temayı Kaydet** → `.thmx`
3. Dosyayı: `%AppData%\Microsoft\Templates\Document Themes\` klasörüne koy
4. Word ve Excel'de **Sayfa Düzeni → Temalar** menüsünde de görünür

Tek tema = Word + Excel + PowerPoint'te aynı renkler, fontlar.

### 7.5 Şerit Özelleştirme — Kurum Sekmesi (PowerPoint)

`customUI14.xml` (Office Custom UI Editor):

```xml
<customUI xmlns="http://schemas.microsoft.com/office/2009/07/customui">
  <ribbon>
    <tabs>
      <tab id="KurumSekmesi" label="Kurum Sunumları">
        <group id="grpSablon" label="Şablonlar">
          <button id="btnYeniRapor"
                  label="Aylık Rapor"
                  size="large"
                  imageMso="FileNew"
                  onAction="cmdYeniRapor"/>
          <button id="btnYeniBrifing"
                  label="Brifing"
                  size="large"
                  imageMso="MailMergeStartMailMerge"
                  onAction="cmdYeniBrifing"/>
        </group>
        <group id="grpAraclar" label="Araçlar">
          <button id="btnExceldenUret"
                  label="Excel'den Üret"
                  imageMso="ImportExcel"
                  onAction="cmdExceldenUret"/>
          <button id="btnPDFCikar"
                  label="PDF Çıkar"
                  imageMso="ExportPdf"
                  onAction="cmdPDFCikar"/>
          <button id="btnTemizleNotlar"
                  label="Notları Temizle"
                  imageMso="ReviewDeleteComment"
                  onAction="cmdTemizleNotlar"/>
        </group>
      </tab>
    </tabs>
  </ribbon>
</customUI>
```

VBA tarafında:

```vba
Sub cmdYeniRapor(control As IRibbonControl)
    Presentations.Open "\\sunucu\sablonlar\AylikRapor.potx", untitled:=msoTrue
End Sub

Sub cmdExceldenUret(control As IRibbonControl)
    AylikRaporUret   ' Yukarıdaki Bölüm 5.6'daki makro
End Sub
```

### 7.6 Add-in (.ppam) ile Dağıtım

PowerPoint Add-in uzantısı **.ppam**:

1. Makrolu sunum hazırla
2. **Dosya → Farklı Kaydet → PowerPoint Eklentisi (.ppam)**
3. Kullanıcıda yükletmek için:
   - **Dosya → Seçenekler → Eklentiler → Yönet: PowerPoint Eklentileri → Git** → Ekle → .ppam seç

PowerPoint açılışlarında otomatik yüklenir.

---

## BÖLÜM 8: Şekil Yerleştirme ve Hizalama

### 8.1 Seçim Bölmesi (Selection Pane)

**Alt+F10** veya **Giriş → Düzenle → Seç → Seçim Bölmesi**.

Slayttaki tüm şekilleri **adlandırılmış liste** olarak gösterir. Şekiller üst üste binince fareyle seçmek zor — bu bölmeden seç.

**Şekle Ad Verme:** Listede şekle çift tıkla → ad yaz.

**Pratik:** Makroda şekle "Title" yerine "AnaSayi" gibi ad veririz → kod okunaklı olur.

### 8.2 Hizalama Araçları

Birden fazla şekil seç → **Şekil Biçimi → Hizala**:

- Sola, ortaya, sağa hizala
- Üste, ortaya, alta hizala
- **Yatay dağıt** (eşit aralık)
- **Dikey dağıt** (eşit aralık)
- Slayda göre / seçilenlere göre

**Profesyonel sunumda "el yordamıyla" hizalama olmaz** — bu araçlar kullanılır.

### 8.3 Akıllı Kılavuzlar

PowerPoint sürükleme sırasında **kırmızı çizgilerle** hizalamayı gösterir. Otomatik snap eder.

Sürükleme sırasında **Alt** tuşu basılı tutarsan kılavuz devre dışı (piksel piksel ayar).

### 8.4 Şekil Sırası (Z-Order)

Şekil → sağ tık → **En Öne Getir / En Arkaya Gönder / Bir Önce / Bir Sonra**.

Üst üste binmiş şekillerde hangisinin görüneceğini belirler.

### 8.5 Şekil Birleştirme (Merge Shapes)

Birden fazla şekil seç → **Şekil Biçimi → Şekilleri Birleştir**:

- **Birleştir (Union):** İki şeklin birleşik formu
- **Birleştir Çıkar (Combine):** Kesişen kısım dışındakiler
- **Parçala (Fragment):** Tüm parçaları ayrı ayrı
- **Kesiştir (Intersect):** Sadece ortak alan
- **Çıkar (Subtract):** İlkinden ikinciyi çıkar

**Pratik:** Türkiye haritasında bir şehri vurgulamak için → "Çıkar" işlemiyle deliği oluştur, bir alttaki şekli renklendirip vurgu yap.

Bu özellik **özel ikon üretmenin de yolu** — basit şekillerden karmaşık ikon kurarsın, **PNG ile dışa aktarmaya** gerek kalmaz.

---

## BÖLÜM 9: Modüler Mimari (PowerPoint VBA)

### 9.1 Modül Ayrımı

| Modül | İçeriği |
|-------|---------|
| `mod_Ana` | Şerit düğmelerinin Sub'ları |
| `mod_SunumUretici` | Yeni sunum üretme mantığı |
| `mod_ExcelKopru` | Excel ile veri alışverişi |
| `mod_Bicim` | Stil/font/renk uygulama yardımcıları |
| `mod_Cikti` | PDF, video, resim çıkarma |
| `mod_Ayarlar` | Şablon yolları, kurumsal sabitler |
| `mod_Log` | Log yazma |

### 9.2 Hata Yönetimi

```vba
Sub AnaIslem()
    On Error GoTo HataYakala
    
    Application.ScreenUpdating = False   ' Var ama sınırlı etki (PPT'de Excel'deki gibi güçlü değil)
    
    ' --- Asıl iş ---
    
TemizCikis:
    Application.ScreenUpdating = True
    Exit Sub

HataYakala:
    Loga "HATA: " & Err.Number & " - " & Err.Description
    MsgBox "Hata: " & Err.Description, vbCritical
    Resume TemizCikis
End Sub
```

**Not:** PowerPoint'te `ScreenUpdating` Excel'deki kadar etkili değil. PowerPoint görseli yoğun bir uygulama, makro yavaşken kullanıcıya bekleme göstermek için **Application.StatusBar** kullanılabilir, ama sınırlı.

### 9.3 Ayarlar Modülü

```vba
' --- mod_Ayarlar ---
Public Const VERSIYON As String = "2026.1.0"
Public Const SABLON_KLASORU As String = "\\sunucu\sablonlar\PPT\"
Public Const CIKTI_KLASORU As String = "C:\PPT_Cikti\"

Public Const SABLON_AYLIK_RAPOR As String = "AylikRapor.potx"
Public Const SABLON_BRIFING As String = "Brifing.potx"

' Kurumsal renkler (RGB long olarak)
Public Const RENK_LACIVERT As Long = 4153152      ' RGB(0, 63, 135)
Public Const RENK_ACIK_MAVI As Long = 14001755    ' RGB(91, 155, 213)
Public Const RENK_SARI As Long = 49407            ' RGB(255, 192, 0)
Public Const RENK_KOYU_GRI As Long = 2236962      ' RGB(34, 34, 34)
```

---

## Kontrol Listesi — Üretim Hazır Şablon

Bir şablonu kuruma dağıtmadan önce:

- [ ] **Slide Master** tasarlandı mı (logo, sayfa no, alt bilgi)?
- [ ] **Layout'lar** tanımlandı mı (kapak, içerik, veri, bölüm girişi)?
- [ ] **Renk şeması** tema renklerine bağlı mı (manuel RGB değil)?
- [ ] **Font şeması** tanımlı mı (+Heading, +Body)?
- [ ] **Örnek slaytlar** eklendi mi (kullanıcı için referans)?
- [ ] Şablon **.potx** olarak kaydedildi mi?
- [ ] Tema **.thmx** olarak ayrıca kaydedildi mi?
- [ ] **Section** yapısı tanımlı mı (büyük sunumda)?
- [ ] Şablondan **test sunumu** oluşturulup tüm layout'lar denendi mi?
- [ ] Makrolu şablon ise **VBA Project parolası** ekli mi?
- [ ] **18 puntodan küçük yazı** yok mu?
- [ ] **Türkçe karakter** test edildi mi (ç, ğ, ı, ö, ş, ü)?
- [ ] **PDF çıktısı** alındı, doğru göründü mü?
- [ ] Şablonun **yedeği** alındı mı?

---

## Sık Yapılan Hatalar

| Hata | Belirti | Çözüm |
|------|---------|-------|
| Doğrudan RGB renk | Tema değişince renk uyumsuz | Tema renklerinden seç (Accent 1-6) |
| Slide Master yerine elle biçim | Tutarsızlık, değiştirmek çok zor | Master'ı doğru kur, slaytları temizle |
| Yer tutucu yerine metin kutusu | Layout otomatik düzeni bozuluyor | Yeni Slayt → uygun layout, yer tutucuya yaz |
| SmartArt zorla biçimlendirme | Otomatik düzen bozuluyor | Şekle dönüştür, sonra elle biçimle |
| Makro çalışmıyor | "Bu içerik makro çalıştıramaz" uyarısı | .pptm/.potm uzantıyla kaydet (.pptx makro saklamaz) |
| Video gömülü ama oynamıyor | Codec sorunu | MP4 H.264 formata dönüştür |
| Animasyon abartısı | Sunum sırasında gözü yorucu | Slayt başına 3-4 ile sınırla, Fade dışında çoğunu çıkar |
| Türkçe karakter font'ta bozuk | Bazı fontlarda ş, ğ yok | Türkçe destekli font seç (Open Sans, Calibri, Montserrat) |
| Sunum başka makinede font değişiyor | Font sistem değişti | Dosya → Seçenekler → Kaydet → "Fontları gömerek kaydet" işaretle |
| 50 slaytlık sunumda navigasyon | Yön kaybediliyor | Section yapısı kur |

---

## Hangi Aracı Ne Zaman Kullan?

| Durum | Tavsiye |
|-------|---------|
| Tek seferlik sunum | Doğrudan yap |
| Aynı kalıpta tekrar eden sunum | Şablon (.potx) |
| Aynı sunum, farklı içerik (aylık) | Şablon + adlı yer tutucular + VBA |
| Excel verisinden üretim | VBA + Excel.Application + Slides.AddSlide |
| 30 kişiye dağıtım, görsel kimlik | Tema (.thmx) + Şablon (.potx) ortak klasörden |
| Otomasyon + kurumsal dağıtım | Add-in (.ppam) + Custom Ribbon |
| Eğitim sunumu (interaktif) | Hyperlink + Custom Show + Trigger animasyon |
| Fuar/stand sunumu | Kiosk modu + zamanlanmış geçiş |
| Karmaşık akış (TED tipi) | Animation Pane + Trigger + Motion Path |
| 50+ slaytlık sunum | Section + Custom Show |

---

## Son Söz

PowerPoint'i iyi kullanan kişi, sunumu **birden fazla kez** kullanır. Aynı emeği iki kez vermek istemez.

Her ay tekrarlanan rapor: Şablon kur, makro yaz, Excel'i kaynağa al — 2 dakikada üretim. Memurun "şu sunumu hazırlasana" diye gelmesini bekleme; otomasyon her ay tıkır tıkır çalışır.

Sunumu sade tutan zaten powerpoint-ustasi skill'inde anlatıldı. Bu skill'in iddiası şudur: **Sade ve etkili sunumu sistematik olarak üretmek.**

Tasarımı bir kez yap, üretimi sonsuz kez yap.
