# sinav-imza-sirkusu

---
name: "sinav-imza-sirkusu"
description: "Nurhak'taki direksiyon eğitimi uygulama sınavları ve MTSK sınavları için MEB başlıklı Görevli Personel Listesi (imza sirküsü) hazırlarken kullan."
---

# Sınav Görevli Personel Listesi (İmza Sirküsü)

Direksiyon eğitimi dersi uygulama sınavları ve MTSK sınavları için hazırlanan imza sirkülerinin standardıdır. Referans düzen: **12.09.2026 Nurhak listesi**. MTSK listeleri de aynı düzende hazırlanır.

Birlikte çalışan skill'ler: tablo için `excel-temel` veya Word için `word-ileri`; başlık metinleri için `kurumsal-turkce-yazim`.

## 1. Kaynaklar

1. **MEBBİS / SIM06003 ekran çıktısı:** sınav tarihi, sınav yeri ve görevli personelin (komisyon başkanı, üyeler vb.) bilgileri buradan alınır.
2. **Emniyetten gelen "Personel Bilgileri" belgesi:** güvenlik görevlisi satırları yalnızca bu belgeden doldurulur.

İki kaynaktaki bilgiler birleştirilir; bir kaynakta olmayan bilgi uydurulmaz, yer tutucu bırakılır ve teslimde belirtilir.

## 2. Belge düzeni

- MEB başlıklı resmî liste: `T.C.` / `MİLLÎ EĞİTİM BAKANLIĞI` (ve referans listedeki alt başlıklar).
- Belge adı: **GÖREVLİ PERSONEL LİSTESİ**; sınav türü (direksiyon / MTSK), sınav tarihi ve yeri.
- Tablo sütunları referans listedeki sırayla korunur (sıra no, ad soyad, görev / unvan, kurum, imza vb.). İmza sütunu boş bırakılır.
- Güvenlik görevlisi satırları tablonun sonunda, emniyet belgesindeki sırayla.
- **Sağ alt köşe**, alt alta: tarih → ad soyad → `İlçe Millî Eğitim Müdürü`. Ad soyad olarak o tarihteki görevli müdür yazılır; kullanıcı belirtmezse hafızadaki güncel kayıt kullanılır ve teslimde tek satırla teyit istenir (müdür vekâleti değişebilir).

## 3. Biçim kuralları

- Ad soyad: ad ilk harfi büyük, soyadı tamamen büyük (İsmail ŞAHAN).
- T.C. kimlik numarası gibi kişisel veriler, kaynak çıktıda bulunsa bile **kullanıcı açıkça istemedikçe listeye konmaz**.
- Tarih `GG.AA.YYYY`.
- Tek sayfa hedeflenir; sığmazsa ikinci sayfada tablo başlık satırı tekrarlanır.

## 4. Teslim öncesi kontrol

- [ ] SIM06003'teki tüm görevliler listede, eksik veya fazla kişi yok
- [ ] Güvenlik görevlileri emniyet belgesiyle birebir aynı
- [ ] Sağ alt blok sırası doğru (tarih, ad soyad, unvan)
- [ ] İmza sütunu boş
- [ ] Düzen 12.09.2026 referans listesiyle aynı
