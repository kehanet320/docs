# pdf-ustasi

---
name: pdf-ustasi
description: PDF dosyalarıyla profesyonel düzeyde her türlü işlemin ustası. Kullanıcı "PDF oluştur", "PDF birleştir", "PDF böl", "PDF doldur", "form alanı", "PDF'e imza", "PDF filigran", "PDF şifrele", "OCR", "taranmış PDF", "PDF içindekiler", "PDF/A", "imzalı PDF", "PDF dijital imza", "akrobat", "form PDF", "interaktif PDF", "yer imi", "sayfa numarası", "PDF rapor", "çok sayfalı PDF" gibi ifadeler kullandığında devreye girer. Form PDF tasarımı, çok sayfalı kurumsal raporlar, PDF düzenleme, OCR, dijital imza, PDF/A arşivleme — hepsi modüler bölümler hâlinde.
---

# PDF Ustası — Kapsamlı Rehber

## Genel İlke

PDF, **dijital basılı belge** standardıdır. Word'den farkı: **her görüntülemede aynı görünür**, font/yerleşim değişmez. Bu yüzden:

- **Resmî yayınlama** için PDF kullanılır (Word değil)
- **Form dağıtımı** için PDF kullanılır
- **Arşiv** için PDF/A kullanılır
- **Dijital imza** için PDF kullanılır

Bu skill 5 ana modülden oluşur. İhtiyaca göre ilgili bölüme atla:

1. [Çok Sayfalı PDF Raporlar](#bölüm-1-çok-sayfalı-pdf-raporlar)
2. [Form Doldurulabilir İnteraktif PDF](#bölüm-2-form-doldurulabilir-interaktif-pdf)
3. [PDF Düzenleme (Birleştirme, Bölme, vb.)](#bölüm-3-pdf-düzenleme)
4. [OCR ve Taranmış PDF](#bölüm-4-ocr-ve-taranmış-pdf)
5. [PDF Güvenlik ve Dijital İmza](#bölüm-5-güvenlik-ve-dijital-imza)

Bu skill `pdf` resmi skill'iyle birlikte çalışır: O **dosya üretim altyapısını** sağlar (Python script'leri), bu skill **profesyonel teknikleri ve standartları** anlatır.

---

## BÖLÜM 1: Çok Sayfalı PDF Raporlar

### 1.1 Profesyonel Rapor Yapısı

Resmî bir rapor genelde şu sırayı takip eder:

```
1. Kapak Sayfası (sayfa numarası YOK)
2. İç Kapak (logo, kurum adı, başlık, tarih)
3. Önsöz / Sunuş
4. İçindekiler (sayfa numaraları i, ii, iii)
5. Şekil ve Tablo Listesi
6. Kısaltmalar Listesi
7. Yönetici Özeti
8. ANA METİN (sayfa numaraları 1, 2, 3...)
   - 1. Giriş
   - 2. Yöntem
   - 3. Bulgular
   - 4. Tartışma
   - 5. Sonuç ve Öneriler
9. Kaynakça
10. Ekler (A-1, A-2, B-1...)
```

### 1.2 Sayfa Numarası Stratejisi

| Bölüm | Numaralandırma |
|-------|----------------|
| Kapak, iç kapak | Numara YOK |
| Ön sayfalar (önsöz, içindekiler) | Roma rakamı küçük (i, ii, iii) |
| Ana metin | Arap rakamı (1, 2, 3) |
| Ekler | Harf-sayı (A-1, A-2) |

Bu yapı için Word'de **bölüm sonları** kullanılır, sonra PDF'e çevrilir.

### 1.3 İçindekiler Tablosu (Otomatik)

PDF içindekiler tablosu **iki seviyede** çalışır:

**Görsel içindekiler** — Sayfada görünen tablo, sayfa numaralarıyla.

**PDF Yer İmleri (Bookmarks)** — PDF okuyucusunun **sol tarafında** açılan navigasyon ağacı. **Bu, profesyonel PDF'in olmazsa olmazıdır.**

#### Yer İmi Oluşturma

- **Word'den PDF'e çevirirken**: "Yer imleri oluştur" seçeneğini açın → Başlık 1, 2, 3 stillerinden otomatik yer imi oluşur.
- **PDF'te manuel**: PDF düzenleyicide (Adobe Acrobat, Foxit, vb.) → Yer İmi panelinde sayfa seçip "Yer İmi Ekle"

### 1.4 Üst Bilgi / Alt Bilgi (Header / Footer)

Profesyonel raporda **her sayfada** olması gerekenler:

**Üst Bilgi:**
- Kurum adı (sol)
- Bölüm/başlık (sağ)

**Alt Bilgi:**
- "Sayfa X / Y" (orta)
- Belge kodu (sol)
- Tarih (sağ)

### 1.5 Görsel ve Tablo Numaralandırma

```
Tablo 1.1: 2026 Yılı Bütçe Dağılımı
Tablo 1.2: Önceki Yıllarla Karşılaştırma
...
Tablo 2.1: Personel Sayıları

Şekil 1.1: Organizasyon Şeması
Şekil 1.2: Süreç Akışı
```

**1.1 = 1. bölüm 1. tablo** — bölüm bazlı numaralandırma, 50+ sayfalık raporlarda kayıp olmasını engeller.

### 1.6 Yazı Tipi ve Boyut Standartları

| Eleman | Font | Boyut |
|--------|------|-------|
| Ana metin | Times New Roman / Calibri | 11-12 pt |
| Başlık 1 | Aynı veya kontrast | 16-18 pt, kalın |
| Başlık 2 | Aynı | 14 pt, kalın |
| Başlık 3 | Aynı | 12 pt, kalın |
| Tablo metni | Aynı | 9-10 pt |
| Dipnot | Aynı | 9 pt |
| Üst/alt bilgi | Aynı | 9-10 pt |

### 1.7 Kenar Boşlukları

Resmi rapor için klasik:
- **Üst:** 2.5 cm
- **Alt:** 2.5 cm
- **Sol:** 3.0 cm (ciltleme için biraz fazla)
- **Sağ:** 2.0 cm

### 1.8 Kontrol Listesi: Kurumsal Rapor PDF

- [ ] Kapakta **kurum logosu** ve **belge tarihi** var mı?
- [ ] **Yer imleri (bookmarks)** ekli mi?
- [ ] **İçindekiler** sayfa numaralarıyla doğru mu?
- [ ] **Üst/alt bilgi** her sayfada uygun mu (kapakta yok)?
- [ ] **Tablo ve şekil numaraları** tutarlı mı?
- [ ] **Sayfa numaralandırma** doğru bölümlerde (i,ii,iii vs 1,2,3) mi?
- [ ] **Türkçe karakterler** her yerde doğru mu (font kontrol)?
- [ ] **Linkler** çalışıyor mu (kaynaklara, web'e)?

---

## BÖLÜM 2: Form Doldurulabilir İnteraktif PDF

### 2.1 Form PDF Nedir?

Kullanıcının PDF içine **doğrudan veri girebileceği** belge. Yazıcıdan basıp elle dolduran kâğıt formun dijital versiyonu.

**Kullanım alanları:**
- Resmi başvuru formları (vergi, sosyal güvenlik)
- İzin/talep dilekçeleri
- Anketler
- Sözleşme şablonları (kişi bilgisi doldurulup imzalanan)
- Personel formları

### 2.2 Form Alanı Türleri

| Tür | Ne işe yarar |
|-----|--------------|
| **Metin Kutusu (Text Field)** | Tek satır metin (ad, soyad) |
| **Çok Satırlı Metin (Multiline)** | Adres, açıklama gibi uzun metinler |
| **Onay Kutusu (Checkbox)** | İşaretle / işaretleme (evet/hayır) |
| **Radyo Düğmesi (Radio)** | Birden fazla seçenekten **bir** tane |
| **Açılır Liste (Dropdown)** | Hazır seçenekler arasından seçim |
| **Liste Kutusu (List)** | Açılır listeye benzer ama görünür |
| **İmza Alanı (Signature)** | Dijital imza için ayrılmış kutu |
| **Tarih Alanı** | Takvimden tarih seçtirir |
| **Hesaplanan Alan** | Diğer alanlardan otomatik hesaplama |
| **Buton (Button)** | "Gönder", "Yazdır", "Sıfırla" |

### 2.3 Form Tasarım İlkeleri

**Mantıksal akış:**
- Kişisel bilgiler (üstte)
- Talep edilen şey (ortada)
- Onay/imza (altta)

**Alan adları:**
- **Açık ve net etiketler** kullan
- Gerekli alan: kırmızı yıldız (*) veya "Zorunlu"
- Format ipucu: "(GG/AA/YYYY)" gibi

**Mantıksal gruplama:**
- Çerçevelerle bölümler ayır
- Aynı tipte alanları **aynı boyda** yap

### 2.4 Veri Doğrulama (Validation)

Profesyonel form PDF'inde:

- **TC Kimlik:** Tam **11 hane** olmalı (script ile kontrol)
- **Telefon:** "0XXX XXX XX XX" formatı
- **E-posta:** "@" ve "." içermeli
- **Tarih:** Geçerli bir tarih olmalı
- **Sayı:** Min/max sınırlar (yaş 0-120, vb.)

Adobe Acrobat'ta her alana **doğrulama scripti** (JavaScript) eklenebilir.

### 2.5 Hesaplama Alanları

**Örnek:** Talep formunda "Birim fiyat × Adet = Toplam"

```
Alan: birim_fiyat (sayı)
Alan: adet (sayı)
Alan: toplam (hesaplanmış)
  Hesap: Tablo > Sum (sum) → birim_fiyat × adet
```

KDV ekleme:
```
Alan: kdv_dahil
  Custom calculation: this.getField("toplam").value * 1.20
```

### 2.6 Resmî Form Şablonu Örneği

```
═════════════════════════════════════
       [KURUM LOGOSU]
       
       İZİN TALEP FORMU
═════════════════════════════════════

PERSONEL BİLGİLERİ
─────────────────
Ad Soyad:    [____________________]
TC Kimlik:   [___________]
Sicil No:    [_______]
Birim:       [▼ Açılır liste     ]
Unvan:       [____________________]

İZİN BİLGİLERİ
──────────────
İzin Türü:   ○ Yıllık  ○ Mazeret  ○ Hastalık  ○ Diğer
Başlangıç:   [GG/AA/YYYY]
Bitiş:       [GG/AA/YYYY]
Süre (gün):  [hesaplanır otomatik]

İzin sebebi (kısaca):
┌──────────────────────────────────┐
│                                  │
│                                  │
└──────────────────────────────────┘

İzin sırasında ulaşım bilgisi:
Telefon: [____________]
Adres:   [____________________]

ONAY
────
□ Verdiğim bilgilerin doğru olduğunu beyan ederim.

İmza alanı:                Tarih:
[___________________]      [GG/AA/YYYY]
```

### 2.7 Form Üretimi: Hangi Aracı Kullan?

| Araç | Avantaj | Dezavantaj |
|------|---------|------------|
| **Adobe Acrobat Pro** | Endüstri standardı, tam özellik | Pahalı |
| **Foxit PDF Editor** | Acrobat'a alternatif | Lisans |
| **LibreOffice Draw** | Ücretsiz | Sınırlı özellik |
| **Python `pypdf`** | Otomatize, programatik | Form alanı oluşturma sınırlı |
| **Python `reportlab`** | Tam kontrol, üretim | Öğrenme eğrisi |
| **Python `fillpdf`** | Hazır PDF doldurma | Sadece doldurma |

### 2.8 Form Kontrol Listesi

- [ ] **Tüm alanlara isim verildi** mi (programatik doldurma için)?
- [ ] **Sekme sırası (Tab order)** doğal akışta mı?
- [ ] **Zorunlu alanlar** belirtildi mi?
- [ ] **Format ipuçları** verildi mi?
- [ ] **Doğrulama scriptleri** çalışıyor mu?
- [ ] **Yazıcıdan basılınca** alanlar görünür mü (boş kalmıyor mu)?
- [ ] **Kaydedilebilir** mi (yoksa sadece doldurulup yazdırılabilir mi)?
- [ ] **Test verisi** ile baştan sona dolduruldu mu?

---

## BÖLÜM 3: PDF Düzenleme

### 3.1 Birleştirme (Merge)

Birden fazla PDF'i **tek dosya** yapma.

**Python ile (`pypdf`):**

```python
from pypdf import PdfWriter

writer = PdfWriter()
for dosya in ["kapak.pdf", "ana_metin.pdf", "ekler.pdf"]:
    writer.append(dosya)

with open("birlesik.pdf", "wb") as f:
    writer.write(f)
```

**Önemli:** Birleştirilen PDF'lerin **sayfa boyutları farklıysa** (A4 + A3 karışık) sonuç dengesiz olur. Önce hepsini aynı boyuta getir.

### 3.2 Bölme (Split)

PDF'i **birden fazla** dosyaya ayırma.

**Senaryolar:**

**A) Sayfa sayfa:** Her sayfa ayrı dosya
```python
from pypdf import PdfReader, PdfWriter

reader = PdfReader("buyuk.pdf")
for i, sayfa in enumerate(reader.pages):
    writer = PdfWriter()
    writer.add_page(sayfa)
    with open(f"sayfa_{i+1}.pdf", "wb") as f:
        writer.write(f)
```

**B) Aralıklara göre:** "1-10. sayfalar bir dosya, 11-25 başka dosya"

**C) Yer imlerine göre:** "Her bölüm ayrı dosya" (yer imi varsa)

### 3.3 Sayfa Çıkarma / Silme

Belirli sayfaları **çıkarmak** veya **silmek**:

```python
# Sayfa 5'i sil
reader = PdfReader("dosya.pdf")
writer = PdfWriter()
for i, sayfa in enumerate(reader.pages):
    if i != 4:  # 0-tabanlı, sayfa 5 = index 4
        writer.add_page(sayfa)
```

### 3.4 Sayfa Sıralaması Değiştirme

Sayfa 5'i sayfa 1'e taşı (örneğin):

```python
reader = PdfReader("dosya.pdf")
writer = PdfWriter()
yeni_sira = [4, 0, 1, 2, 3, 5, 6]  # 5. sayfa başa
for i in yeni_sira:
    writer.add_page(reader.pages[i])
```

### 3.5 Filigran (Watermark)

PDF'in her sayfasına **arka plan damgası** ekleme.

**"GİZLİDİR"**, **"TASLAK"**, **"KOPYA"**, kurum logosu vb.

```python
from pypdf import PdfReader, PdfWriter

reader = PdfReader("dosya.pdf")
filigran = PdfReader("filigran.pdf").pages[0]

writer = PdfWriter()
for sayfa in reader.pages:
    sayfa.merge_page(filigran)
    writer.add_page(sayfa)
```

**Filigran tasarım ipuçları:**
- **Şeffaf** olsun (yazıyı kapatmasın) — opaklık %20-30
- **Çapraz** yerleştir (45°)
- Büyük punto (60-100 pt)
- Açık gri renk

### 3.6 Sayfa Döndürme

Yan dönmüş sayfaları düzeltme:

```python
sayfa.rotate(90)   # Saat yönünde 90°
```

### 3.7 PDF'i Görsele Çevirme

PDF sayfalarını **PNG/JPG** olarak çıkarmak:

```python
import fitz  # PyMuPDF

doc = fitz.open("dosya.pdf")
for i, sayfa in enumerate(doc):
    pix = sayfa.get_pixmap(dpi=300)  # Yüksek çözünürlük
    pix.save(f"sayfa_{i+1}.png")
```

**Çözünürlük seçimi:**
- **72 dpi:** Web/ekran
- **150 dpi:** Genel kullanım
- **300 dpi:** Yazıcı kalitesi
- **600 dpi:** Profesyonel baskı

### 3.8 PDF Sıkıştırma

Büyük PDF'leri **küçültme**:

**Strateji:**
1. **Resimleri optimize et** (300 dpi → 150 dpi)
2. **Kullanılmayan font alt kümelerini** çıkar
3. **Embed'li nesneler**i sıkıştır

Aracı: Adobe Acrobat "Reduce File Size", **Ghostscript**:

```bash
gs -sDEVICE=pdfwrite -dCompatibilityLevel=1.4 \
   -dPDFSETTINGS=/ebook -dNOPAUSE -dQUIET -dBATCH \
   -sOutputFile=kucuk.pdf orijinal.pdf
```

PDFSETTINGS seçenekleri:
- `/screen` — En küçük (72 dpi resim)
- `/ebook` — Orta (150 dpi)
- `/printer` — Yazıcı (300 dpi)
- `/prepress` — Profesyonel (300 dpi, renk korunur)

---

## BÖLÜM 4: OCR ve Taranmış PDF

### 4.1 OCR Nedir?

**Optical Character Recognition** — Taranmış görüntüden **metni tanıma**. Eski belgeler, taranmış evraklar, fotoğraflar metin haline getirilebilir.

### 4.2 Taranmış PDF'in Sorunu

Taranmış belge **görüntüden** ibarettir — içindeki yazıyı **kopyalayamazsın, arayamazsın**. OCR ile metin "katmanı" eklendikten sonra:

- ✅ Metni seçip kopyalayabilirsin
- ✅ Ctrl+F ile arayabilirsin
- ✅ Erişilebilirlik sağlanır (ekran okuyucu)
- ✅ Boyut **biraz** artar (metin katmanı eklenir)

### 4.3 Türkçe için OCR

**Önemli:** OCR motoru **Türkçe diline ayarlı** olmalı. İngilizce ayarda "ı, ç, ö" karakterleri bozulur.

#### Tesseract (Ücretsiz)

```bash
# Türkçe dil paketi kurulumu
sudo apt install tesseract-ocr-tur

# Kullanım
tesseract dosya.png cikti -l tur

# PDF için (önce sayfa görselleri alınır)
ocrmypdf -l tur taranmış.pdf aranabilir.pdf
```

#### Bulut OCR Alternatifleri

- **Google Document AI** (yüksek doğruluk, ücretli)
- **Microsoft Azure OCR** (Türkçe iyi)
- **AWS Textract** (form ve tablo çıkarımı için iyi)
- **Adobe Acrobat Pro** (yerel, ücretli)

### 4.4 OCR Doğruluğunu Artırma

Taranan görüntü **ne kadar net**, OCR **o kadar iyi**:

- **300 dpi minimum** — daha düşükte hata oranı katlanır
- **Düz tara** — eğri taranmışsa önce düzelt
- **Kontrast yüksek** — açık metin / koyu arka plan
- **Arka plan temiz** — leke, gölge OCR'yi şaşırtır

#### Görüntü Ön İşleme

OCR'den önce:

```python
from PIL import Image, ImageOps

img = Image.open("taranmis.png")
img = ImageOps.grayscale(img)        # Gri tonlama
img = ImageOps.autocontrast(img)     # Kontrast artır
img = img.point(lambda x: 0 if x < 128 else 255)  # Eşikleme
img.save("temizlenmis.png")
```

### 4.5 Taranmış Belgeden Tablo Çıkarma

Taranmış belgede tablo varsa:
- **Camelot** (Python) — yapısal tablolar için
- **Tabula** (Java) — basit tablolar
- **Adobe Acrobat Pro** — "Tabloyu Excel'e aktar"
- **AWS Textract** — karışık formlar için

### 4.6 OCR Kontrol Listesi

- [ ] **Türkçe dil paketi** yüklü mü?
- [ ] Görüntü **300 dpi+** mi?
- [ ] **Düz** taranmış mı?
- [ ] OCR sonrası **rastgele 5 sayfada** doğrulama yapıldı mı?
- [ ] **Özel karakterler** (ı, ğ, ş, ç) doğru mu?
- [ ] **Sayılar** doğru çıkmış mı (genelde "0 ↔ O", "1 ↔ l" karışır)?
- [ ] **PDF/A** olarak kaydedildi mi (arşiv için)?

---

## BÖLÜM 5: Güvenlik ve Dijital İmza

### 5.1 Şifreleme

PDF'i **açma** şifresi veya **düzenleme** şifresi ile koruma.

```python
from pypdf import PdfReader, PdfWriter

reader = PdfReader("dosya.pdf")
writer = PdfWriter(clone_from=reader)
writer.encrypt(
    user_password="acma_sifresi",
    owner_password="duzenleme_sifresi",
    use_128bit=True
)
with open("sifreli.pdf", "wb") as f:
    writer.write(f)
```

**Şifre Türleri:**
- **User Password (Open):** PDF'i **açmak** için gerekli
- **Owner Password (Permissions):** Düzenleme/yazdırma kısıtlamalarını **kaldırmak** için

### 5.2 İzin Kısıtlamaları

PDF'te neler engellenebilir:

- Yazdırma
- Metin/görsel kopyalama
- Yorum ekleme
- Form doldurma
- Sayfa eklemek/çıkarmak
- İçerik değiştirme

```python
writer.encrypt(
    user_password="",  # Açma şifresi yok
    owner_password="gizli",
    permissions_flag=PrintPermissionFlag.PRINT  # Sadece yazdırma izni
)
```

### 5.3 Dijital İmza

**Elektronik İmza vs. Dijital İmza:**

- **Elektronik imza:** Görüntü olarak imza (taranmış imza, çizilmiş)
- **Dijital imza:** Kriptografik, **hukuken geçerli**, **sahibini doğrular**

### 5.4 Türkiye'de Dijital İmza Türleri

| Tür | Açıklama | Hukuki Geçerlilik |
|-----|----------|-------------------|
| **e-İmza (Nitelikli E-İmza)** | Akıllı kart / USB token | Islak imza ile **eşdeğer** (5070 sayılı Kanun) |
| **Mobil İmza** | GSM operatörü | Nitelikli imza ile **eşdeğer** |
| **e-Devlet Kapısı** | T.C. kimlik + e-Devlet şifresi | Sınırlı resmi geçerlilik |
| **Görsel imza** | İmzanın resmi | Hukuki geçerliliği sınırlı |

### 5.5 e-İmza ile PDF İmzalama

Adobe Acrobat Reader DC ile:

1. **Araçlar → Sertifikalar → Dijital İmza**
2. PDF'te imza alanına tıkla
3. e-İmza kartını bilgisayara tak
4. PIN gir
5. İmzala → Kaydet

**Doğrulama:**
- Acrobat **otomatik** imzayı doğrular
- "İmza geçerli" yeşil onay görünür
- "İmzalandıktan sonra değiştirilmemiş" garantisi

### 5.6 PDF/A — Arşiv Standardı

Resmî kurum belgesi **uzun süre saklanacaksa** PDF/A formatına çevrilmeli.

**Niye PDF/A?**
- 100 yıl sonra da **aynı görünmesi** garanti
- **Tüm fontlar gömülü** (font değişmez)
- **Dış kaynaklara bağımlılık yok** (linkler donmuş)
- **DEVLET ARŞİVLERİNİN STANDARDI**

**Türleri:**
- **PDF/A-1** — En kısıtlı, en güvenli
- **PDF/A-2** — JPEG2000, şeffaflık dahil
- **PDF/A-3** — Eklenti dosya saklama dahil

#### PDF/A'ya Çevirme

**Adobe Acrobat:** Dosya → Farklı Kaydet → PDF/A

**Ghostscript:**
```bash
gs -dPDFA=2 -dBATCH -dNOPAUSE -sProcessColorModel=DeviceRGB \
   -sDEVICE=pdfwrite -sPDFACompatibilityPolicy=1 \
   -sOutputFile=arşiv.pdf orijinal.pdf
```

### 5.7 Güvenlik Kontrol Listesi

- [ ] **Hassas bilgi** mi? Şifrelenmesi gerekiyor mu?
- [ ] Resmî belge mi? **Dijital imza** atılmalı mı?
- [ ] **Uzun süreli arşiv** mi? **PDF/A** mı?
- [ ] **Yazdırma engellenmeli** mi?
- [ ] **Kopyalamaya** kısıtlama gerekiyor mu?
- [ ] Yedek **şifresiz** kopya saklandı mı (kayıp riskine karşı)?

---

## Genel Karar Tablosu: Hangi Yaklaşım?

| Senaryo | Öneri |
|---------|-------|
| Word'den tek seferlik PDF | "PDF olarak kaydet" yeter |
| Çok sayfalı kurumsal rapor | Word + bölüm sonları → PDF + yer imleri |
| Form dolduran kullanıcılar | Adobe Acrobat / Foxit ile interaktif PDF |
| 100 PDF birleştirmek | Python `pypdf` script |
| Taranmış belge | Tesseract OCR (Türkçe) → Aranabilir PDF |
| Hassas belge | Şifreleme + Dijital imza |
| Devlet arşivi | PDF/A formatı |
| Programatik üretim | Python `reportlab` veya `weasyprint` |

---

## Programatik PDF Üretimi (Hızlı Referans)

### `reportlab` ile Sıfırdan PDF

```python
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer

doc = SimpleDocTemplate("rapor.pdf", pagesize=A4)
styles = getSampleStyleSheet()

icerik = [
    Paragraph("Resmî Rapor", styles['Title']),
    Spacer(1, 12),
    Paragraph("Bu bir test paragrafıdır.", styles['Normal']),
]

doc.build(icerik)
```

### `weasyprint` ile HTML→PDF

HTML yazıp PDF'e çevirme — CSS ile tam kontrol:

```python
from weasyprint import HTML

HTML(string='<h1>Başlık</h1><p>İçerik</p>').write_pdf("cikti.pdf")
```

**Avantaj:** HTML/CSS biliyorsan istediğin tasarımı yapabilirsin. **Karmaşık raporlar için en güçlü yol.**

### `fillpdf` ile Form Doldurma

Hazır boş form PDF'ini doldurmak:

```python
from fillpdf import fillpdfs

veri = {
    "ad_soyad": "Ahmet YILMAZ",
    "tc_kimlik": "12345678901",
    "tarih": "08/05/2026"
}

fillpdfs.write_fillable_pdf("bos_form.pdf", "dolu_form.pdf", veri)
```

---

## Son Söz

PDF, **basit görünen ama derinlemesine güçlü** bir formattır. Sıradan kullanıcı sadece "kaydet" der, profesyonel:
- Doğru sayfa yapısını kurar
- Yer imlerini ekler
- Form alanları tasarlar
- Dijital imza koyar
- PDF/A arşivler

Bu skill, **hangi senaryoda hangi tekniği** kullanacağını anlatır. İhtiyacına göre ilgili bölüme dön.
