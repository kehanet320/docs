# turkce-dogallastirici

---
name: turkce-dogallastirici
description: Türkçe metinlerdeki yapay zekâ izlerini ve çeviri kokan kalıpları temizleyerek doğal, insan kaleminden çıkmış bir Türkçe üslup elde etmek için kullanılır. Kullanıcı "bu yazı yapay duruyor", "doğallaştır", "çeviri gibi olmuş", "robotik", "insan eli değmiş gibi olsun", "üslubu düzelt", "akıcı hâle getir" gibi ifadeler kullandığında ya da bir Türkçe metni (resmî yazı, rapor, aforizma, e-posta) gözden geçirirken devreye girer. ebys-yazisma ve humanizer skill'lerini tamamlar; resmî yazışma kurallarını veya gerekli resmî kalıpları (arz/rica ederim vb.) bozmadan çalışır.
---

# Türkçe Doğallaştırıcı

## Genel İlke

Türkçe metinlerdeki yapay zekâ izlerini ve İngilizceden çeviri kokan kalıpları ayıklayıp metni doğal, akıcı, insan kaleminden çıkmış hâle getirmek. Mesaj korunur, anlam değişmez; yalnızca yapaylık temizlenir.

**Temel ölçüt:** Metin sesli okunduğunda gerçek bir insanın yazdığı izlenimini vermeli. "Doğru ama soğuk/şişkin/robotik" duran her cümle adaydır.

**Kritik uyarı — bağlama duyarlılık:** Resmî yazışmada bazı kalıplar *zorunludur* ve doğallaştırma adına bunlara dokunulmaz: "arz ederim", "rica ederim", "gereğini arz/rica ederim", "bilgilerinize sunulur", "-maktadır/-mektedir" gibi resmî kip. Bunlar yapaylık değil, resmî registerin kuralıdır. Doğallaştırma bu çerçevenin *içinde* yapılır. (Resmî yazışma kuralları için `ebys-yazisma` skill'i esastır; bu skill onun üslup katmanıdır.)

---

## Türkçeye Özgü Yapay Kalıplar (Tespit ve Düzeltme)

### 1. Şişirilmiş önem vurgusu

**İzler:** büyük önem taşımaktadır, kritik bir rol oynamaktadır, hayati öneme sahiptir, göz ardı edilemez, dikkat çekmektedir, vazgeçilmez bir unsurdur, önemli bir adım atılmıştır

**Sorun:** Sıradan bir olguyu yapay biçimde büyütür, içi boş ağırlık katar.

- **Önce:** "Dijitalleşme, günümüz kurumları açısından büyük önem taşımakta ve vazgeçilmez bir rol oynamaktadır."
- **Sonra:** "Kurumlar işlerinin çoğunu artık dijital ortamda yürütüyor."

### 2. Çeviri kokan kalıplar (calque)

**İzler:** "söz konusu olduğunda", "... açısından bakıldığında", "bu, ... anlamına gelir", gereksiz "bir" (İngilizce "a/an" çevirisi), "günün sonunda" (at the end of the day), "bir bütün olarak"

**Sorun:** Türkçenin doğal akışı yerine İngilizce cümle iskeleti kurulur.

- **Önce:** "Verimlilik söz konusu olduğunda, bu, sürecin bir bütün olarak ele alınması anlamına gelir."
- **Sonra:** "Verimlilik için süreci baştan sona ele almak gerekir."

### 3. Aşırı "-mektedir / -maktadır" yığını

**Sorun:** Her cümleyi geniş zaman edilgen kipiyle bitirmek metni resmî değil, *yapay* yapar. (Resmî yazıda yerinde kullanımı normaldir; sorun *yığılmasıdır*.)

- **Önce:** "Çalışma tamamlanmaktadır. Sonuçlar değerlendirilmektedir. Rapor hazırlanmaktadır."
- **Sonra:** "Çalışma tamamlandı, sonuçlar değerlendirildi ve rapor hazırlanıyor."

### 4. İçi boş geçiş ve dolgu ifadeleri

**İzler:** "Bu bağlamda", "Bu doğrultuda", "Bu kapsamda", "Sonuç olarak", "Özetle", "Bilindiği üzere", "Günümüzde", "Hızla gelişen dünyamızda" (özellikle *peş peşe* ve *gereksiz* kullanım)

**Sorun:** Cümleye anlam katmadan yer kaplar, tutorial/şablon hissi verir.

- **Önce:** "Bu bağlamda, bilindiği üzere, günümüzde teknoloji hızla gelişmektedir."
- **Sonra:** "Teknoloji hızla gelişiyor."

### 5. Sözde derinlik veren "-arak / -erek" zincirleri

**İzler:** "vurgulayarak", "sağlayarak", "ortaya koyarak", "destekleyerek", "katkı sunarak" — cümlenin sonuna takılan sahte derinlik.

- **Önce:** "Proje, verimliliği artırarak, maliyeti düşürerek ve iş birliğini güçlendirerek değer sağlamaktadır."
- **Sonra:** "Proje verimliliği artırıyor, maliyeti düşürüyor ve ekipler arası iş birliğini kolaylaştırıyor."

### 6. Üçleme (rule of three) refleksi

**Sorun:** Her şeyi üçer sıfat/yüklemle sıralamak (hızlı, etkili ve güvenilir) ritmi makineleştirir.

- **Önce:** "Sistem hızlı, etkili ve güvenilir bir şekilde çalışır."
- **Sonra:** "Sistem hızlı çalışıyor ve nadiren hata veriyor."

### 7. Tumturaklı/gereksiz ağır söz dağarcığı

**İzler:** gerekli olmayan yerde "kusursuz", "sorunsuz", "zahmetsizce", "son derece", "oldukça", "etkili bir şekilde", gereksiz Osmanlıca-Arapça ağdalı sözcükler.

- **Önce:** "Süreç son derece kusursuz ve zahmetsizce ilerlemektedir."
- **Sonra:** "Süreç sorunsuz ilerliyor." *(tek bir sade yüklem yeterli)*

### 8. Belirsiz atıf

**İzler:** "uzmanlara göre", "yapılan araştırmalar gösteriyor ki", "herkesin bildiği gibi" (kaynak vermeden).

- **Önce:** "Uzmanlara göre bu yöntem daha başarılıdır."
- **Sonra:** "2025 tarihli Bakanlık raporu bu yöntemin hata oranını yarıya indirdiğini gösteriyor." *(kaynak varsa belirt; yoksa iddiayı yumuşat)*

### 9. Klişe açılış ve kapanış

**İzler (açılış):** "Günümüzde...", "Tarih boyunca...", "İnsanlık var olduğundan beri..."
**İzler (kapanış):** "Sonuç olarak geleceğimiz parlak", "Unutulmamalıdır ki...", "Velhasıl"

- **Önce:** "Sonuç olarak, unutulmamalıdır ki eğitim geleceğimizin temelidir."
- **Sonra:** *(Çoğu zaman tümüyle silinir; metin asıl noktasıyla biter.)*

---

## Süreç

1. Metni dikkatle, tercihen sesli okur gibi tara.
2. Yukarıdaki kalıpların her örneğini işaretle.
3. **Önce bağlamı belirle:** Resmî yazı mı, rapor mı, aforizma mı, e-posta mı? Resmî yazıysa zorunlu kalıplara dokunma.
4. Her sorunlu bölümü, anlamı koruyarak yeniden yaz.
5. Metni şu süzgeçten geçir:
   - Sesli okununca doğal mı?
   - Cümle uzunlukları çeşitleniyor mu (hep aynı boyda değil)?
   - Soyut iddia yerine somut bilgi var mı?
   - Bağlama uygun ton korunuyor mu?
6. **Son anti-yapaylık geçişi:** "Bu metni hâlâ yapay gösteren ne?" diye sor, kalan izleri kısaca yaz, sonra "Şimdi yapay durmasın" diyerek son düzeltmeyi yap.

## Çıktı Biçimi

1. Doğallaştırılmış metin
2. (İsteğe bağlı) "Hâlâ yapay duran yerler" — kısa madde
3. (İsteğe bağlı) Yapılan başlıca değişikliklerin özeti

---

## Diğer Skill'lerle İlişki

- **`ebys-yazisma`** resmî yazışmanın *kurallarını ve formatını* belirler. Bu skill onun *üslup/doğallık katmanıdır*. Çakışma durumunda resmî kural önceliklidir.
- **`humanizer`** İngilizce AI kalıpları üzerine kuruludur. Bu skill onun Türkçe karşılığıdır; Türkçe metinlerde bunu tercih et.
- **`dusunce-ortagi` / `skill-yoneticisi`** karmaşık çok katmanlı işlerde bu skill'i sıraya koyabilir.

## Sık Yapılan Hatalar

| Hata | Doğrusu |
|------|---------|
| Resmî zorunlu kalıpları (arz/rica ederim) "yapay" sanıp silmek | Resmî registerin kuralı; korunur |
| Her "-maktadır"ı silmek | Yığılmayı çöz, yerinde kullanımı bırak |
| Doğallaştırırken anlamı kaydırmak | Anlam sabit kalır, sadece biçim değişir |
| Resmî yazıya aşırı samimi/devrik üslup sokmak | Doğallık = sadelik, laubalilik değil |
| TDK imlasından sapmak | İmla her hâlükârda korunur |
