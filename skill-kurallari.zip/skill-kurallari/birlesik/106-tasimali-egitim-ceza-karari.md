# tasimali-egitim-ceza-karari

---
name: "tasimali-egitim-ceza-karari"
description: "Nurhak İlçe MEM taşımalı eğitim (öğrenci taşıma) sözleşmelerinde ServisCell ve benzeri aykırılıklar için komisyon ceza kararı hazırlarken ve ceza tutarını hesaplarken kullan."
---

# Taşımalı Eğitim Komisyon Ceza Kararı

Bu skill, öğrenci taşıma hizmeti sözleşmelerinde yükleniciye uygulanacak cezalar için hazırlanan **Komisyon Kararı** belgelerinin tek ve sabit standardıdır. Birden fazla sözleşme için toplu karar istenebilir; her sözleşme ayrı karar ve ayrı sayfadır.

Birlikte çalışan skill'ler: `kurumsal-turkce-yazim` → `turkce-dogallastirici` (resmî kalıplara dokunmadan) → Word çıktısı için `word-ileri` / `docx`.

## 1. Girdi kontrolü

Her karar için şu bilgiler gerekir:

- Taşıma güzergâhı / okul adı
- Yüklenicinin adı soyadı veya firma unvanı
- Sözleşme tarihi ve (varsa) sayısı
- Ceza hesabının dayanağı olan tutar (sözleşmede cezanın hesaplandığı bedel; günlük taşıma bedeli mi, toplam sözleşme bedeli mi olduğu sözleşmeden okunur)
- Aykırılığın türü (ör. ServisCell sistemine giriş yapılmaması) ve gerçekleştiği gün sayısı veya tarihler
- Karar tarihi

Eksik bilgi varsa iş durdurulmaz: metne [Sözleşme Tarihi] gibi yer tutucu konur ve teslimde tek satırla belirtilir. **Ceza dayanağı tutar** bilinmiyorsa hesap yapılmaz, yer tutucu bırakılır; tahmin edilmez.

## 2. Ceza hesabı

- Oran: **binde 2 (0,002)**.
- Formül: `Ceza = Dayanak tutar × 0,002 × aykırılık sayısı (gün/olay)` — aykırılık sayısının nasıl sayıldığı (gün, sefer, olay) sözleşmedeki ceza maddesine göre belirlenir.
- Hesap mutlaka kodla (Python) yapılır ve kuruşa yuvarlanır (ROUND_HALF_UP).
- Tutar hem rakamla hem yazıyla verilir: `1.234,56 TL (Bin iki yüz otuz dört Türk lirası elli altı kuruş)`.
- Toplu kararlarda her sözleşmenin hesabı ayrı ayrı yapılır, sonra kontrol tablosu ile kullanıcıya gösterilir.

## 3. Hukuki dayanak (metinde aynen)

- Öğrenci Taşıma Yönergesi (24.07.2025)
- Taşıma Yoluyla Eğitime Erişim Yönetmeliği (11.09.2014)
- Kahramanmaraş İl Millî Eğitim Müdürlüğünün E-38898943-140-147839275 sayılı yazısı
- İlgili taşıma sözleşmesinin ceza maddesi

Kullanıcı yeni bir dayanak verirse listeye eklenir; mevcut dayanaklar silinmez.

## 4. Belge düzeni

- Word, A4 dikey, **tek sayfa**.
- Başlık bloğu: `T.C. / NURHAK KAYMAKAMLIĞI / İlçe Millî Eğitim Müdürlüğü`.
- Belge adı: **KOMİSYON KARARI**; altında karar tarihi ve karar sayısı.
- Gövde sırası: (1) konu ve sözleşme bilgileri, (2) tespit edilen aykırılık, (3) dayanak mevzuat, (4) hesap ve ceza tutarı, (5) karar cümlesi ("…tutarındaki cezanın yüklenicinin hak edişinden kesilmesine oy birliğiyle karar verilmiştir.").
- **OLUR bloğu yoktur.**
- Altta komisyon imza blokları yan yana: Başkan ve iki üye (ad soyad üstte, unvan altta).
- Komisyon üyeleri varsayılan olarak hafızadaki güncel komisyon kaydından alınır (başkan, şube müdürü, şef). Kullanıcı farklı isim verirse onunki geçerlidir.

## 5. Dil

- Resmî karar dili: edilgen ve geçmiş zaman ("…tespit edilmiştir", "…karar verilmiştir").
- Aynı cümle kalıbı her kararda kelimesi kelimesine tekrarlanmaz; toplu kararlarda bile doğal akış korunur, ama hukuki ifadeler değişmez.
- TDK: kurum adları büyük harfle, tarihler `GG.AA.YYYY`, para `1.234,56 TL`.

## 6. Teslim öncesi kontrol

- [ ] Her hesap kodla doğrulandı, rakam ve yazı aynı tutarı söylüyor
- [ ] Her karar tek sayfaya sığıyor
- [ ] OLUR bloğu yok, imza blokları eksiksiz
- [ ] Dayanak listesi tam
- [ ] Yer tutucular teslim notunda listelendi
