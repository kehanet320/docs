# resmi-tutanak

---
name: "resmi-tutanak"
description: "Nurhak İlçe MEM adına resmî tutanak (tespit, teslim-tesellum, sınav, hasar, toplantı vb.) hazırlarken kullan; imza ve UYGUNDUR onay bloğu düzenini sabit uygular."
---

# Resmî Tutanak

Bir olayın, durumun veya teslimin resmî olarak kayda geçirildiği tutanakların standardıdır.

Birlikte çalışan skill'ler: `kurumsal-turkce-yazim` → `turkce-dogallastirici` (tutanak kalıplarına dokunmadan) → Word için `word-ileri` / `docx`.

## 1. Tutanak türünü belirle

| Tür | Gövdede mutlaka bulunur |
|---|---|
| Tespit tutanağı | Ne, nerede, ne zaman, kim tarafından tespit edildi |
| Teslim-tesellum | Teslim eden, teslim alan, malzeme/belge listesi, adet, durum |
| Hasar / arıza | Taşınır veya yapı, hasarın niteliği, tahmini neden |
| Sınav tutanağı | Sınav adı, tarih-saat, salon, katılımcı sayısı, olaylar |
| Toplantı / komisyon | Katılımcılar, gündem, alınan kararlar |

## 2. Belge düzeni

- Word, A4 dikey, mümkünse tek sayfa.
- Başlık: `T.C.` / `NURHAK KAYMAKAMLIĞI` / `İlçe Millî Eğitim Müdürlüğü`.
- Belge adı ortalı, büyük harf (ör. **TESPİT TUTANAĞI**).
- Gövde: düz paragraf. Giriş cümlesi tarih, saat ve yeri verir: "06.10.2026 tarihinde saat 10.00'da … yapılan incelemede …"
- Liste gerekiyorsa (malzeme, katılımcı) gövdenin içinde tablo.
- Kapanış kalıbı: "İşbu tutanak … nüsha olarak düzenlenmiş ve hep birlikte imza altına alınmıştır." (nüsha sayısı bilinmiyorsa yer tutucu).

## 3. İmza ve onay blokları

- Düzenleyenlerin imza blokları yan yana: ad soyad üstte, unvan altta. Kullanıcı tek düzenleyen ise varsayılan blok: **İsmail ŞAHAN / Memur**.
- Onay gerekiyorsa altta ortalı **UYGUNDUR** bloğu: tarih, ad soyad, `İlçe Millî Eğitim Müdürü` (vekil ise `İlçe Millî Eğitim Müdürü V.`). Ad soyad hafızadaki güncel kayıttan alınır; değişmiş olabileceği için teslimde tek satırla teyit istenir.
- Onay gerektirmeyen tutanaklarda (ör. teslim-tesellum) UYGUNDUR bloğu konmaz.

## 4. Dil

- Tarafsız, olgusal, geçmiş zaman: "…görülmüştür", "…tespit edilmiştir". Yorum ve tahmin "…olduğu değerlendirilmektedir" biçiminde açıkça ayrılır.
- Sayılar rakam ve gerektiğinde yazıyla.
- Kişisel veri (T.C. kimlik no vb.) yalnızca kullanıcı verirse ve tutanak türü gerektiriyorsa yazılır.

## 5. Teslim öncesi kontrol

- [ ] Tarih, saat, yer giriş cümlesinde var
- [ ] Tutanak türünün zorunlu unsurları tam
- [ ] Kapanış kalıbı ve nüsha sayısı var
- [ ] İmza ve (gerekiyorsa) UYGUNDUR bloğu doğru
- [ ] TDK yazım ve noktalama kontrolü yapıldı
