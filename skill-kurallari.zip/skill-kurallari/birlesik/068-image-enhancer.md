# image-enhancer

---
name: image-enhancer
description: Improves the quality of images, especially screenshots, by enhancing resolution, sharpness, and clarity. Perfect for preparing images for presentations, documentation, or social media posts. Turkce tetikleyiciler — gorsel iyilestir, ekran goruntusu netlestir, goruntu kalitesini artir, upscale, keskinlestir, sunum icin gorsel hazirla.
---

# Image Enhancer

This skill takes your images and screenshots and makes them look better—sharper, clearer, and more professional.

## When to Use This Skill

- Improving screenshot quality for blog posts or documentation
- Enhancing images before sharing on social media
- Preparing images for presentations or reports
- Upscaling low-resolution images
- Sharpening blurry photos
- Cleaning up compressed images

## What This Skill Does

1. **Analyzes Image Quality**: Checks resolution, sharpness, and compression artifacts
2. **Enhances Resolution**: Upscales images intelligently
3. **Improves Sharpness**: Enhances edges and details
4. **Reduces Artifacts**: Cleans up compression artifacts and noise
5. **Optimizes for Use Case**: Adjusts based on intended use (web, print, social media)

## How to Use

### Basic Enhancement

```
Improve the image quality of screenshot.png
```

```
Enhance all images in this folder
```

### Specific Improvements

```
Upscale this image to 4K resolution
```

```
Sharpen this blurry screenshot
```

```
Reduce compression artifacts in this image
```

### Batch Processing

```
Improve the quality of all PNG files in this directory
```

## Example

**User**: "Improve the image quality of screenshot-2024.png"

**Output**:
```
Analyzing screenshot-2024.png...

Current specs:
- Resolution: 1920x1080
- Format: PNG
- Quality: Good, but slight blur

Enhancements applied:
✓ Upscaled to 2560x1440 (retina)
✓ Sharpened edges
✓ Enhanced text clarity
✓ Optimized file size

Saved as: screenshot-2024-enhanced.png
Original preserved as: screenshot-2024-original.png
```

**Inspired by:** Lenny Rachitsky's workflow from his newsletter - used for screenshots in his articles

## Tips

- Always keeps original files as backup
- Works best with screenshots and digital images
- Can batch process entire folders
- Specify output format if needed (PNG for quality, JPG for smaller size)
- For social media, mention the platform for optimal sizing

## Common Use Cases

- **Blog Posts**: Enhance screenshots before publishing
- **Documentation**: Make UI screenshots crystal clear
- **Social Media**: Optimize images for Twitter, LinkedIn, Instagram
- **Presentations**: Upscale images for large screens
- **Print Materials**: Increase resolution for physical media


---

## Bu ortamda çalışan yöntem (kod yürütme ile)

Bu skill yapay zekâ tabanlı süper çözünürlük modeli çağırmaz; bunun yerine kod yürütme ortamındaki **Pillow** ile gerçek, güvenilir iyileştirme uygular. Tipik akış:

```python
from PIL import Image, ImageEnhance, ImageFilter

img = Image.open("girdi.png").convert("RGB")

# 1) Büyütme (Lanczos en kaliteli yeniden örnekleme)
scale = 2
img = img.resize((img.width*scale, img.height*scale), Image.LANCZOS)

# 2) Keskinlik (Unsharp Mask — ekran görüntüleri için ideal)
img = img.filter(ImageFilter.UnsharpMask(radius=2, percent=150, threshold=3))

# 3) Kontrast ve renk dengesi (hafif)
img = ImageEnhance.Contrast(img).enhance(1.08)
img = ImageEnhance.Color(img).enhance(1.05)

img.save("cikti.png", optimize=True)
```

Gerçekçi beklenti: Bu yöntem ekran görüntüsü/sıkıştırma kaynaklı bulanıklığı belirgin biçimde düzeltir, sunum ve dokümana hazır hâle getirir. Ancak **kayıp bilgiyi geri üretmez** — çok düşük çözünürlüklü bir görseli gerçek 4K detayına çıkaramaz. "4K'ya yükselt" istendiğinde bunu kullanıcıya net söyle ve Lanczos ile ölçekleyip keskinleştir.

Toplu işlem için klasördeki tüm `.png/.jpg` dosyalarında döngü kur; çıktıları ayrı bir `iyilestirilmis/` klasörüne yaz, orijinalleri koru.
