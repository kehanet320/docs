# skill-yoneticisi

---
name: "skill-yoneticisi"
description: "Kullanıcının mesajına göre HANGİ skill'lerin devreye gireceğini belirleyen ve doğru sıraya koyan koordinatör. Karmaşık görevlerde, çoklu skill gerektiren işlerde veya niyet belirsizken devreye girer. Mesaj tek bir skill'i açıkça çağırıyorsa (örneğin \"şu Excel formülü\") bu skill devreye GİRMEZ — gereksiz katman olur. Tetikleyiciler şunlardır: \"yardım et\", \"şunu hazırla\", \"bu yazıyı düzelt ve sunum yap\", \"rapor + tablo + grafik\", \"tam bir iş çıkar\", uzun çok parçalı görevler, hangi skill'i kullanacağına emin olunmayan durumlar."
---

# Skill Yöneticisi (Router) — Sürüm 2

## Amacım

Kullanıcı çok parçalı, karmaşık veya niyeti belirsiz bir iş istediğinde; o iş için **hangi skill'lerin**, **hangi sırayla** ve **hangi katmanda** çalışacağına karar veririm.

Sabit bir liste ezberlemem. O an sistemde hangi skill'ler mevcutsa **kendi açıklamalarını okur**, niyetle eşleştiririm. Yeni bir skill eklendiğinde beni güncellemeye gerek kalmaz; açıklaması netse onu görür ve yerinde kullanırım.

## Ekip İçindeki Yerim

Üç skill birlikte çalışır, görevleri karışmaz:

| Skill | Ne zaman | Görevi |
|---|---|---|
| `skill-orkestrasyonu` | **Her talepte** | Genel kurallar: katmanlı seçim, çakışma kuralları, teslim öncesi kontrol listesi |
| `skill-yoneticisi` (ben) | **Yalnızca çok parçalı, karmaşık veya belirsiz işlerde** | İşi parçalara ayırmak, her parçaya skill atamak, parçaları doğru sıraya dizmek |
| `kurumsal-turkce-yazim` | **Her Türkçe yazışma ve konuşma metninde** | TDK, kurumsal dil ve insan elinden çıkmış üslup standardı |

Orkestrasyonun kuralları benim üstümdedir. Aramızda bir çelişki görünürse orkestrasyon kazanır.

## Ne Zaman Devreye Girerim?

✅ **Devreye girerim:**
- İş **birden fazla skill** gerektiriyorsa ("rapor hazırla, sunum yap, mail at")
- Niyet **belirsizse** ("yardım et", "şunu yapalım")
- Karmaşık ve çok aşamalı bir görevse
- Kullanıcı "hangi skill'i kullanmalıyım?" diye sorduysa

❌ **Devreye girmem:**
- Mesaj tek bir skill'i zaten açıkça çağırıyorsa
- Basit selamlaşma, kısa sohbet veya bilgi sorusu
- Kullanıcı belirli bir skill'i adıyla istemişse (o skill doğrudan çalışır)

---

## Karar Süreci

### 1⃣ Niyeti Çöz

- **Tek iş mi, çoklu iş mi?** Çoklu ise parçaları tek tek yaz.
- **Hangi alan(lar)?** Resmî yazışma, konuşma metni, veri/tablo, sunum, PDF, tasarım, web, mobil uygulama, kod, araştırma…
- **Çıktı ne?** Sohbet içi metin mi, Docs/Sheets/Slides artifact'ı mı, Word/Excel/PowerPoint/PDF dosyası mı, web sayfası mı, kod mu?
- **Dil ne?** Türkçe ise `kurumsal-turkce-yazim` ve `turkce-dogallastirici` hesaba katılır.
- **Risk düzeyi ne?** Büyük, geri dönüşü zor veya hata kaldırmayan iş ise `ultrawork` çalışma modu eklenir.

### 2⃣ Mevcut Skill'leri Tara

O an erişilebilir skill açıklamalarını (özellikle Türkçe tetikleyicileri) gözden geçirir, niyetle örtüşenleri seçerim. Bir skill'i "adı tanıdık geldi" diye değil, **açıklaması bu işi kapsadığı için** çağırırım.

Katmanlı ailelerde (temel / ileri / uzman) işin gerçek karmaşıklığına uyan **en uygun katmanı** seçerim; garanti olsun diye hepsini birden çağırmam.

### 3⃣ Sırala

```
1. Çalışma modu      → gerekirse ultrawork / dusunce-ortagi / systematic-debugging
2. İçerik            → alanına uygun içerik skill'i (ebys-yazisma, agency-*, araştırma…)
3. Türkçe standart   → kurumsal-turkce-yazim (Türkçe yazışma/konuşma metninde)
4. Üslup cilası      → turkce-dogallastirici (Türkçe) / humanizer (yalnızca İngilizce)
5. Biçim ve çıktı    → artifact türü veya word/excel/powerpoint/pdf/html skill'leri
6. Doğrulama         → verification-before-completion + orkestrasyonun kontrol listesi
```

Üslup cilası, metin dosyaya dökülmeden önce yapılır; böylece dosya yeniden üretilmez. Her iş altı adımın hepsini gerektirmez; gerekeni alır, gereksizi atlarım.

### 4⃣ Çakışmayı Çöz

İki skill aynı işe aday görünüyorsa **daha özel olan, daha genel olana yeğdir.** Kalan kararlar için aşağıdaki altın kurallara ve `skill-orkestrasyonu` çakışma kurallarına başvururum.

### 5⃣ Sessiz Uygulama

Skill seçim sürecini kullanıcıya anlatmam; "şu skill'leri kullanacağım" türü açıklama yapmam. Çok aşamalı işlerde ilerlemeyi görev listesiyle (task list) gösteririm; kullanıcı yalnızca sonucu ve gerekiyorsa tek cümlelik bir notu görür.

---

## Altın Kurallar

Bu kurallar belirli skill **adlarına** değil, **işlevlere** bağlıdır. Adlar kolaylık için anılmıştır; bir skill'in adı değişse de kural işleviyle geçerlidir.

1. **Türkçe üslupta Türkçe doğallaştırıcı:** Türkçe metinde `turkce-dogallastirici`; genel `humanizer` yalnızca İngilizce metinde.

2. **Resmî yazışmada sıra:** Önce `ebys-yazisma` (yönetmelik yapısı), sonra `kurumsal-turkce-yazim` (TDK ve kurumsal dil), en son `turkce-dogallastirici`. Doğallaştırma "arz ederim / rica ederim", ilgi, konu, dağıtım gibi resmî kalıpları **asla bozmaz**.

3. **Katmanlı ailelerde doğru katman:** Günlük iş → temel katman (`excel-temel`, `word-ileri`, `powerpoint-ustasi`). "Makro", "VBA", "add-in", "şablon mimarisi", "mail merge", "Ribbon" gibi ileri işaret varsa uzman katman (`excel-makro-vba` → `excel-otomasyon-ustasi`, `word-ileri-ustasi`, `powerpoint-ileri-ustasi`).

4. **Çıktı biçimi:** Kullanıcı Word, Excel, PowerPoint veya PDF dosyasını açıkça istemişse dosya skill'i kullanılır. İstememişse oturumda varsa Docs / Sheets / Slides artifact türleri tercih edilir. Mevcut bir dosyanın düzenlenmesi istenmişse dosya kendi biçiminde düzenlenir.

5. **Resmî bağlamda yaratıcı tasarım dili yok:** Kurumsal belge ile afiş aynı estetikle ele alınmaz. Görsel tasarımda `tasarim-ustasi`; kurumsal/resmî görünüm gerekiyorsa sade, ölçülü dil.

6. **Kod ve geliştirme:**
   - Hata, beklenmeyen davranış → önce `systematic-debugging`, düzeltmeden sonra `verification-before-completion`
   - Kod kalitesi/güvenlik geri bildirimi → `code-reviewer`
   - Commit mesajı → `git-commit-writer`; PR açıklaması → `pr-description-writer`; README → `readme-generator`
   - "Proje çalışmıyor / kurulmuyor / port dolu" → `env-doctor`
   - Anthropic / Claude ürün ve API soruları → `product-self-knowledge` (bellekten değil, bu referanstan)
   - Kod aile skill'leri metin üslubunu düzeltmez; doğallaştırma **kod çıktısına uygulanmaz**, yalnızca insanın okuyacağı düz metne uygulanır.

7. **Mobil, web ve eklenti:**
   - APK, WebView, Capacitor → `webview-apk-kurallari` + `capacitor-app-development` (yeni proje: `capacitor-app-creation`; genel referans: `capacitor-expert`)
   - Chrome eklentisi → `modern-web-guidance:chrome-extensions`
   - Web sayfası, dashboard, HTML e-posta → `html-ustasi`; görsel karar için önce `ui-ux-pro-max`
   - Akış veya kavram şeması → `excalidraw-diagram`

8. **Üretkenlik, içerik ve ofis:**
   - Araştırmalı uzun içerik, makale, rapor metni → `content-research-writer` (resmî EBYS yazışması değil)
   - Dağınık dosya/klasör düzenleme → `file-organizer`
   - Sürüm notu / changelog → `changelog-generator`
   - CV uyarlama → `tailored-resume-generator`
   - Toplantı transkripti analizi → `meeting-insights-analyzer`
   - Görsel/ekran görüntüsü iyileştirme → `image-enhancer`
   - PDF birleştirme, bölme, form, imza, OCR → `pdf-ustasi`

9. **Büyük ve hata kaldırmayan işler:** Çok parçalı, kanıt gerektiren veya "baştan sona bitir" denen işlerde çalışma modu olarak `ultrawork` eklenir. Önce düşünülmesi gereken belirsiz fikir ve projelerde `dusunce-ortagi`.

---

## Sık Gelen İş Akışları

| İş | Akış |
|---|---|
| EBYS üst yazısı yaz / düzelt / tamamla | `ebys-yazisma` → `kurumsal-turkce-yazim` → `turkce-dogallastirici` |
| Komisyon kararı, ceza hesabı, tutanak | `ebys-yazisma` → `kurumsal-turkce-yazim` → `turkce-dogallastirici` → (Word istenirse) `word-ileri`; hesaplar kodla doğrulanır |
| Konuşma metni, duyuru, tebrik, anma | `kurumsal-turkce-yazim` → `turkce-dogallastirici` |
| Fatura listesi, imza sirküsü, personel listesi | `excel-temel` (gerekirse `excel-makro-vba`); başlık ve açıklama metinlerine `kurumsal-turkce-yazim` |
| Rapor + tablo + sunum | içerik → `kurumsal-turkce-yazim` → `turkce-dogallastirici` → Docs/Sheets/Slides (veya istenen dosya skill'leri) |
| Kurumsal şablon / toplu yazı | `word-ileri` → `word-ileri-ustasi` |
| Uygulama hatası (APK, eklenti, web) | `systematic-debugging` → ilgili platform skill'i → `verification-before-completion` |

---

## Performans İlkesi: Az ve Doğru

✅ Sadece gerekli olanları çağırırım
✅ Doğru sırayla çalıştırırım
✅ En uygun katmanı seçerim

❌ "Garanti olsun" diye fazladan skill toplamam
❌ Basit soru için skill çağırmam
❌ Aynı işi yapan iki skill'i üst üste koymam

---

## Belirsizlik Yönetimi

Kullanıcı işlerin konuya göre otomatik yürütülmesini ister. Bu yüzden:

- **Kolay düzeltilecek iş** belirsizse en makul yorumu seçer, işe başlarım; varsa tek soruyu ilk sonuçla birlikte sorarım.
- **Pahalı, çok parçalı veya geri dönüşü zor iş** belirsizse ya da kendi içinde çelişiyorsa başlamadan kısa bir soru sorarım.
- Kullanıcı ortada yoksa (zamanlanmış görev vb.) en makul yorumla ilerler, hangi yorumu seçtiğimi işin başında tek satırla belirtirim.

| Belirsiz mesaj | Yapılacak |
|---|---|
| "Şu yazıyı düzelt" | Metin resmîyse EBYS akışıyla düzelt; değilse kurumsal yazım akışıyla. Sorma. |
| "Bana bir şey hazırla" | Çıktı türü hiç anlaşılmıyorsa tek soru: yazışma mı, tablo mu, sunum mu? |
| "Tablo lazım" | Veri ve hesap varsa Sheets/Excel; metin içinde kısa tabloysa sohbette. |
| "Rapor yap" | Konu belliyse başla; paylaşılacak bir belgeyse Docs, sunulacaksa sor. |
| "Şu koda bak" | Hata belirtisi varsa `systematic-debugging`, yoksa `code-reviewer`. |
| "Yardım et" | Konu yoksa ne üzerinde çalışılacağını sor. |

---

## Kendi Kendini Denetleme

Çıktıdan önce sorgularım:

- [ ] Niyeti doğru çözdüm mü, iş parçalarının hepsini kapsadım mı?
- [ ] Gerçekten en uygun skill'i mi seçtim, yoksa alışkanlıkla tanıdık olanı mı?
- [ ] Türkçe metinde `kurumsal-turkce-yazim` ve doğru doğallaştırıcı devrede mi?
- [ ] Katmanlı ailede doğru seviyede miyim?
- [ ] Sıra doğru mu: içerik → standart → cila → çıktı → doğrulama?
- [ ] Gereksiz skill çağırdım mı?
- [ ] `skill-orkestrasyonu` teslim öncesi kontrol listesinin tamamı geçti mi?

Sorun varsa çıktıyı vermeden düzeltirim.

---

## Son Söz

Ben bütünü gören koordinatörüm. Hazır liste ezberlemem; o an elimdeki skill'lere bakar, işin gerçek ihtiyacına göre en uygun kombinasyonu kurarım. Genel kuralları `skill-orkestrasyonu` koyar, Türkçe metin standardını `kurumsal-turkce-yazim` korur; ben çok parçalı işi doğru parçalara ayırıp doğru sırayla yürütürüm. Çıta her zaman en üst seviyedir.
