# powerpoint-ustasi

---
name: powerpoint-ustasi
description: Etkili PowerPoint sunumu hazırlama ustası. Kullanıcı "sunum", "PowerPoint", "slayt", "PPT", "konferans sunumu", "kurumsal sunum", "eğitim slaytı", "rapor sunumu", "slayt tasarımı", "geçiş efekti", "animasyon", "ana sayfa", "şablon", "konuşmacı notu" gibi ifadeler kullandığında devreye girer. Sunumun içeriğini, görsel düzenini ve akışını birlikte planlar; "AI tasarımı" hissi vermeyen, mesajı net iletilen profesyonel sunumlar oluşturur.
---

# PowerPoint Sunum Ustası

## Temel İlke

**Bir sunum slayt yığını değil, anlatılan hikâyedir.** İçerik, görsel ve akış bir bütündür. Slaytlar konuşmacının yardımcısıdır, **konuşmanın yerine geçmez**.

Bu skill `pptx` resmi skill'iyle birlikte çalışır: O dosyayı **üretir**, bu skill **iyi sunumun ne olduğunu** anlatır.

---

## BÖLÜM 1: Sunum Yapmadan Önce

### 5 Soru — Mutlaka Cevaplanacak

1. **Kim dinleyecek?** (Yöneticiler, akademisyenler, vatandaşlar, öğrenciler — herkes farklı)
2. **Ne kadar süre var?** (5 dk → 5-7 slayt; 30 dk → 15-20 slayt; saat → en fazla 30-40)
3. **Ana mesaj nedir?** (Tek cümleyle özetleyin. Yapamıyorsanız henüz hazır değilsiniz)
4. **Dinleyici ne yapsın?** (Karar versin? Onaylasın? Bilgilensin? Harekete geçsin?)
5. **Sunum sonrası ne kalsın?** (Slaytlar paylaşılacak mı? PDF olarak mı dağıtılacak?)

### Slayt Sayısı Hesabı

**Kaba kural:** Slayt başına **1.5 - 2 dakika**. Konuyu hiç bilmeyene anlatıyorsan bu artar.

| Süre | Slayt Sayısı |
|------|--------------|
| 5 dk | 3-5 |
| 10 dk | 6-8 |
| 20 dk | 12-15 |
| 30 dk | 18-22 |
| 60 dk | 30-40 |

**Uyarı:** Çoğu kötü sunum **çok fazla slayt** yüzünden başarısızdır. Kalabalık sunum dinleyiciyi yorar.

---

## BÖLÜM 2: Standart Sunum Akışı

### Klasik Yapı

```
1. Kapak slaydı
2. İçindekiler / akış
3. Bağlam (problem nedir?)
4. Yöntem / yaklaşım
5. Bulgular / içerik
6. Sonuç ve öneriler
7. Teşekkür / iletişim
```

### "Hikâye" Yapısı (Daha Etkili)

```
1. Kanca: "İşte size bir gerçek..." (dinleyiciyi içine çek)
2. Mesele: "Şu sorun var"
3. Geçmiş: "Şimdiye kadar şöyle olmuştu"
4. Dönüm noktası: "Ama şimdi şu değişti"
5. Çözüm: "Bizim önerimiz şu"
6. Hedef: "Bunu yaparsak şuraya varırız"
7. Çağrı: "Sizden istediğimiz şu"
```

Hikâye yapısı **dinleyicinin dikkatini sonuna kadar tutar**. Klasik yapı bilgi aktarmak için iyi, ikna etmek için zayıf.

---

## BÖLÜM 3: Slayt Tasarımı — Altın Kurallar

### 1️⃣ Slayt Başına Tek Fikir

**Yanlış:** "2026 Yılı Bütçe, Personel Durumu, Eğitim Faaliyetleri" — tek slaytta 3 konu.

**Doğru:** Her slayt **bir mesaj** taşır. 3 konuysa 3 slayt.

### 2️⃣ Az Yaz, Çok Söyle

**Yanlış:** Slaytta paragraf paragraf metin → Dinleyici **slaytı okur, seni dinlemez**.

**Doğru:** Slaytta **anahtar 3-7 kelime** veya bir görsel. Detayı **konuşmacı notuna** yaz.

**Kabul edilebilir maksimum:** Slayt başına **6 satır × 6 kelime** (klasik 6×6 kuralı). Bunu da abartmayın.

### 3️⃣ Bir Görsel Bin Kelime

**Bir grafik bir tablodan iyidir. Bir görsel bir cümleden iyidir.** İmkân varsa görsel kullan.

### 4️⃣ Tutarlılık

Bütün slaytlarda:
- **Aynı font**
- **Aynı renk paleti**
- **Aynı düzen mantığı**
- **Başlık konumu sabit**
- **Logo aynı yerde**

### 5️⃣ Boşluğa Saygı

Slaytın **kenarlarına bir şey değmesin**. **Üstte ve altta boşluk** bırak. Sıkışık slayt amatör görünür.

---

## BÖLÜM 4: Tipografi

### Font Seçimi

**Sunum için ideal:**
- **Sans-serif** (kalın çıkıntısız) → Uzaktan okunaklı
- **Calibri, Open Sans, Source Sans Pro, Montserrat** → Modern ve okunaklı
- **Times New Roman** → Sunumda kullanma (kitap fontu)
- **Comic Sans, Papyrus** → Asla

### Punto

| Eleman | Punto |
|--------|-------|
| Slayt başlığı | 32-44 |
| Alt başlık | 24-28 |
| Madde işaretli liste | 18-24 |
| Dipnot/kaynak | 12-14 |

**Kural:** En küçük yazı **18 puntodan küçük olmamalı**. Salondaki en arkadaki kişi okuyabilmeli.

### Türkçe Kontrol

ç, ğ, ı, ö, ş, ü karakterlerinin **font ile uyumlu** olduğunu kontrol et. Bazı dekoratif fontlar Türkçe karakterleri bozar.

---

## BÖLÜM 5: Renk

### Sunum Renk Paleti

**3 temel renk seç:**

1. **Ana renk** (slayt arka planı, başlıklar)
2. **İkincil renk** (vurgular, alt başlıklar)
3. **Vurgu rengi** (önemli sayı, anahtar kelime)

**Örnek (Kurumsal Mavi):**
- Ana: `#003F87` (lacivert)
- İkincil: `#5B9BD5` (açık mavi)
- Vurgu: `#FFC000` (sarı)
- Metin: `#222222` (koyu gri, siyah değil)
- Arka plan: `#FFFFFF` (beyaz) veya `#F8F8F8` (kırık beyaz)

### Kontrast

Arka plan ile metin arasında **yüksek kontrast** gerekir:
- **Beyaz arka plan + koyu yazı** ✅
- **Koyu arka plan + açık yazı** ✅
- **Pastel arka plan + pastel yazı** ❌ (okunmaz)

### Kurumsal Sunum İçin

- Devlet kurumu: Koyu mavi/lacivert + beyaz
- Üniversite: Bordo + krem (geleneksel) veya modern paletler
- Şirket: Marka renklerine **uygun**

---

## BÖLÜM 6: Görsel Yerleştirme

### Resim Boyutu

- **Düşük çözünürlüklü** resim **kullanma** (pikselli görünür, profesyonelliği bozar)
- **Tam slayt** kapsayacak resim → minimum **1920x1080 px**
- **Stok fotoğraf klişelerinden** kaçın ("kurumsal el sıkışma" gibi)

### İyi Görsel Kaynakları

- Unsplash, Pexels (ücretsiz, kaliteli)
- Pixabay, Burst
- **Telif hakkı kontrol et** — özellikle resmi sunumda

### Grafik vs. Tablo

| Veri tipi | Tercih |
|-----------|--------|
| 2-5 sayı, karşılaştırma | **Grafik** |
| Detaylı çoklu sütun | **Tablo** |
| Trend (zaman) | **Çizgi grafik** |
| Bütünün payları | **Pasta grafik** (max 6 dilim) |

### Slaytta Tablo

- Maksimum **5-6 satır × 4-5 sütun**
- Daha büyük tablo varsa **Excel ekle** (dosya olarak), slayta koyma

---

## BÖLÜM 7: Madde İşaretleri

### Sık Yapılan Hata

```
• Personel sayısı arttı
• Bütçe büyüdü
• Yeni binaya geçildi
• Eğitim sayısı arttı
• Ödüller alındı
• Yeni projeler başladı
```

Bu sıkıcı. Dinleyici tek tek okumak zorunda. **Hiçbir hiyerarşi yok.**

### Daha İyi Yöntem

**Görsel hiyerarşi**:
- Ana mesaj büyük, kalın
- Alt destek noktaları küçük

```
PERSONEL %15 ARTTI
├ 250 → 287 kişi
├ Yeni teknik ekip kuruldu
└ 12 yeni mühendis
```

### Liste Yerine Görsel

3 madde varsa: Maddeler yerine **3 ikon + 3 sayı**.
Süreçte madde varsa: Maddeler yerine **akış oku**.

---

## BÖLÜM 8: Slayt Ana Sayfası (Slide Master)

### Niye Önemli?

**Slayt Ana Sayfası**, tüm slaytların **şablon dosyasıdır**. Buraya yapılan değişiklik **tüm slaytlara yansır**.

### Açma

**Görünüm → Slayt Ana Sayfası**

### Yapılması Gerekenler

1. **Logo yerleştir** → Tüm slaytlarda otomatik görünür
2. **Sayfa numarası ekle** → Otomatik numaralandırma
3. **Üstbilgi/altbilgi** belirle
4. **Yazı stilleri** (başlık, alt başlık, gövde) bir kez ayarla
5. **Renk teması** seç

Bu yapı kurulduktan sonra slayt eklemek **çok hızlı** olur.

### Düzen (Layout)

Ana sayfada birden fazla **düzen** olur:
- Başlık slaydı
- Başlık + içerik
- İki içerik
- Boş
- Sadece görsel
- Vb.

Yeni slayt eklerken **hangi düzeni** kullanacağını seç. Karışıklık olmaz.

---

## BÖLÜM 9: Animasyon ve Geçişler

### Animasyon (Slayt İçi)

**Az kullan, etkili kullan.** Her slaytta animasyon = amatör.

**Faydalı animasyon türleri:**
- **Sırayla görünme**: Maddeleri tek tek getir, dinleyiciyi yönlendir
- **Vurgu**: Önemli kısma odaklanmasını sağla
- **Çıkma**: Eski içeriği temizle

**Yasaklılar:**
- ❌ Spin (dönen yazı)
- ❌ Bounce (zıplayan)
- ❌ Curve in/out
- ❌ Random

**Kabul edilebilir:**
- ✅ Fade (yavaş geliş)
- ✅ Appear (anında geliş)
- ✅ Wipe (yandan kayar)

### Geçiş (Slaytlar Arası)

**Tek bir geçiş tipi seç**, tüm sunumda kullan. Karışık geçiş = baş ağrısı.

**En iyi:** "Yok" veya "Solma" (Fade). Sade ve profesyonel.

---

## BÖLÜM 10: Konuşmacı Notu

### Nedir?

Slaytın **altında**, sadece konuşmacının gördüğü not. Slayt ekranda görünürken konuşmacı bunlardan okur (yardımcı olur).

### Kullanım

- Slaytta yazmadığın **detayları** buraya yaz
- Anekdotlar, örnekler
- Geçiş cümleleri ("Şimdi şu konuya geçelim...")
- Soru olabilecek noktalar için cevaplar

### "Sunum Modu"

PowerPoint'te F5'le sunum başlar. **İki ekran** varsa: Projeksiyon dinleyici slaytını gösterir, laptop ekranı **konuşmacı görünümü**: Mevcut slayt, **sonraki slayt önizlemesi**, konuşmacı notu, zamanlayıcı.

---

## BÖLÜM 11: Sunumdan Önce Son Kontrol

### Provayı Yap

- **Yüksek sesle** baştan sona oku
- **Süresini ölç** — fazla mı/az mı?
- Geçişler **doğal mı**?
- Anlaşılmayan kısım var mı?

### Teknik Kontrol

- [ ] **Yazım denetimi** (F7)
- [ ] Sayılar **tutarlı** mı (slayt 3'te 250 personel diyorsan slayt 8'de de 250 olmalı)?
- [ ] Tüm fontlar **mevcut bilgisayarda** var mı? (Sunum yapacağın yerde Calibri yoksa font değişir → Embed Fonts seçeneğini kullan)
- [ ] Görsellerin **tümü görünüyor** mu?
- [ ] Animasyonlar **çalışıyor** mu?
- [ ] **Backup**: PDF olarak da export et (yedek)
- [ ] **USB / cloud** — sunumu nereden açacağın hazır mı?

### "Murphy" Senaryoları

- Projeksiyon çalışmazsa? (PDF yedeği var mı?)
- Bilgisayar açılmazsa? (Başka cihazdan açabilir misin?)
- Saatler 16:9 değil 4:3 mü? (İki versiyon hazırla)
- İnternet çalışmazsa? (Online video varsa, indir)

---

## BÖLÜM 12: Sunum Sırasında

### Konuşmacı Davranışı

- **Slayta arkanı dönme** (dinleyiciye bak, sloganı aklında tut)
- **Slaytı okuma** (zaten yazılı, sen anlat)
- **Lazer pointer'i sürekli sallama** (dinleyici takip edemez, sadece vurgu için)
- **Soru için zaman bırak**

### Yedek Plan

- **3 dk eksik kaldı?** — Detay sorularıyla doldur
- **5 dk fazla vakit?** — Sona "kaynaklar" slaytı ekle, oradan akıt
- **Soru gelmedi?** — Kendin başlat: "Genelde merak edilen şu olur..."

---

## BÖLÜM 13: Resmi/Kurumsal Sunum İçin

EBYS bağlamında, devlet kurumu için sunum yapılırken:

### Olması Gerekenler

- **Kurum logosu** ve adı (kapakta büyük, sonraki slaytlarda küçük)
- **Tarih ve sunum yeri**
- **Sunan kişinin adı, unvanı**
- **Kaynaklar/mevzuat** atfı (varsa)
- **Sayfa numarası** (alt sağda)
- **Resmî dil** (klişe yığını olmadan)

### Olmaması Gerekenler

- ❌ Espri yok (ya da çok dikkatli)
- ❌ Aşırı renk
- ❌ Hareketli GIF'ler
- ❌ Stok fotoğraf abartısı
- ❌ Kişisel tarz aşırılığı

---

## Sonuç Kontrol Listesi

Sunum bitti, şimdi son kontrol:

- [ ] **Ana mesajı** tek cümleyle söyleyebiliyor muyum?
- [ ] Her slayt **tek bir fikir** mi taşıyor?
- [ ] **Slayt sayısı** süreyle uyumlu mu?
- [ ] **Tutarlı** font, renk, düzen var mı?
- [ ] **18 punto altı** yazı yok mu?
- [ ] **Türkçe karakterler** her yerde doğru mu?
- [ ] **Görseller** kaliteli ve uygun mu?
- [ ] **Animasyon** abartılı değil mi?
- [ ] **Konuşmacı notu** dolu mu?
- [ ] **Provayı** yaptım mı?
- [ ] **Yedek (PDF)** aldım mı?

---

## Son İlke

**Sen sunumu yaparsın, slayt yardımcı.**

Slayt ne kadar boş olursa konuşma o kadar etkili olur. Slaytı dolu yapan kötü konuşmacılar dinleyiciyi okumaya zorlar — kimse okumaz.

Sade, net, akıllı. Üç sıfat. Yeterli.
