# deep-research


---

## Dosya: `SKILL.md`

---
name: deep-research
description: Use this skill when the user's prompt requires (1) researching a topic across multiple sources, comparing options or alternatives, analyzing trends or history, understanding markets or industries, or reviewing literature or studies and (2) synthesizing that research into a comprehensive, narrative report. If you're planning to search the web or internal knowledge bases, consider using this skill. This skill coordinates research subagents, so use it only when you have a tool for spawning subagents (the Agent or Task tool); otherwise, research the question directly.
---

# Coordinating Deep Research

## Your Role

You are acting as the **coordinator**. Your job is to analyze the user's question, spawn subagents, and manage output files. In order to keep your context clean, you should never conduct research or write files directly. For the same reason, you also should not read the researcher.md or report-writer.md files.

As you work, if you have a to-do or task-list tool (for example TodoWrite, or TaskCreate and TaskUpdate), use it to keep the user informed of your plan and progress. For clarity, don't reference subagents in those items. For example, you might say "Conduct research" instead of "Spawn research subagents".

## Process

1. [If necessary] Ask the user follow up questions
2. Choose a title for this research and create its directories
3. Decompose the user's query to determine subagent count
4. Spawn research subagents (in parallel)
5. [If absolutely necessary] Conduct one additional round of research
6. Spawn report writer subagent
7. Deliver report to user

### 1. [If necessary] Ask the user follow up questions

Read the user's question and consider if there are any missing or ambiguous details that need to be clarified. Some examples include:
- Ambiguous terminology — Acronyms, jargon, or terms with multiple meanings across different fields
- Implicit geographic or jurisdictional context — Questions where the answer varies significantly by region but no region is specified
- Ambiguous entities — Company names, product names, or proper nouns that refer to multiple distinct entities

In order to avoid creating unnecessary friction with the user, follow ups should only be asked when they would meaningfully impact how research is conducted.

If you determine that you do need to ask follow up questions, do so with the AskUserQuestion tool.

### 2. Choose a title for this research and create its directories

First choose a title for this research. It names the folder that will hold this request's research notes and is also the filename of the report the user receives, where it is shown as the report's title, so make it a short, specific title for this research in the user's language and in sentence case: 3 to 6 words and under 50 characters (count them, and drop words rather than exceed either limit), using only letters, numbers and single spaces. Keep accented and non-Latin letters exactly as the user's language writes them (for example é, ñ, ü, 日本語) rather than converting them to plain ASCII, and use no hyphens, underscores, apostrophes or other punctuation. For example, a question about how the EU AI Act affects startups could use "EU AI Act startup obligations".

This research's folders go in the same directory you used for research earlier in this conversation, or, if this is the first research request here, in your current working directory (not /tmp or an uploads folder). Before settling on the title, recall the titles of any research reports you have already delivered earlier in this conversation, and, if a research_notes/ folder already exists in that directory, list it — each folder inside it holds the notes behind a report of the same name in reports/, possibly from an earlier conversation. Then pick the case that fits:
- New topic: choose a fresh title.
- Returning to, extending or updating an earlier topic: choose a title that still names the topic and says what this request adds or changes (for example "EU AI Act startup penalties", not just "Penalties"), or, if nothing distinguishes it from the earlier request, the earlier title with the next number added, dropping a word first if that would exceed the limits above (for example "EU AI Act startup obligations 2"). Note the path of the most recent earlier report on that topic and of its notes folder: you will pass them to the report writer in step 6 as background to build on. If that report or its notes folder is no longer on disk, pass on only what remains and research whatever is missing.
- The user asks for earlier research to be redone independently: choose a title as in the previous case, but do not pass the earlier material on.

In every case the title must differ from every report delivered earlier in this conversation and from every folder you see, so that this request's notes and report never mix with or replace an earlier one's. Never rename, move or write into an earlier request's folder.

Then create the folders research_notes/{research title}/ and reports/ in that directory. Quote these paths in shell commands, since the title contains spaces, and note the directory's absolute path — you will give the subagents absolute paths into these folders, and they will store their files there.

### 3. Decompose the user's query to determine subagent count

In order to effectively spawn and task subagents, determine if and how the user's question can be decomposed into independent subtopics. These subtopics should be mutually exclusive and collectively exhaustive. For each subtopic, then consider if the research requires (or would benefit from) multiple independent points of view.

| Researchers | Decomposition Strategy | Example |
|-------------|------------------------|---------|
| 1 | No meaningful decomposition — single factual question | "Who won the 2024 Super Bowl?" |
| 3 | Few natural angles or perspectives on a focused topic | "Effects of temperature on salmon migration" → (1) biological mechanisms, (2) observed population data, (3) climate projections |
| 4 | Distinct facets or evaluation criteria | "Compare CRM platforms for small businesses" → (1) pricing models, (2) feature comparison, (3) integrations ecosystem, (4) user reviews/sentiment |
| 5 | Multiple independent entities, regions, or domains | "AI regulation landscape" → (1) US federal, (2) EU/GDPR-AI Act, (3) China, (4) UK, (5) industry self-regulation |
| 6+ | Large enumerable set requiring systematic coverage | "Electric vehicle adoption rates by US state" → researchers assigned to regional clusters |

In the next step, you should spawn one subagent for each subtopic and independent point of view that you identified. When in doubt, 3 researchers is a reasonable default. If in step 2 you noted earlier research to build on, decompose only what this request adds or needs re-checked; the report writer will have the earlier material.

### 4. Spawn foreground research subagents (in parallel)

For each subtopic and independent point of view determined above, spawn a foreground research subagent.

To spawn research subagents, use the Agent tool (named Task in some versions) with subagent_type="general-purpose" and run_in_background=false. Ensure that you provide **extremely clear, specific** instructions to each research subagent. Be sure to propagate constraints of the original question to the research subagent (e.g., temporal, geographical). In the prompts below, replace {path_to_skill} with this skill's base directory (the directory this SKILL.md was loaded from), {absolute path of your working directory} with the path you noted in step 2, and {research title} with the title you chose in step 2. Follow the exact format provided below:

```
Agent(
  run_in_background=false
  subagent_type="general-purpose",
  description="{3-5 words}",
  prompt="Research {specific narrow topic}.

Objective: {clear description of what's covered in the desired output}

Key questions:
- {Specific question 1}
- {Specific question 2}

Suggested sources:
- {Types of source to prioritize}

Constraints:
- {Any bounds from the initial user query, including temporal or geographic}

Save your output notes to {absolute path of your working directory}/research_notes/{research title}/{topic}.md

**As a first step, you must read {path_to_skill}/references/researcher.md for instructions on how to conduct research.**"
)
```

Example of a good, clear, detailed prompt for a research subagent:

> Research the semiconductor supply chain crisis and its current status as of 2026.
>
> Objective: Compile a dense report of the facts, covering the current situation, ongoing solutions, and future outlook, with specific timelines and quantitative data where available.
>
> Key questions:
>  - What are current bottlenecks?
>  - What are the projected capacity increases from new fab construction?
>  - What are geopolitical factors affecting supply chains?
>  - When do experts predict supply will meet demand?
>
> Suggested sources:
> - Recent quarterly reports from major chip manufacturers like TSMC, Samsung, and Intel, found on investor relations pages or through the SEC EDGAR database
> - Industry reports from SEMI, Gartner, and IDC that provide market analysis and forecasts
> - Government responses, including US CHIPS Act implementation progress at commerce.gov, EU Chips Act at ec.europa.eu, and similar initiatives in Japan, South Korea, and Taiwan through their respective government portals
>
> Constraints:
> - Must reflect current state as of 2026 with prior issues clearly noted as such
>
> Save your output notes to {absolute path of your working directory}/research_notes/Semiconductor supply chain outlook 2026/semiconductor_supply_chain.md
>
> **As a first step, you must read {path_to_skill}/references/researcher.md for instructions on how to conduct research.**"

In order to ensure research is conducted as quickly as possible, it's essential that all subagents are spawned in parallel, i.e., that you make all your calls to the Agent tool in a single turn.

### 5. [If absolutely necessary] Conduct one additional round of research

Based on the task summaries returned by the research subagents, determine if there are any critical gaps that would make the report incomplete. If deemed absolutely necessary, spawn researchers in parallel to close those gaps. Spawning additional researchers in this step delays delivery of the report to the user, leading to a much worse experience, so this must be used with extreme care.

**This step can only be followed once** - after the researchers finish, move immediately to Step 6, regardless of what results you get back. If you kick off any more research, you will hit timeouts or rate limits, meaning the user will never get an answer to their query. **To help yourself remember this, you should always output "After these researchers finish, I will move directly to coordinating the report writer" when choosing to kick off additional research.**

### 6. Spawn foreground report writer subagent

After research is done, spawn a single report writer subagent. Use the Agent tool (named Task in some versions) with subagent_type="general-purpose" and run_in_background=false, and fill in the placeholders as in step 4. For {the user's original question}, state the question this report must answer in full — if this request returns to or extends earlier research, that is the earlier question as amended by this request (for example "How does the EU AI Act affect startups, including penalties?"), not just the follow-up message. On the line for earlier research, give the absolute paths of the earlier report and notes folder you noted in step 2, or write "none" if you noted nothing to build on or the user asked for an independent redo. Follow the exact format provided below:

```
Agent(
  run_in_background=false
  subagent_type="general-purpose",
  description="Write final report",
  prompt="Read the notes in {absolute path of your working directory}/research_notes/{research title}/ and synthesize into a research report that answers: {the user's original question}.

Earlier research in this conversation to build on: {absolute paths of the earlier report and notes folder from step 2, or "none"}

Save your final report to this exact path: {absolute path of your working directory}/reports/{research title}.md

**As a first step, you must read {path_to_skill}/references/report-writer.md for instructions on how to write your research report.**"
)
```

### 7. Deliver report to user

After the report writer is done, make the report available to the user: if you have a tool for sending files to the user (for example SendUserFile), send reports/{research title}.md with it; otherwise, if your environment has a user-visible outputs folder, copy the report there under the same filename; otherwise leave it at reports/{research title}.md. Then read the finalized report and send the user a brief summary (aim for 3-5 sentences) that says where the full report is (sent to them, in the outputs folder, or its absolute path).


---

## Dosya: `references/report-writer.md`

# Writing a Research Report

You are reviewing comprehensive research notes put together by a team of researchers and synthesizing them into a focused, well-structured report. Your top priority is delivering a high-quality research report that answers the user's query as best and as completely as possible.

## General Process

1. Find and read all the research notes in the specified folder. If your assignment lists earlier research to build on, read that report and those notes too as additional input and reuse what is still relevant; where they disagree with the notes in your folder, the notes in your folder win, and your report must stand on its own rather than refer the reader to the earlier one. Paths may contain spaces, so use the Read tool or quote them in shell commands.
2. Plan out the signpost headers for your report based on the writing guidelines below
3. Write and save the full report to the specified path

## Report Format

```markdown
# {6-word compelling title with active verb}
{BLUF paragraph: Lead with the key finding, then significance, impact, and essential context. One paragraph, roughly 5-8 sentences}

## {Narrative signpost header with specific insight}
{Dense narrative-form paragraphs with **bold key facts**. Cite facts inline with `([Source](URL))`. Paragraphs should flow naturally — no bullet points or numbered lists}

## {Second signpost header}
{Continue with dense paragraphs in the same format as above}

<!-- Repeat signpost sections as needed: 3-5 total -->

## Conclusion
{1-2 paragraphs of novel takeaways and implications only — no repetition of earlier content}
```

## Detailed Specs

### Title
- ~6 words, concise, interesting, draws the reader in
- Use active verbs when possible

## BLUF paragraph
- Lead with the most important finding, then expand into significance, impact and context - the first sentences should directly answer the user's primary question
- One paragraph - prioritize density over sentence counting
- The reader should be able to stop here and walk away informed

### Section headers
- Sentence case, not title case
- Act as **signposts** - a reader skimming only headers should understand the report
- Use specific numbers or narrative framing
- Each header should feel fresh and distinct from others

Good -> Bad examples:
| Good | Bad |
|------|-----|
| "Migratory geese forage 370 extra hours annually" | "Effects of climate on geese" |
| "Nocturnal feeding extends the foraging day" | "Feeding behavior changes" |
| "Arctic summer eliminates circadian constraints" | "Environmental factors" |

If helpful for readability, you can include sub-headers within a section. These sub-headers should follow the same rules outlined above.

### Body paragraphs
- Write in dense, narrative prose that balances scholarly rigor and clarity with narrative form
- Don't use bullets or numbered lists
- **Bold** the most critical facts and figures to enable quick scanning
- Cite facts inline with `([Source](URL))`. You must include citations so the user can review sources.
- Each section should advance the argument, not just catalog information
- Use tables or rich markdown formatting when these elements significantly help.

### Conclusion
- Be concise. Use 1-2 paragraphs maximum
- Include key takeaways and novel insights only
- Show how understanding has changed or what it implies going forward
- Don't summarize or repeat earlier content

## Writing guidelines

### Length

You should tailor the report's style and length to match the user's request and what is most appropriate for the topic. An in-depth scientific question likely warrants a long, rigorous, detailed report, while an engineering question likely warrants decision-ready, precise technical answers. In general, a focused report that clearly communicates key insights is far more valuable than a longer report that includes everything. However, if the user's question requires depth and breadth, then make the report as long as necessary to cover everything important.

A good rule of thumb is to include 3-5 focused sections with clear headers.

### Writing style

The report should have a clear narrative arc guiding readers. The opening (following the BLUF) establishes stakes and poses questions. The body develops analysis with strong supporting evidence. The conclusion doesn't just summarize, but shows how understanding has changed or offers novel insights.

In your writing you should:
- Maximize information density while maintaining narrative form and clarity
- Use clear, direct, concrete language in active voice, eliminating unnecessary words
- Avoid hedging ("may", "possibly")
- Vary sentence rhythm, front-load key points, create elegant transitions, and maintain concision
- Maintain a tone of approachable intelligence - informative but not stiff, demonstrating expertise through facts and analysis while using conversational language

### Analytical rigor

Be sure to maintain epistemic honesty:
- Explicitly state what is uncertain or unknown
- Consider different angles or steelman alternative positions
- For scientific or analytical questions, develop and explore hypotheses
- Take positions based on research - come to conclusions about what is true, don't just give overviews.

### Dealing with data

You should interpret what data *means* rather than just stating facts without context:
- Prioritize synthesis showing how the information connects, rather than listing pure facts
- Weave quantitative and qualitative insights together
- Balance stories with numbers and facts where relevant.

### Citations

You must include inline citations using the `([Source](URL))` format following key claims, so that the user can verify sources. Focus on:
- Major findings that readers would want to verify
- Quantitative claims and statistics
- References to specific published media
- Not every sentence - cite strategically

If a research note contains a specific major finding, quantitative claim, or reference to published media without an inline source URL, do not include it in the final report. A report with 5 well-sourced claims is better than one with 20 claims where half are unsourced.


---

## Dosya: `references/researcher.md`

# Executing Research

You've been assigned to a specific research task as part of a larger effort. Other researchers are covering adjacent areas in parallel, so focus exclusively on your assigned scope.

## Your Goal

Meet the objective and answer the key questions you were given.

Your notes will be read by a report writer who will synthesize findings from all researchers into a final report. The writer won't do any additional research, so your notes must be comprehensive, self-contained, and well-sourced.

## How to Research

Core loop:
1. Reflect on what knowledge gaps exist to meet your objective and answer key questions
2. Use search tools (WebSearch or internal knowledge base searches) to collect information to close those gaps - generally shorter queries (<5 words) provide better results
3. Use fetch tools (WebFetch or internal document retrieval) to get the full content of promising pages from your search results - snippets from search are easy to take out of context
4. Repeat steps 1-3 until you hit one of the stop conditions below

Guidelines:
- If search results are sparse, try broader queries
- Never repeat the exact same query — always vary phrasing or you will get the same results
- Parallelize search and fetch tool calls as much as possible
- Roughly 10 tool calls is typical; avoid exceeding 15 in order to provide timely responses and prevent timeouts

## When to stop

- You've met your objective and answered your key questions with well-sourced findings
- You're no longer finding any new, relevant information
- You're approaching or have hit 15 tool calls

## Evaluating Sources

After receiving results from web searches or other tools, pay attention to the details of tool results, and do not just take them at face value. Maintain epistemic honesty and practice good reasoning by ensuring sources are high-quality and only reporting accurate information in your notes.

Before including a finding, consider:
- Is this speculation or confirmed fact (mentioning predictions, using verbs like "could" or "may", using narrative driven speculation with future tense, etc.)?
- Is this the original source or an aggregator? Prefer primary sources.
- Is this source generally problematic (using false authority, pairing passive voice with nameless sources, using general qualifiers without specifics, parroting unconfirmed reports, etc.)?

For recent topics, defer to search results over your training data as facts may have changed.

When sources conflict or there are potential issues with results, note that explicitly. Don't silently pick a conflicting source or report a suspect fact. When information is sparse, unavailable, or unreliable, say so clearly. Noting "I found no reliable sources on X" communicates valuable signal for the report-writer.

## Output

Save your findings to the path specified in your assignment, using the Write tool (the path may contain spaces, so quote it if you use a shell command instead). The parent directory has already been created by the coordinator.

Structure your notes using exactly these three sections. If helpful, sub-headings within sections are fine for organization, but do not add other top-level sections:

```markdown
# {Your Assigned Topic}

## {Key Question 1}

### Takeaway
{1-2 sentence summary with the key takeaway from the research}

### Cited Findings
- {Fact, stat, claim, or opinion} — [Source](URL)
- {Fact, stat, claim, or opinion} — [Source](URL)
- {Fact, stat, claim, or opinion} — [Source A](URL); contradicted by [Source B](URL)

### Inferences
- {Inference made based on cited findings}

### Gaps
- {Question that couldn't be answered and why}

{repeated for each key question}
```

Never fabricate information. If you can't find a specific statistic, fact, opinion, etc. do not invent one. Instead you should note the missing information as a gap. This is essential to making sure that the report is accurate.

To that end, every fact or claim listed in your report must have an inline [Source](URL). If you cannot find a source move it to the Gaps section.

Focus on specific, citable facts that answer your key questions. The report-writer needs concrete material to synthesize, not vague summaries.
