# openbb-piyasa-verisi

---
name: "openbb-piyasa-verisi"
description: "Hisse, döviz, makroekonomi ve piyasa verisi çekme ya da finansal veri analizi istendiğinde OpenBB Platform'u kurup kullanmak için. Yatırım tavsiyesi vermez."
---

# OpenBB ile Piyasa Verisi

OpenBB Platform, birçok veri sağlayıcısından piyasa, temel ve alternatif verilere tek bir arayüzden erişmeyi sağlayan açık kaynaklı bir veri platformudur.

## Ne zaman kullanılır
- Kullanıcı hisse, endeks, döviz, ekonomik gösterge ya da şirket verilerini çekip tabloya ya da grafiğe dönüştürmek istiyorsa.
- Birden çok kaynaktan gelen finansal verinin tek yerde toplanması isteniyorsa.

## Çalışma ilkeleri
1. Yatırım tavsiyesi verme, al ya da sat önerisinde bulunma. Veriyi, hesabı ve olgusal özeti ver. Kararı kullanıcı verir. Hukukçu ya da finans danışmanı olmadığını belirt.
2. Güncel fiyat ve veri her zaman çekilen kaynağa dayansın, hafızadan rakam yazma. Verinin kaynağını ve çekim zamanını belirt.
3. Çalışma alanının ağ erişimi izin listesiyle sınırlıdır. Veri sağlayıcısına erişim reddedilirse bunu açıkça söyle, başka yolla dolanma. Betiği kullanıcının kendi bilgisayarında çalışacak biçimde hazırlamayı öner.
4. Bazı sağlayıcılar API anahtarı ya da ücretli abonelik ister. Hangisinin ücretsiz, hangisinin ücretli olduğunu kurulumdan önce kullanıcıya bildir. Anahtarları dosyalara yazma, kullanıcıdan ortam değişkeni olarak vermesini iste.

## Kurulum
- Çekirdek: `pip install openbb`
- Grafik desteği: `pip install "openbb[charting]"`
- Yahoo Finance bağlayıcısı: `pip install openbb-yfinance`
- Tüm uzantılar: `pip install "openbb[all]"`
- Sanal ortam içinde kurulum önerilir. Python sürüm uyumunu kurulumdan önce resmî belgeden doğrula (https://docs.openbb.co/platform/installation). Çalışma alanında pip komutuna `--break-system-packages` eklemek gerekebilir.

## Kullanım
- İçe aktarım: `from openbb import obb`
- Komut ve sağlayıcı adlarını sürüme göre resmî belgeden doğrula, çünkü uzantı adları sürümler arasında değişmiştir.

## Teslim
Sonucu Excel dosyası, tablo ya da grafik olarak ver. Rakamları yeniden hesaplayarak doğrula.
