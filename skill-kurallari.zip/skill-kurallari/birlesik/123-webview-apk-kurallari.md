# webview-apk-kurallari

---
name: webview-apk-kurallari
description: Android WebView içinde çalışacak HTML/CSS/JS arayüzler için zorunlu kısıtlar. Capacitor, Cordova veya WebView sarmalayıcı ile APK/AAB olarak paketlenecek her arayüz işinde uygulanır. Tetikleyiciler - APK, Capacitor, WebView, Android uygulaması, mobil HTML, hibrit uygulama, offline çalışan sayfa, tek dosya mobil arayüz. Bu skill görsel yön belirlemez; taste-skill veya ui-ux-pro-max ile birlikte çalışır ve onların çıktısını WebView gerçekliğine göre kısıtlar.
---

# WebView / APK Arayüz Kuralları

Bu kurallar tasarım tercihi değil, teknik zorunluluktur. Görsel yönü başka bir skill belirler; burada yazanlar onun üzerine kısıtlama olarak biner ve çakışma hâlinde **burası kazanır.**

## 1. Ağ bağımlılığı — mutlak yasak

Uygulama uçakta, metroda, şebekesiz açılacak. Dış kaynak çağrısı yapan her satır bir hatadır.

- Tailwind CDN, Bootstrap CDN, herhangi bir CSS CDN → **yasak.** Tailwind'i lokalde derleyip tek CSS dosyası olarak göm.
- Google Fonts, Adobe Fonts, `@import url(...)` → **yasak.** `.woff2` dosyalarını `assets/fonts/` altına indir, `@font-face` ile yerel tanımla.
- CDN'den ikon seti, `cdn.simpleicons.org` gibi çağrılar → **yasak.** İkonları inline SVG olarak göm.
- CDN'den GSAP veya herhangi bir JS kütüphanesi → **yasak.** npm ile kur, bundle'a dahil et.
- `<img src="https://...">` → **yasak.** Görseller `assets/` altında yerel olmalı.

Kod yazmadan önce kendine sor: bu dosya internetsiz açılırsa ne eksik görünür? Cevap "hiçbir şey" olmalı.

## 2. Yerleşim

- `100vh` **kullanma**, `100dvh` kullan. Android'de adres çubuğu ve klavye açılınca `vh` yanlış değer döndürür.
- `<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">` zorunlu.
- Ekranın kenarına değen her öğede `env(safe-area-inset-top/bottom/left/right)` kullan. Yoksa içerik çentiğin ve jest çubuğunun altında kalır.
- Yatay taşma (`overflow-x`) kabul edilemez. WebView'da yatay kaydırma uygulamayı bozuk gösterir.
- Sabit piksel genişlik yok. 360 px genişliğinde ucuz bir cihazda da, 412 px'lik bir cihazda da düzgün durmalı.

## 3. Dokunma

- `:hover` durumuna görsel olarak güvenme. Dokunmatikte hover state dokunduktan sonra yapışık kalır. Geri bildirimi `:active` ile ver.
- Dokunulabilir her öğe en az **48×48 px**. Görsel olarak küçük olabilir ama dokunma alanı padding veya `::after` ile büyütülmeli.
- `-webkit-tap-highlight-color: transparent` ver ve yerine kendi `:active` durumunu tanımla.
- Metin seçilmesi gerekmeyen arayüz öğelerinde `user-select: none`.
- `input` alanlarında `font-size: 16px` altına inme; Android/iOS otomatik yakınlaştırma yapar.

## 4. Performans — orta segment cihaza göre yaz

Hedef amiral gemisi telefon değil, 3 yıllık orta segment bir Android.

- `backdrop-filter` ve büyük yarıçaplı `blur()` **kaçın.** Glassmorphism masaüstünde şık, WebView'da kare düşürür. Gerekiyorsa tek bir öğede, küçük yarıçapla.
- Animasyonu yalnızca `transform` ve `opacity` üzerinden yap. `width`, `height`, `top`, `left`, `margin` animasyonu layout thrashing üretir.
- Scroll'a bağlı sürekli hesaplama yapma. Gerekiyorsa `IntersectionObserver` kullan, `scroll` olayında hesap yapma.
- `will-change` yalnızca animasyon süresince, sonra kaldır. Kalıcı bırakmak belleği şişirir.
- `prefers-reduced-motion: reduce` sorgusuna mutlaka uy — hem erişilebilirlik hem performans kaçışı.
- Aynı anda 2'den fazla sürekli animasyon çalışmasın.

## 5. Kapanış kontrolü

Kod teslim etmeden önce bu listeyi tek tek doğrula ve sonucu yaz:

1. Tek bir dış URL çağrısı kaldı mı? (fontlar, ikonlar, kütüphaneler, görseller dahil)
2. `vh` birimi kaldı mı?
3. Safe area inset uygulandı mı?
4. Her dokunma hedefi 48 px'e ulaşıyor mu?
5. `backdrop-filter` veya ağır blur kaldı mı?
6. Animasyonların hepsi `transform`/`opacity` ile mi?
7. `prefers-reduced-motion` karşılığı var mı?

Maddelerden biri bile geçmiyorsa kodu teslim etme, düzelt.
