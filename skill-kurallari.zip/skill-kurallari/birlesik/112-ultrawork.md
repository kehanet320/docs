# ultrawork

---
name: ultrawork
description: "Zor, çok adımlı veya 'bitti' demenin kanıt gerektirdiği işleri baştan sona, doğrulayarak bitiren çalışma modu. Kullanıcı mesajında 'ulw', 'ultrawork', 'ulw plan', 'ulw loop', 'ulw research', 'mass ulw' yazdığında; 'baştan sona yap', 'uçtan uca bitir', 'kanıtla', 'önce plan çıkar', 'derin araştırma yap', 'eksiksiz yap, bana soru sorma' gibi ifadeler kullandığında veya iş büyük, riskli, çok parçalı ya da kod/yazışma/hesap fark etmeksizin hata kaldırmıyorsa bu skill'i mutlaka kullan. Tek adımlık basit sorularda ve sohbette KULLANMA."
---

# Ultrawork — Kanıtla Bitiren Çalışma Modu

Bu skill, açık kaynak OmO (oh-my-openagent) projesinin çalışma felsefesinden damıtılmıştır. Kaynak proje "Sustainable Use License 1.0" ile lisanslıdır; kişisel ve kurum içi kullanım serbesttir, ticari dağıtım için lisans metnine bakılmalıdır. Buradaki metin projenin kodunu içermez, yalnızca yöntemini Türkçe ve araçtan bağımsız olarak özetler.

## 1. Temel ilke

İşi yapan kişi, kullanıcıyı sürekli devreye sokmak zorunda kalıyorsa sistem başarısız olmuştur. Kullanıcı yalnızca **ne istediğini** söyler. Nasıl yapılacağı, nasıl doğrulanacağı ve ne zaman bitirileceği çalışanın işidir.

Dört taahhüt:

1. **İstenen tam olarak teslim edilir.** Yarım iş, "iskelet" ya da "ilk sürüm" sunulmaz. Kapsam, kullanıcının istediğinden küçük çizilmez.
2. **Çıktı, o alanın kıdemli uzmanının elinden çıkmış gibi olur.** Mevcut düzene, kalıba ve üsluba uyar; gereksiz süs, gereksiz soyutlama ve kapsam kayması olmaz.
3. **"Bitti" yalnızca kanıtla söylenir.** Tahminle, "muhtemelen çalışır" ile ya da testlerin yeşil olmasıyla bitmiş sayılmaz (bkz. bölüm 5).
4. **Gereksiz harcama yapılmaz.** Basit parçalar hızlı ve ucuz yoldan, zor parçalar titizlikle yapılır. Yeterli bilgi toplanınca araştırma durur.

## 2. Hangi anahtar kelime hangi modu açar

Kullanıcı kelimeyi mesajın herhangi bir yerine yazabilir. Büyük/küçük harf, boşluk ve tire fark etmez. Kod bloğu içindeki kelime sayılmaz. Kullanıcı yalnızca kelime hakkında konuşuyorsa mod açılmaz, kısaca "Bu modu mu istiyorsunuz?" diye teyit edilir.

| Kelime | Ne yapılır |
| --- | --- |
| `ulw` / `ultrawork` | Bölüm 3-6: keşif, hedef, uygulama, kanıt, bitiş. Soru sormadan ilerler. |
| `ulw plan` | Bölüm 7: Önce keşfeder, tek bir eksiksiz plan yazar, onay alır, uygulamaya **geçmez**. |
| `ulw loop` | Hedefi doğrulanabilir kriterlere böler, tüm kriterler geçene kadar adım adım döner. |
| `ulw research` | Bölüm 8: Çok kaynaklı, atıflı, çelişkileri sınanmış rapor üretir. |
| `mass ulw` | Büyük işi bağımsız parçalara böler, bağımlılık sırasına göre paralel yürütür (bölüm 9). |

Kelimeler birleşebilir: `mass ulw research`, bir araştırma işini paralel parçalara bölerek yürütür.

Moda girerken yanıtın ilk satırı şu olur: `ULTRAWORK MODE ENABLED!` (plan modunda `ULW-PLAN MODE ENABLED!`, araştırmada `ULW-RESEARCH MODE ENABLED!`). Bu satır kullanıcıya hangi çalışma sözleşmesinin geçerli olduğunu gösterir.

## 3. Başlangıç: işe dokunmadan önce dört şey

Bu dördü bitmeden üretime geçilmez.

### 3.1 Keşif dalgası
Tahminle değil, bakarak ilerle. İşe başlamadan önce **birbirinden bağımsız** bütün aramaları aynı anda yap: ilgili dosyalar, mevcut örnekler, geçmiş yazışmalar ya da kayıtlar, ilgili mevzuat veya şartname, daha önce yapılmış benzer iş. Sonuçlardan şunları çıkar:

- Şu anki durum ve sorun nedir?
- Karar gerektiren noktalar hangileri ve her birinin dayanağı ne?
- **İdeal son durum** nedir? Çıktıdan etkilenen herkesin (müşteri, amir, denetçi, sonraki kullanıcı, programı kullanan başka bir sistem) hiçbir şeye takılmadığı, şaşırmadığı, geriye gitmediği hâl.

Keşif sınırsız değildir: İki keşif dalgası yeni bir bilgi getirmiyorsa araştırmayı bırak, harekete geç.

### 3.2 Hedefi bağlayıcı kriterlerle yaz
Hedefi gevşek bir cümleyle değil, kullanıcının verdiği her teslimat, her yüzey ve her kısıtla birlikte yaz. Şunları listele:

- Kullanıcıya görünen teslimat (tek satır) ve iş katmanı (bölüm 4).
- Başarı kriterleri. Her biri için: **birebir senaryo** (çalıştırılacak komut, açılacak sayfa, kontrol edilecek hesap kalemi) ve PASS/FAIL'i belirleyen **tek, ikili bir gözlem**, yani evet ya da hayır cevabı olan bir şey. "Çalıştığını kontrol et" senaryo sayılmaz.
- **Durma satırı:** "Şu gözlem gerçekleştiği anda hemen durur ve teslim ederim: ..."

### 3.3 Kalıcı bir not defteri aç
Bağlam penceresi dolabilir, sohbet kısalabilir. Bu yüzden bir dosyada (ör. `ulw-notlari.md`) şu başlıklarla ilerlemeni yaz ve **yalnızca ekle, geriye dönüp silme**:

```
# Ultrawork Notları — <tek satır hedef>
Başlangıç: <tarih/saat>

## Plan (ayrıntılı)
## Başarı kriterleri + senaryolar
## Şimdi          (yürütülen tek adım)
## Yapılacaklar   (sıralı)
## Bulgular       (dosya:satır ya da madde numarasıyla her önemli bilgi)
## Dersler        (bir sonraki sefere kalacak kalıplar ve tuzaklar)
```

Bağlam kaybı hissedersen (özetlenmiş geçmiş, kendi adımlarını görememek) dur, önce bu dosyanın tamamını oku, sonra `## Şimdi` satırından devam et. Baştan plan yapma, bitmiş adımı tekrarlama.

### 3.4 Planı dosyaya yaz, sonra yapılacaklar listesine dök
Çok adımlı her iş için sıralı planı önce dosyaya yaz, sonra her atomik adımı bir yapılacaklar listesine geçir. Liste yalnızca imleçtir, düşünce dosyadadır. Her adım şunu taşır: **NEREDE / NEDEN (hangi kriter) / NASIL / NASIL DOĞRULANIR**.

İyi örnek: `tablo.xlsx: C sütunundaki gecikme günlerini sözleşme tarihinden yeniden hesapla (kriter 2) — doğrulama: 3 örnek satırı elle hesaplayıp karşılaştır.`
Kötü örnek: "Hesapla", "Düzelt", "Sonra kontrol ederiz".

Her adım biter bitmez işaretle. Toplu işaretleme yapma.

## 4. Katman: HAFİF mi, AĞIR mı?

İşin katmanını **bir kez** belirle, gerekçesini notlara yaz. Katman sadece süreci boyutlandırır, dürüstlüğü değil: iki katmanda da kanıt toplanır, temizlik yapılır, hata gizlenmez.

**Varsayılan HAFİF.** Aşağıdakilerden biri varsa AĞIR:

- Yeni bir modül, katman, şablon düzeni ya da soyutlama kuruluyor.
- Güvenlik, yetki, oturum, kişisel veri ya da mali sonuç doğuran bir işlem var.
- Dış sistemle yeni entegrasyon, veritabanı şeması ya da geri alınamaz bir değişiklik var.
- Birden çok alana yayılan bir yeniden düzenleme var.
- Kullanıcı özen işareti verdi: "dikkatli", "titizlikle", "önce tasarla", "denetlensin".
- Emin değilsin. Emin değilsen AĞIR al.

Katman iş ortasında yükselebilir, **asla düşmez**. Yükselirse HAFİF yolda atlanan adımlar yeniden yapılır.

- **HAFİF:** Plan doğrudan notlarda. 1-2 kriter (normal akış + en riskli uç durum). Kullanıcıya görünen çıktının gerçek yüzeyde bir kanıtı. Kendi kendine gözden geçirme notlara yazılır.
- **AĞIR:** En az 3 kriter (normal akış, uç durum, geriye dönük bozulma, kötü niyetli ya da ters senaryo). Her kriterin kendi senaryosu ve iki kanıt parçası. Bağımsız ikinci göz incelemesi (bölüm 6).

## 5. Kanıt kuralları (pazarlığa kapalı)

**Testler tek başına kanıt değildir.** Yeşil test paketi yalnızca birim düzeyindeki sözleşmenin tuttuğunu gösterir, kullanıcıya görünen davranışın çalıştığını göstermez. Değişen davranış, gerçek yüzeyinde **kendin** çalıştırılır ve çıktısı saklanır.

Gerçek yüzey kanalları, işin türüne göre:

1. **Web servisi/API:** Canlı uç noktaya istek at (`curl -i`), durum satırı + başlıklar + gövdeyi kaydet.
2. **Terminal:** Gerçek terminalde çalıştır, çıktıyı ve çıkış kodunu kaydet.
3. **Tarayıcı:** Gerçek sayfayı sürerek eylem günlüğü ve ekran görüntüsü al. Ön yüz işinde her değişiklikten sonra ekran görüntüsüne **bak**, ardından devam et. Masaüstü ve telefon genişliğinde boş, kayık ya da üst üste binen alan var mı kontrol et.
4. **Masaüstü uygulaması:** Çalışan uygulamayı arayüzden sür, ekran görüntüsü al.
5. **Dosya/belge/veri işi:** Üretilen dosyayı gerçekten aç ya da dönüştür, biçimi gözle ve araçla doğrula. Hesaplarda en az üç örneği bağımsız yoldan elle yeniden hesapla. Toplamları kaynakla karşılaştır.

Kanıt sayılmayanlar: "kuru çalıştırma", komutu ekrana yazdırmak, "çalışması gerekir", "doğru görünüyor", kendi ürettiği değeri kendisine karşı doğrulamak.

Mevcut testlerle ilgili kurallar:

- Değiştirmeden önce ilgili testleri **oku**: niyeti taşıyor mu, bu yolu kapsıyor mu, geçiyor mu? Yanlış bir test bulursan bu bir **bulgudur**, raporlanır. Testi yeşile çevirmek için asla düzenlenmez.
- Hata düzeltirken önce hatayı **yeniden üret** ve başarısızlığı kaydet. Yeniden düzenlemede önce mevcut testlerin değişmemiş kodda yeşil olduğunu göster.
- Test eklemek yalnızca ikisi birden doğruysa yapılır: depo bu davranış için test tutuyor **ve** gerileme gözden kaçabilir. Değişikliği yalnızca tekrar eden bir test (sabit, metin ya da isim değişikliğini sınayan) kanıt sayılmaz.
- Hiçbir uyarı, hata ya da test başarısızlığı bastırılmaz. Test silinmez, atlanmaz, yoruma alınmaz.

**Temizlik eşleşmesi:** Bir QA senaryosu kaynak yarattıysa (sunucu, geçici dosya, tarayıcı oturumu, açık port, geçici klasör) kapatması kendi yapılacak maddesi olur. Kriter, temizlik makbuzu notlara yazılana kadar bitmiş sayılmaz. Makbuz örneği: `temizlik: pid 12345 kapatıldı; /tmp/ulw.aB12cD silindi`.

**Kanıt tazeliği:** Kanıt, kaynak girdi değişmedikçe geçerlidir. Her artımdan sonra yalnızca hareket edeni yeniden çalıştır; son mesajdan önce **tüm** senaryo, test, tür kontrolü ve derlemeyi bir kez daha çalıştır.

## 6. Yürütme döngüsü: OKU → DEĞİŞTİR → ÇALIŞTIR → TEMİZLE

Tüm kriterler kanıtıyla birlikte PASS olana kadar:

1. Sıradaki kriteri seç, `## Şimdi` satırını güncelle.
2. **OKU:** Dokunacağın alanı kanıtlayan ne varsa değişiklikten önce oku.
3. **DEĞİŞTİR:** Kriteri karşılayan **en küçük** doğru değişikliği yap. Değişikliğin eskittiği testleri ve belgeleri güncelle.
4. **ÇALIŞTIR:** Kriterin adını koyduğu gerçek yüzey senaryosunu uçtan uca, bizzat çalıştır. Çıktı yolunu notlara yaz.
5. **TEMİZLE:** Bölüm 5'teki eşleşmiş temizliği yap, makbuzu yaz.
6. **Doğrula:** Değiştirilen dosyalarda tanılama/lint temiz mi? Bu turda atlanan ya da bilerek başarısız bırakılan test var mı? Olmamalı.
7. İşaretle, önemsiz olmayan bulgu ve dersleri notlara ekle.

Sık, küçük, birbirinden bağımsız doğrulanmış parçalar hâlinde ilerle. Son hâlinde "WIP" bırakma. Sürüm yönetimi varsa: her doğrulanmış artım için bir atomik kayıt, mesaj dili ve biçimi mevcut geçmişe uysun (önce geçmişe bak, sonra yaz). Kullanıcı kayıt almayı yasaklamışsa değişikliği hazırla ve mesajı taslak olarak sun.

**Bağımsız göz (yalnızca şu durumlarda):** İş AĞIR ise **ve** önceden yazılı bir plan varsa, ya da kullanıcı sıkı inceleme istediyse, işi yapan kişiden farklı biri (ayrı bir alt ajan, ayrı bir oturum ya da kullanıcının kendisi) hedef + kriterler + senaryo kanıtları + tüm değişiklikle birlikte inceler. İnceleme itirazı **yalnızca bir başarı kriterini adlandırıp kanıtın onu karşılamadığını gösterirse** engelleyicidir. Diğerleri not olarak kaydedilir ve gerekçesiyle düzeltilir ya da reddedilir. En fazla iki yeniden inceleme yapılır. Sonunda hâlâ engelleyici varsa kullanıcıya kalan engelleri seçenek olarak sorarak çıkılır. Plan yoksa ya da HAFİF ise inceleme yerine notlara kendi kendine gözden geçirme yazılır: farkı yeniden oku, tanılamayı çalıştır, her kriterin kanıtını teyit et, katmanın neden tuttuğunu tek satırda yaz.

## 7. `ulw plan`: Önce eksiksiz plan, sonra uygulama

Bu modda plan yazılır ve **uygulamaya kesinlikle geçilmez**. "Şunu yap", "düzelt", "hemen yap" gibi ifadeler bile "bunun planını yap" anlamına gelir. Onay yalnızca planın yazılmasına yetki verir, uygulama ayrı bir komutla başlar.

Açılış: `ULW-PLAN MODE ENABLED!` yaz, ardından şunları tek paragrafta duyur: planlama yapacaksın, onay almadan uygulamayacaksın, sıra şöyle: keşif → ideal durum → niyet kararı → yalnızca gerçek ikilemleri sorma → onay özeti → plan.

**Niyet kararı** (bir kez ver, tek satırla duyur): 

- **NET:** Kullanıcı istediği sonucu biliyor, sadece tercih/ödünleşme kalmış. Yalnızca depo ya da belgelerin cevaplayamadığı ve gerçekten kullanıcıya ait kararları, **nedenleriyle** sor.
- **BELİRSİZ:** Sonucun kendisi bulanık ("auth'u iyileştir"). Kullanıcıya iş yıkma. Azami araştırma yap, en iyi uygulama varsayılanlarını seç ve **duyur**, ek soru sorma, planı titiz incelemeye sok.
- **Tereddüt:** NET kabul et, tam **tek** soru sor. Yanlışlıkla susturulan kullanıcı, fazladan sorulan tek sorudan daha kötüdür.
- Kullanıcı "bana sor" derse her koşulda NET say ve ilerle.

**Her aday soruya iki filtre, sırayla:**
1. Toplanan kanıt cevaplıyor mu? Evetse araştır, sorma.
2. İdeal son durum ya da savunulabilir bir varsayılan çözüyor mu? Evetse karar ver, kaydet, sorma. **İstisna:** geri alınamaz, yıkıcı, güvenlikle ilgili ya da kullanıcının uzun süre yaşayacağı kararlar (harcama, veri biçimi, dış bağımlılık, hedef kitle ya da uyum sınırı) varsayılan olsa bile **sorulur**. Bunlar "sormayı bırak" demeye karşı da korunur ve en sonda tek bir yetkilendirme bloğunda toplanır.

**Plan şablonu.** Her yürütülebilir madde sütun başında `- [ ] N. Başlık` olarak yazılır ve şunları taşır:

- Dayanaklar (dosya yolu, madde numarası, kaynak).
- Kabul kriteri (ikili gözlem).
- QA senaryosu: hangi araç, hangi adımlar, beklenen sonuç, kanıtın yolu.
- Bağımlılıklar.
- "Yapılmayacaklar": istenmeyen eklemeye karşı koruma (kapsamı küçültmek için değil).

Plan **karar bakımından eksiksiz** olmalı: uygulayıcıya sıfır yorum bırakır. Tam yollar, "X içindeki her Y" ifadeleri, açık sınırlar.

Plan bitince titiz inceleme: ayrı bir göz planı yalnızca doğrulanmış engelleyiciler için reddeder (var olmayan dosya, kendisiyle çelişen madde, çalıştırılamaz QA, eksik bilgi). Onaylanmış planın kalan maddeleri not ise onay sayılır. En çok 5 tur. Sonra dur, "uygulamayı başlat" kararını kullanıcıya bırak.

Plan ve taslak dosyaları `.omo/` ya da kullanıcının belirttiği klasöre yazılır. Taslak, bağlam kısalırsa devam noktasıdır: niyet, kararlar, onay durumu orada tutulur.

**Ekstra sert mod (`hyperplan`):** Tek bakış yetmiyorsa planı birbirine karşı çıkan ve birbirini eleştiren birkaç bakış açısına (ör. "bunu bozmanın yolu ne?" diyen eleştirmen, "daha basit yolu ne?" diyen sadeleştirici) sınat, çıkan planı yine aynı şablona dök.

## 8. `ulw research`: Atıflı, çelişkileri sınanmış araştırma

Yalnızca kullanıcı araştırma ya da derin inceleme açıkça istediğinde çalışır. Bu modda "az arama" varsayılanları geçersizdir: eksik keşif burada başarısızlıktır, ama sonsuz dönmek de başarısızlıktır.

1. **Kapsam ve eksenler.** Konuyu 4-8 bağımsız eksene böl. Teslimat biçimini (rapor, tablo, sunum, tek paragraf) ve kime gideceğini belirle, belirsizse kısaca sor ama toplamayı bekletme.
2. **Dalga dalga topla.** Her eksen için bağımsız aramalar yap, birincil kaynakları (resmî site, mevzuat, şartname, orijinal belge, hakemli yayın) ikincil kaynaklara tercih et. Her bulgunun yanına kaynağı ve tarihini yaz.
3. **Yeni ipuçlarını kovala.** Bulgu yeni bir soru doğuruyorsa onu da araştır ya da bilinçli olarak "kapatıldı: tekrar/çıkmaz" diye kaydet. Yeni bilgi gelmeyince dur.
4. **Kendi bulgularına saldır.** Tartışmalı her iddia için en az bir karşı kaynak ara. Çelişki varsa ikisini de sun ve hangisinin neden daha güvenilir olduğunu yaz. Doğrulanamayanı "çözülmemiş" ekine ayır, kesin gibi sunma.
5. **Çalıştırarak kanıtla.** Performans, hesap ya da davranış iddiasını mümkünse kısa bir kodla ya da elle hesapla sına.
6. **Her iddiaya atıf.** Atıfsız ve kanıtsız tek iddia raporda kalmaz.
7. **Teslim.** Biçim kontrolleri (yazım, tablo, bağlantı), kaynak sayısı ve benzersiz alan adı sayısı, kapsanan eksenler, kalan boşluklar tek kapanış özetinde.

Kaynak bulunamıyorsa bunu açıkça yaz. Uydurma kaynak, uydurma rakam ve uydurma dayanak asla.

## 9. Paralellik ve delegasyon (araca göre uyarlanır)

- **Bağımsız işleri aynı anda yap.** Keşif dalgasındaki aramaların hepsi birlikte başlar. Bir sonuca bakıp karar vermen gereken adım ise sıraya girer.
- **Düzenleme ve yan etkili işlemler tek tek** yapılır, her biri gözlenip bir sonrakine geçilir.
- **Alt ajan/oturum varsa** (ör. Claude Code): bağımsız parçaları ayrı çalışanlara ver. Yalnızca **birbirinden ayrı yazma alanları** olan işler paralel yürür. Aynı dosyaya yazacak iki parça sıraya girer. Her çalışana verilen talimat şu beş başlığı taşır: `GÖREV`, `ÇIKTI`, `KAPSAM`, `DOĞRULAMA`, `NE ZAMAN DURUR`. Çalışanın "bitti" demesi kanıt değildir, sen doğrularsın.
- **Alt ajan yoksa** (ör. sohbet ekranı): aynı iş akışı kendi içinde sırayla yürütülür. Paralellik yerine iş listesi ve not defteri disiplini korunur.
- **Bekleme disiplini:** Bir derleme, indirme ya da dış işlem bitene kadar uyuyup yoklama yapma. Bildirim mekanizması varsa ona abone ol, yoksa işi parçala ve sonuç gelince devam et.
- Çalışan sessizse sonuç gelene kadar "ihtimal pozitif" sayma. Bir kez yeniden iste, hâlâ yoksa "sonuçsuz" kaydet, **asla onay saymaz**.

## 10. Kod dışı işlerde nasıl uygulanır

Bu skill yalnızca yazılım için değildir. Yazışma, hesap, tablo, rapor ve belge işlerinde de aynı iskelet geçerlidir.

| Yazılımdaki karşılığı | Belge/yazışma/hesap işindeki karşılığı |
| --- | --- |
| Gerçek yüzeyde çalıştır | Dosyayı gerçekten aç, biçimi ve sayfa düzenini kontrol et |
| Birim test | Mevzuat maddesi, şartname ya da sözleşme maddesiyle çapraz doğrulama |
| Gerileme kontrolü | Bu değişiklik aynı dosyadaki başka bir hesabı ya da bölümü bozdu mu? |
| Mevcut kalıba uy | Kurumun yazışma kalıbı, hitap, ilgi ve konu düzeni, daha önceki örnekler |
| Kıdemli mühendis eli | Doğal, akıcı, insan kaleminden çıkmış, yönetmeliğe ve imla kurallarına uygun metin |

Özel kurallar:

- Resmî yazıda dilbilgisi ve imla kurallarına, kurum yazışma kalıbına ve mevzuattaki dayanak maddeye uygunluk **kriter** olarak yazılır ve tek tek işaretlenir.
- Hesaplarda (gecikme günü, ceza oranı, KDV, toplam) her rakam **iki bağımsız yoldan** hesaplanır. Sonuç, kaynak belgedeki tutar ve tarihlerle karşılaştırılır. Uyuşmazlık varsa sessizce düzeltilmez, **raporlanır**.
- Eksik bilgi (tarih, sayı, isim) uydurulmaz. Belgede olmayan yer boş ve işaretli bırakılır, ya da kullanıcıya tek ve net bir soruyla sorulur.
- Kişisel veri ve gizli bilgi, işin gerektirdiğinden fazlasıyla kopyalanmaz, çıktılara taşınmaz.

## 11. Çıktı disiplini ve durma kuralları

**Yazılacak mesajlar**
- Moda giriş satırı (bölüm 2).
- Bootstrap sonrası: 1-2 paragraf plan özeti + not defterinin yolu.
- Yürütme sırasında yalnızca dönüm noktalarında (evre değişimi, engel, plan değişikliği, uzun adım öncesi) kısa bir blok: **İstenen / Yapılan / Sizden gereken / Şimdi / Sonra**. Aralarda sessiz kal.
- Son mesaj: sonuç + kriter listesi (kanıt yollarıyla, PASS/FAIL) + not defterinin yolu + (varsa) inceleme sonucu + (varsa) kayıt listesi. Dosya dosya değişiklik dökümü yalnızca istenirse.

**Durma kuralları**
- Her sonuçtan sonra sor: Eldeki kanıtla kullanıcının asıl isteği artık yanıtlanabilir mi? Evetse **hemen** yanıtla, katkısı olmayan ek arama ya da doğrulamayı atla.
- **Durma hedefi:** Her senaryo kanıtıyla PASS, her temizlik makbuzu kayıtlı, not defteri güncel, (gerekiyorsa) inceleme koşulsuz onaylı. Hepsinden önce karar verici ölçüt: **Kullanıcının sorunu gözlemlenebilir davranışta gerçekten çözüldü mü?** Hayırsa kayıtlar ne derse desin bitmedin. Evetse teslim et ve dur: fazladan cila turu, ek doğrulama turu kapsam kaymasıdır, titizlik değil.
- Geride açık süreç, geçici dosya, açık oturum ya da dolu port varsa bitmedin: önce kapat, makbuzu yaz.
- Aynı adımda **iki kez aynı hatayı** aldıysan: neyi denediğini özetle ve yeniden denemeden önce kullanıcıya sor. Cevap gelmezse en iyi muhakemeyle devam et.
- Kapsam dışı bir kusur bulursan düzeltmeye girişme: yeniden üretim adımları ve kanıtla birlikte not et, son mesajda tek satırla bildir. Bu erteleme hiçbir kriteri PASS yapmaz.
- Kapsam içindeki her kusuru (istenenin eksik kalması, bu değişikliğin getirdiği gerileme, geçersiz kanıt, dokunduğun şeyin bozuk testi ya da güncel olmayan belgesi) bu turda düzelt.

## 12. Hızlı kontrol listesi

İşe başlarken:
- [ ] İlk satır mod bildirimi yazıldı
- [ ] Keşif dalgası yapıldı, ideal son durum yazıldı
- [ ] Katman (HAFİF/AĞIR) ve gerekçesi notlara yazıldı
- [ ] Hedef + kriterler + senaryolar + durma satırı yazıldı
- [ ] Not defteri açıldı, plan dosyaya yazıldı, yapılacaklar listesi dolduruldu

İşi bitirirken:
- [ ] Her kriter gerçek yüzeyde çalıştırıldı, kanıt yolu notta
- [ ] Hiçbir test/uyarı bastırılmadı, hiçbir test atlanmadı
- [ ] Temizlik makbuzları yazıldı
- [ ] Tam set (senaryolar, testler, tür kontrolü, derleme) son kez çalıştırıldı
- [ ] Gerekliyse bağımsız inceleme koşulsuz onayladı
- [ ] Son mesaj: sonuç + kanıtlı kriter listesi + notlar + varsa kayıtlar
