# excel-otomasyon-ustasi

---
name: excel-otomasyon-ustasi
description: Excel'in profesyonel otomasyon katmanını uygulamak için kullanılır. Kullanıcı "Excel add-in", ".xlam", "eklenti", "Ribbon özelleştir", "şerit menü", "CustomUI", "UserForm", "MultiPage", "ListView", "TreeView", "Class Module", "olay yakalama", "Dictionary", "Collection", "dizi (Array)", "ReDim", "transpose", "yavaş makro", "makro hızlandırma", "ScreenUpdating", "Application.Calculation", "kurumsal makro", "modüler VBA", "bordro otomasyonu", "KDV hesaplama otomasyonu", "bütçe otomasyonu" gibi ifadeler kullandığında devreye girer. Mevcut excel-makro-vba skill'inin üstüne bir uzman katmanı: gerçek üretim ortamına dayanıklı, hızlı, modüler, dağıtılabilir Excel otomasyonu kurar.
---

# Excel Otomasyon Ustası

## Genel İlke

**Bir makroyu yazmak başka, üretim ortamına çıkarmak başka.**

Bu skill, mevcut **excel-makro-vba** skill'inin üzerine inşa edilir. Önkoşul: o skill'in 12 bölümüne hâkim olmak. Burada anlatılanlar **gerçek üretim ortamı** içindir: dakikalar süren makroları saniyelere indirme, onlarca kullanıcıya dağıtılabilir add-in geliştirme, UserForm'u gerçekten kullanışlı kılma, Ribbon'a kendi sekmenizi koyma.

**Hedef seviye:** Tek sayfada çalışan deneme makrosu değil; bir kurumun aylık bordro/KDV/bütçe sürecini saniyelerle bitiren, hatasız, geri alınabilir, sürüm yönetimi yapılabilir otomasyon.

---

## Bu Skill Ne Zaman Devreye Girer?

| Durum | Bu skill mi, excel-makro-vba mı? |
|-------|----------------------------------|
| "Bir Sub yazıp bir hücreye yazsın" | **excel-makro-vba** |
| "For döngüsü nasıl yazılır" | **excel-makro-vba** |
| "100.000 satırlık veride makro 30 dakika sürüyor" | **bu skill** (Bölüm 1-2) |
| "VLOOKUP yerine VBA'da hızlı arama" | **bu skill** (Bölüm 2 - Dictionary) |
| "Karmaşık form, sekmeli (TabStrip / MultiPage)" | **bu skill** (Bölüm 3) |
| "Şeride kendi sekmemi eklemek istiyorum" | **bu skill** (Bölüm 4) |
| "Bu makroyu 20 bilgisayara dağıtmam lazım" | **bu skill** (Bölüm 5) |
| "Şirket içi KDV/bordro otomasyonu kuracağım" | **bu skill** (Bölüm 6) |

---

## BÖLÜM 1: Performans Ustalığı

### 1.1 Üç Temel Optimizasyon (Her Makronun İlk Satırı)

Bunlar **olmadan** ileri kod yazmak boşa kürek çekmektir:

```vba
Sub BaslangicAyarlari()
    Application.ScreenUpdating = False           ' Ekran çizimini durdur
    Application.Calculation = xlCalculationManual ' Otomatik hesaplamayı kapat
    Application.EnableEvents = False             ' Olayları kapat (Worksheet_Change vb.)
    Application.DisplayAlerts = False            ' Uyarı kutularını kapat
End Sub

Sub BitisAyarlari()
    Application.ScreenUpdating = True
    Application.Calculation = xlCalculationAutomatic
    Application.EnableEvents = True
    Application.DisplayAlerts = True
End Sub
```

**Kural:** Her ana makro `BaslangicAyarlari` ile başlar, hata yönetiminden sonra `BitisAyarlari` ile biter.

### 1.2 EN ÖNEMLİ KURAL: Hücre Hücre Yazma — Diziye Yaz, Bir Kerede Aktar

Excel'in en yavaş işi **VBA ile hücre arasında veri transferi**. Her `Cells(i,j).Value = x` yazımı kendi başına yavaştır.

**❌ Yanlış (yavaş — 100.000 satır = dakikalar):**

```vba
For i = 1 To 100000
    Cells(i, 1).Value = i
    Cells(i, 2).Value = i * 2
    Cells(i, 3).Value = "Satır " & i
Next i
```

**✅ Doğru (hızlı — 100.000 satır = saniyeden az):**

```vba
Dim veri() As Variant
ReDim veri(1 To 100000, 1 To 3)

Dim i As Long
For i = 1 To 100000
    veri(i, 1) = i
    veri(i, 2) = i * 2
    veri(i, 3) = "Satır " & i
Next i

' Tek bir transferle yazılır
Range("A1").Resize(100000, 3).Value = veri
```

**Tersi de geçerli — veriyi okurken de diziye al:**

```vba
Dim veri As Variant
veri = Range("A1:C100000").Value   ' Tek seferde belleğe al

Dim i As Long, toplam As Double
For i = 1 To UBound(veri, 1)
    toplam = toplam + veri(i, 2)   ' Bellekteki diziden oku (çok hızlı)
Next i
```

**Pratik etki:** 100.000 satırlık bir bordro hesabı, döngü yöntemiyle 4-5 dakika, dizi yöntemiyle 2-3 saniye sürer.

### 1.3 Range Okumalarının Tam Listesi

| İşlem | Yavaş | Hızlı |
|-------|-------|-------|
| 100K satır oku | `For Each` ile tek tek | `arr = rng.Value` |
| 100K satır yaz | `Cells(i,j) = x` döngü | `rng.Value = arr` |
| Satır sayısını al | `Rows.Count` üzerinde döngü | `Cells(Rows.Count, 1).End(xlUp).Row` |
| Aralık seçimi | `Range("A1").Select` + işlem | Doğrudan `Range("A1").Value =` |
| Sayfa değişimi | `Worksheets("X").Activate` | `Worksheets("X").Range(...)` |

**Asla kullanma:** `.Select`, `.Activate` (kayıt makrosunun bıraktığı şeyler). Doğrudan referans ver.

### 1.4 Son Satır/Sütun Doğru Bulma

```vba
' A sütununun son dolu satırı
Dim sonSatir As Long
sonSatir = Cells(Rows.Count, 1).End(xlUp).Row

' 1. satırın son dolu sütunu
Dim sonSutun As Long
sonSutun = Cells(1, Columns.Count).End(xlToLeft).Column

' Tablonun gerçek son hücresi (kullanılan alan)
Dim sonHucre As Range
Set sonHucre = ActiveSheet.UsedRange.SpecialCells(xlCellTypeLastCell)
```

**Uyarı:** `UsedRange` bazen şişer (silinen satırları hatırlar). Güvenilirlik için `End(xlUp)` tercih edilir.

---

## BÖLÜM 2: Veri Yapıları — Dictionary, Collection, Array

`Range` üzerinde her şeyi yapmak yavaş ve sınırlı. Profesyonel kod **bellekte** çalışır.

### 2.1 Dictionary — Hızlı Arama (VLOOKUP Yerine)

Dictionary, **anahtar → değer** ilişkisi tutar. Anahtara erişim **anında** (hash tabanlı).

**Kullanıma açmak:** İki yol var.

**Yol 1 — Early Binding (önerilir, IntelliSense çalışır):**
1. VBA Editör → Tools → References
2. **Microsoft Scripting Runtime** kutusunu işaretle

```vba
Dim sozluk As New Scripting.Dictionary
```

**Yol 2 — Late Binding (referans gerekmez, dağıtım için iyi):**

```vba
Dim sozluk As Object
Set sozluk = CreateObject("Scripting.Dictionary")
```

### 2.2 Dictionary Kullanımı — Pratik

```vba
Sub TCKimlikteAdSoyadBul()
    Dim sozluk As Object
    Set sozluk = CreateObject("Scripting.Dictionary")
    
    ' Personel listesi: A=TCKN, B=AdSoyad
    Dim veri As Variant
    veri = Sheets("Personel").Range("A2:B5000").Value
    
    ' Sözlüğe doldur
    Dim i As Long
    For i = 1 To UBound(veri, 1)
        If Not sozluk.Exists(veri(i, 1)) Then
            sozluk.Add veri(i, 1), veri(i, 2)
        End If
    Next i
    
    ' Şimdi başka sayfada hızlı arama yap
    Dim sorgu As Variant
    sorgu = Sheets("Bordro").Range("A2:A100000").Value
    
    Dim sonuc() As Variant
    ReDim sonuc(1 To UBound(sorgu, 1), 1 To 1)
    
    For i = 1 To UBound(sorgu, 1)
        If sozluk.Exists(sorgu(i, 1)) Then
            sonuc(i, 1) = sozluk(sorgu(i, 1))
        Else
            sonuc(i, 1) = "BULUNAMADI"
        End If
    Next i
    
    Sheets("Bordro").Range("B2").Resize(UBound(sonuc, 1), 1).Value = sonuc
End Sub
```

**100.000 satırda VLOOKUP:** dakikalarca. Dictionary ile: 2-3 saniye.

### 2.3 Dictionary — Benzersiz Liste Çıkarma

```vba
Dim sozluk As Object
Set sozluk = CreateObject("Scripting.Dictionary")

Dim veri As Variant
veri = Range("A2:A100000").Value

Dim i As Long
For i = 1 To UBound(veri, 1)
    sozluk(veri(i, 1)) = 1   ' Varsa üstüne yazar, yoksa ekler — kontrol gereksiz
Next i

' Sözlüğün anahtarları benzersiz değerler
Dim benzersiz As Variant
benzersiz = sozluk.Keys
Range("C2").Resize(sozluk.Count, 1).Value = Application.Transpose(benzersiz)
```

### 2.4 Dictionary — Gruplu Toplam (Pivot Alternatifi)

KDV beyannamesi mantığı: ürün koduna göre KDV oranı bazında toplam.

```vba
Sub KDVOraninaGoreTopla()
    Dim veri As Variant
    veri = Sheets("Faturalar").Range("A2:C50000").Value
    ' A=Ürün, B=KDV oranı, C=Tutar
    
    Dim grup As Object
    Set grup = CreateObject("Scripting.Dictionary")
    
    Dim i As Long, anahtar As String
    For i = 1 To UBound(veri, 1)
        anahtar = CStr(veri(i, 2))   ' KDV oranı
        If grup.Exists(anahtar) Then
            grup(anahtar) = grup(anahtar) + veri(i, 3)
        Else
            grup.Add anahtar, veri(i, 3)
        End If
    Next i
    
    ' Sonuçları yaz
    Dim sonuc() As Variant
    ReDim sonuc(1 To grup.Count, 1 To 2)
    
    Dim anahtarlar As Variant
    anahtarlar = grup.Keys
    
    For i = 0 To grup.Count - 1
        sonuc(i + 1, 1) = anahtarlar(i)
        sonuc(i + 1, 2) = grup(anahtarlar(i))
    Next i
    
    Sheets("Özet").Range("A2").Resize(grup.Count, 2).Value = sonuc
End Sub
```

### 2.5 Collection — Sıralı Liste

Dictionary anahtar-değerli, Collection sadece sıralı liste:

```vba
Dim liste As New Collection
liste.Add "Ankara"
liste.Add "İstanbul"
liste.Add "İzmir"

Dim sehir As Variant
For Each sehir In liste
    Debug.Print sehir
Next sehir
```

**Ne zaman Collection, ne zaman Dictionary?**
- Sadece ekleyip dolaşacaksan → **Collection**
- Anahtarla arama, var mı kontrolü → **Dictionary**

### 2.6 Array (Dizi) Detayları

```vba
' Statik dizi
Dim aylar(1 To 12) As String

' Dinamik dizi
Dim veri() As Double
ReDim veri(1 To n)              ' Tek boyutlu
ReDim veri(1 To n, 1 To 3)      ' 2 boyutlu

' Diziyi büyütürken eski değerleri koru
ReDim Preserve veri(1 To n + 100)   ' Sadece son boyut değişebilir

' Sınırlar
LBound(dizi)   ' Alt sınır
UBound(dizi)   ' Üst sınır
UBound(dizi, 1) ' 2D'de satır sınırı
UBound(dizi, 2) ' 2D'de sütun sınırı
```

**Önemli:** `ReDim Preserve` sadece **son boyutu** değiştirebilir. 2D dizide ilk boyutu değiştiremezsin.

### 2.7 Array — Tek Sütunu Diziye Almak

```vba
' Hücre aralığından 2D dizi gelir (1 sütunluk bile olsa veri(i, 1))
Dim sutun As Variant
sutun = Range("A1:A100").Value

Debug.Print sutun(5, 1)   ' 5. satırın değeri

' 1 satırlık aralık → 2D ama (1, j) olarak indekslenir
Dim satir As Variant
satir = Range("A1:E1").Value
Debug.Print satir(1, 3)   ' E1 değeri (yanlış değil — sütun 3)
```

---

## BÖLÜM 3: İleri UserForm

### 3.1 UserForm'un Anatomisi

VBA Editör → **Insert → UserForm**. Sağ tarafta **Toolbox** açılır. Sürükle-bırak ile eklenen kontroller:

| Kontrol | Ne işe yarar |
|---------|--------------|
| **Label** | Sadece okunur etiket |
| **TextBox** | Metin/sayı girişi |
| **ComboBox** | Açılır liste + yazılabilir |
| **ListBox** | Çoklu seçim listesi |
| **CheckBox** | Tek bağımsız onay |
| **OptionButton** | Birbirini dışlayan seçenek |
| **Frame** | Gruplama (OptionButton grupları için **şart**) |
| **MultiPage** | Sekmeli pencere |
| **TabStrip** | Aynı sayfanın sekmeli görünümü |
| **SpinButton** | Yukarı/aşağı sayı |
| **ScrollBar** | Kaydırma çubuğu |
| **Image** | Görüntü |
| **CommandButton** | Düğme |

### 3.2 Olaylar — UserForm'un Beyni

Her kontrolün **olayları** vardır. Çift tıklayarak kod penceresine girersin:

```vba
' Form açılırken
Private Sub UserForm_Initialize()
    ' Burada başlangıç değerleri, ComboBox dolduruma vs.
    ComboBox1.AddItem "Ankara"
    ComboBox1.AddItem "İstanbul"
    ComboBox1.AddItem "İzmir"
End Sub

' Form kapatılırken (X tıklanırsa)
Private Sub UserForm_QueryClose(Cancel As Integer, CloseMode As Integer)
    If CloseMode = vbFormControlMenu Then
        ' X ile kapatmayı iptal et — sadece düğme ile kapansın
        ' Cancel = 1
    End If
End Sub

' TextBox'a yazıldıkça
Private Sub TextBox1_Change()
    ' Her tuşa basışta tetiklenir
End Sub

' TextBox'tan ayrıldığında
Private Sub TextBox1_Exit(ByVal Cancel As MSForms.ReturnBoolean)
    If Not IsNumeric(TextBox1.Value) Then
        MsgBox "Sayı girin"
        Cancel = True   ' Çıkışı engelle
    End If
End Sub
```

### 3.3 ComboBox/ListBox — İleri Doldurma

```vba
' Sayfadan otomatik doldur (tek sütun)
Private Sub UserForm_Initialize()
    Dim sonSatir As Long
    sonSatir = Sheets("Personel").Cells(Rows.Count, 1).End(xlUp).Row
    
    ComboBox1.List = Sheets("Personel").Range("A2:A" & sonSatir).Value
End Sub

' Çoklu sütun
Private Sub UserForm_Initialize()
    ListBox1.ColumnCount = 3
    ListBox1.ColumnWidths = "60;100;80"
    ListBox1.List = Sheets("Personel").Range("A2:C100").Value
End Sub

' Çoklu seçime izin ver
Private Sub UserForm_Initialize()
    ListBox1.MultiSelect = fmMultiSelectMulti   ' Ctrl ile çoklu
End Sub
```

### 3.4 Veri Doğrulama Şablonu

Her CommandButton_Click'in başında **doğrulama** yapılır:

```vba
Private Sub btnKaydet_Click()
    ' --- Doğrulama ---
    If Trim(txtAd.Value) = "" Then
        MsgBox "Ad alanı boş olamaz", vbExclamation
        txtAd.SetFocus
        Exit Sub
    End If
    
    If Not IsNumeric(txtMaas.Value) Then
        MsgBox "Maaş sayısal olmalı", vbExclamation
        txtMaas.SetFocus
        Exit Sub
    End If
    
    If CDbl(txtMaas.Value) < 0 Then
        MsgBox "Maaş negatif olamaz", vbExclamation
        txtMaas.SetFocus
        Exit Sub
    End If
    
    If cmbDepartman.ListIndex = -1 Then
        MsgBox "Departman seçin", vbExclamation
        cmbDepartman.SetFocus
        Exit Sub
    End If
    
    ' --- Asıl iş ---
    Dim sonSatir As Long
    sonSatir = Sheets("Veri").Cells(Rows.Count, 1).End(xlUp).Row + 1
    
    With Sheets("Veri")
        .Cells(sonSatir, 1).Value = txtAd.Value
        .Cells(sonSatir, 2).Value = CDbl(txtMaas.Value)
        .Cells(sonSatir, 3).Value = cmbDepartman.Value
    End With
    
    MsgBox "Kayıt eklendi", vbInformation
    Unload Me
End Sub
```

### 3.5 MultiPage — Sekmeli Form

Karmaşık form (mesela bordro girişi: Kişisel, İş, Maaş, Kesinti) tek sayfada sığmaz. **MultiPage** sekme yapar.

```vba
' Sekmeyi programlı değiştirme
MultiPage1.Value = 0   ' İlk sekme
MultiPage1.Value = 2   ' Üçüncü sekme

' "İleri" düğmesi
Private Sub btnIleri_Click()
    If MultiPage1.Value < MultiPage1.Pages.Count - 1 Then
        MultiPage1.Value = MultiPage1.Value + 1
    End If
End Sub

' Doğrulama ile sekmeye girişi engelleme
Private Sub MultiPage1_Change()
    If MultiPage1.Value = 2 Then  ' Maaş sekmesi
        If Trim(txtAd.Value) = "" Then
            MsgBox "Önce kişisel bilgileri doldurun"
            MultiPage1.Value = 0
        End If
    End If
End Sub
```

### 3.6 Modal vs Modeless

```vba
' Modal: form açıkken Excel'e dokunulamaz (varsayılan)
UserForm1.Show

' Modeless: form açıkken Excel'le çalışabilirsin
UserForm1.Show vbModeless
```

**Modeless** kullanımı: kullanıcı hücreyi seçip forma "seçimi al" düğmesi tıklamak istiyorsa.

---

## BÖLÜM 4: Class Module ve Olaylar

### 4.1 Class Module Nedir?

VBA'da kendi **nesne tipini** tanımlarsın. Personel, Fatura, BordroSatiri gibi.

VBA Editör → **Insert → Class Module**. Properties penceresinde **Name** alanını "Personel" yap.

```vba
' --- Class Module: Personel ---

' Özellikler (Property)
Public Ad As String
Public Soyad As String
Public TCKN As String
Public BrutMaas As Double

' Metot
Public Function NetMaas() As Double
    Dim sgk As Double, gv As Double
    sgk = BrutMaas * 0.14
    gv = (BrutMaas - sgk) * 0.15
    NetMaas = BrutMaas - sgk - gv
End Function

Public Function TamAd() As String
    TamAd = Ad & " " & Soyad
End Function
```

**Modül tarafında kullanım:**

```vba
Sub PersonelTest()
    Dim p As Personel
    Set p = New Personel
    p.Ad = "Ahmet"
    p.Soyad = "Yılmaz"
    p.BrutMaas = 30000
    
    Debug.Print p.TamAd & " net maaş: " & p.NetMaas
End Sub
```

### 4.2 Property Get/Let/Set — Kontrollü Erişim

`Public X As Double` doğrudan erişim verir. Doğrulamak istersen Property kullan:

```vba
Private pBrutMaas As Double

Public Property Get BrutMaas() As Double
    BrutMaas = pBrutMaas
End Property

Public Property Let BrutMaas(deger As Double)
    If deger < 0 Then
        Err.Raise vbObjectError + 1000, "Personel", "Brüt maaş negatif olamaz"
    End If
    pBrutMaas = deger
End Property
```

Şimdi `p.BrutMaas = -100` denemesi hata fırlatır.

### 4.3 Olay Yakalama — Application Events

Class Module'in en güçlü kullanımı: **Excel'in olaylarını dinlemek**.

Bir Class Module aç, adı "AppOlaylar" yap:

```vba
Public WithEvents App As Application

' Herhangi bir kitap açıldığında
Private Sub App_WorkbookOpen(ByVal Wb As Workbook)
    MsgBox "Açılan kitap: " & Wb.Name
End Sub

' Herhangi bir hücreye yazıldığında
Private Sub App_SheetChange(ByVal Sh As Object, ByVal Target As Range)
    Debug.Print "Değişen hücre: " & Sh.Name & "!" & Target.Address
End Sub
```

**ThisWorkbook** modülünde başlatılır:

```vba
Dim olayDinleyici As New AppOlaylar

Private Sub Workbook_Open()
    Set olayDinleyici.App = Application
End Sub
```

Artık kullanıcı **herhangi bir** kitapta bir şey yapınca senin kodun çalışır.

### 4.4 Worksheet Olayları (Sayfa Bazlı)

Bunlar Class değil — doğrudan sayfanın kod penceresine yazılır (sayfaya sağ tık → Kodu Görüntüle):

```vba
' Belirli sayfada hücre değişince
Private Sub Worksheet_Change(ByVal Target As Range)
    If Not Intersect(Target, Range("A:A")) Is Nothing Then
        Application.EnableEvents = False
        Target.Value = UCase(Target.Value)   ' A sütunu büyük harf
        Application.EnableEvents = True
    End If
End Sub

' Hücre seçimi değişince
Private Sub Worksheet_SelectionChange(ByVal Target As Range)
    Application.StatusBar = "Seçili: " & Target.Address
End Sub

' Çift tıklama
Private Sub Worksheet_BeforeDoubleClick(ByVal Target As Range, Cancel As Boolean)
    If Target.Column = 5 Then
        Target.Value = Date
        Cancel = True   ' Düzenleme moduna girmeyi engelle
    End If
End Sub
```

**Önemli:** Olay içinde sayfa değiştirirken **EnableEvents = False** yap, yoksa kendi kendini tetikler (sonsuz döngü).

---

## BÖLÜM 5: Ribbon Özelleştirme ve Add-in (.xlam)

### 5.1 Hedef: Kendi Şerit Sekmen

Bir kuruma "Bordro Otomasyonu" adında, kendi düğmeleri olan bir şerit sekmesi vermek. Kullanıcı **Office Custom UI Editor** ile XML yazar, dosyanın içine gömer.

### 5.2 Office Custom UI Editor Kurulumu

Microsoft'un eski ama çalışan ücretsiz aracı. **Office Custom UI Editor Tool** — GitHub'da güncel sürümleri var. Excel'i kapatıp tool'u aç, .xlsm/.xlam dosyasını sürükle.

### 5.3 Temel Şerit XML'i

`customUI14.xml` olarak ekle (Office 2010+):

```xml
<customUI xmlns="http://schemas.microsoft.com/office/2009/07/customui">
  <ribbon>
    <tabs>
      <tab id="BordroSekmesi" label="Bordro Otomasyonu">
        
        <group id="grpGiris" label="Giriş">
          <button id="btnYeniBordro"
                  label="Yeni Bordro"
                  size="large"
                  imageMso="FileNew"
                  onAction="cmdYeniBordro"/>
          <button id="btnAcKaydedilen"
                  label="Aç"
                  size="large"
                  imageMso="FileOpen"
                  onAction="cmdAcKaydedilen"/>
        </group>
        
        <group id="grpHesap" label="Hesaplama">
          <button id="btnHesapla"
                  label="Hesapla"
                  imageMso="Calculator"
                  onAction="cmdHesapla"/>
          <button id="btnSGK"
                  label="SGK Tablosu"
                  imageMso="DatasheetView"
                  onAction="cmdSGKTablosu"/>
          <separator id="sep1"/>
          <toggleButton id="tglDetay"
                        label="Detaylı Göster"
                        imageMso="ShowDetails"
                        onAction="cmdDetayDegistir"/>
        </group>
        
        <group id="grpRapor" label="Rapor">
          <button id="btnPDF"
                  label="PDF Çıkar"
                  size="large"
                  imageMso="ExportPdf"
                  onAction="cmdPDFCikar"/>
        </group>
        
      </tab>
    </tabs>
  </ribbon>
</customUI>
```

### 5.4 XML Düğmelerini VBA'ya Bağlama

Her `onAction` özniteliği bir VBA Sub'una işaret eder. **İmza şarttır** (parametre listesi):

```vba
' Normal button için
Sub cmdYeniBordro(control As IRibbonControl)
    UserForm_YeniBordro.Show
End Sub

' ToggleButton için (basılı/değil)
Sub cmdDetayDegistir(control As IRibbonControl, pressed As Boolean)
    If pressed Then
        Columns("F:K").Hidden = False
    Else
        Columns("F:K").Hidden = True
    End If
End Sub

' ComboBox için
Sub cmdSecimDegisti(control As IRibbonControl, text As String)
    MsgBox "Seçilen: " & text
End Sub
```

### 5.5 imageMso — Hazır Office İkonları

Microsoft yüzlerce hazır ikon sunar. Liste için: "imageMso gallery" internet araması. Sık kullanılanlar:
- `FileNew`, `FileOpen`, `FileSave`, `FilePrint`
- `Calculator`, `Calendar`, `Mail`
- `TableInsert`, `ChartInsert`, `PivotTableInsert`
- `ExportPdf`, `ExportExcel`
- `HappyFace`, `WarningGeneric`, `Info`

### 5.6 Add-in (.xlam) Olarak Paketleme

**Hedef:** Bordro otomasyonu kodu **her** Excel açılışında yüklü olsun, kullanıcı dosyayı aramasın.

**Adımlar:**

1. **Tüm makroları ve formları** bir `.xlsm` dosyasında topla.
2. **Dosya → Farklı Kaydet → "Excel Eklentisi (*.xlam)"** seç.
3. Excel otomatik olarak `C:\Users\[kullanici]\AppData\Roaming\Microsoft\AddIns\` klasörüne kaydeder.
4. Kullanıcıya dağıt: dosyayı kopyala + **Geliştirici → Excel Eklentileri** → **Gözat** → seç → **Tamam**.
5. Artık o kullanıcının her Excel açılışında add-in yüklü, şerit sekmesi otomatik gelir.

### 5.7 Add-in Geliştirme Notları

- Add-in'de **sayfa görünmez** — `ThisWorkbook.IsAddin = True`. Kullanıcı dosyayı görmez, sadece kodları çalışır.
- Add-in açıkken **kod değiştirme yapmak istersen** geçici olarak `IsAddin = False` yap, düzenle, geri al, kaydet.
- Add-in **şerit XML'ini** ister `customUI14.xml` ister `customUI.xml` olarak gömebilir. 14 versiyonu Office 2010+, eski versiyon Office 2007.
- Add-in **dijital imzalı** olursa kullanıcının "Makroları etkinleştir" uyarısı azalır. Kurumsal sertifika veya SelfCert.exe ile yapılır.

### 5.8 Add-in Güncelleme Stratejisi

Şirkette 50 kişiye add-in dağıttın, sonra bir güncelleme geldi. Üç yöntem:

1. **Ortak ağ klasörü:** Add-in'i `\\sunucu\eklentiler\BordroOtomasyon.xlam` yolundan yükletirsin. Tek bir dosyayı güncellersen herkes etkilenir.
2. **Otomatik güncelleme:** Add-in açılırken bir sunucudan versiyon kontrolü yapar, gerekirse yeni dosyayı indirir.
3. **Manuel:** Yeni .xlam'ı e-posta ile gönderirsin, kullanıcı eskisini siler, yenisini koyar.

Ortak ağ klasörü en pratiği — kurumlarda standart yaklaşım.

---

## BÖLÜM 6: Mali/Finans Otomasyonu — Gerçek Senaryolar

### 6.1 Senaryo: KDV Beyannamesi Hazırlama

**Girdi:** "Faturalar" sayfasında binlerce fatura kalemi. A=Tarih, B=Müşteri, C=Açıklama, D=KDV oranı, E=KDV hariç tutar, F=KDV tutarı.

**Çıktı:** KDV oranına göre gruplu özet — beyanname tablosuna kopyala-yapıştır kıvamında.

Bkz: **`mali-ornekler.md`** — Bölüm 1 (KDV Beyannamesi).

### 6.2 Senaryo: Aylık Bordro Hesaplama

**Girdi:** "Personel" sayfasında çalışan listesi (TCKN, Ad, Brüt Maaş, AGI, vs.). "Devam" sayfasında o ayki çalışma günleri.

**Çıktı:** Her personel için: SGK işçi payı, işsizlik primi, gelir vergisi matrahı, kümülatif vergi matrahı, gelir vergisi, damga vergisi, net ödeme — tüm dilim hesapları doğru.

Bkz: **`mali-ornekler.md`** — Bölüm 2 (Bordro).

### 6.3 Senaryo: Bütçe vs Gerçekleşen — Sapma Raporu

**Girdi:** "Butce" sayfasında ay-departman-kalem bazında bütçe. "Fiili" sayfasında aynı kırılımda gerçekleşen.

**Çıktı:** Sapma raporu (tutar farkı + yüzde + uyarı bayrağı).

Bkz: **`mali-ornekler.md`** — Bölüm 3 (Bütçe Sapma).

---

## BÖLÜM 7: Modüler Mimari — Kurumsal Kod

### 7.1 Modül Ayrımı

Tek bir devasa modülde 5000 satır kod = bakım kâbusu. Ayır:

| Modül Adı | İçeriği |
|-----------|---------|
| `mod_Ana` | Şerit düğmelerinin Sub'ları (giriş noktası) |
| `mod_Hesap` | Saf hesaplama fonksiyonları |
| `mod_Veri` | Veri okuma/yazma/doğrulama |
| `mod_Rapor` | PDF çıkarma, biçimlendirme |
| `mod_Yardimci` | Genel yardımcı fonksiyonlar |
| `mod_Ayarlar` | Sabit değerler, parametreler |
| `mod_Log` | Log yazma, hata kayıt |
| `cls_Personel` | Class Module — Personel |
| `cls_BordroSatiri` | Class Module — bir satır bordro |
| `frm_YeniKayit` | UserForm — yeni kayıt |
| `frm_Ayarlar` | UserForm — ayarlar |

### 7.2 Hata Yönetimi Şablonu

Her ana Sub bu şablonda olmalı:

```vba
Sub AnaIslem()
    On Error GoTo HataYakala
    
    BaslangicAyarlari   ' Performans modunu aç
    
    ' --- Asıl iş ---
    HesaplamaYap
    RaporOlustur
    Loga "Ana işlem başarılı"
    
TemizCikis:
    BitisAyarlari       ' Performans modunu kapat
    Exit Sub

HataYakala:
    Loga "HATA: " & Err.Number & " - " & Err.Description & " - " & Err.Source
    MsgBox "Bir hata oluştu. Yöneticiye bildirin." & vbCrLf & _
           "Kod: " & Err.Number & vbCrLf & _
           "Açıklama: " & Err.Description, vbCritical
    Resume TemizCikis
End Sub
```

**Resume TemizCikis** anahtardır: hata çıksa bile **BitisAyarlari** çalışır. Yoksa kullanıcının Excel'i "donmuş" gibi kalır.

### 7.3 Basit Log Modülü

```vba
' --- mod_Log ---
Public Sub Loga(mesaj As String)
    Dim dosya As String
    dosya = Environ("APPDATA") & "\BordroOtomasyon\log.txt"
    
    ' Klasör yoksa oluştur
    Dim klasor As String
    klasor = Environ("APPDATA") & "\BordroOtomasyon"
    If Dir(klasor, vbDirectory) = "" Then MkDir klasor
    
    Dim no As Integer
    no = FreeFile
    Open dosya For Append As #no
    Print #no, Format(Now, "yyyy-mm-dd hh:nn:ss") & vbTab & mesaj
    Close #no
End Sub
```

Kullanım:

```vba
Loga "Bordro hesaplama başladı, " & sayi & " personel"
' ...işlemler...
Loga "Bordro hesaplama tamamlandı, süre: " & (Timer - baslangic) & " sn"
```

### 7.4 Versiyon ve Yapılandırma

```vba
' --- mod_Ayarlar ---
Public Const VERSIYON As String = "2.4.1"
Public Const KDV_GENEL As Double = 0.2
Public Const KDV_INDIRIMLI As Double = 0.1
Public Const KDV_TEMEL_GIDA As Double = 0.01

Public Const SGK_ISCI_ORANI As Double = 0.14
Public Const ISSIZLIK_ISCI_ORANI As Double = 0.01
Public Const DAMGA_ORANI As Double = 0.00759

Public Function VersiyonBilgisi() As String
    VersiyonBilgisi = "Bordro Otomasyonu v" & VERSIYON
End Function
```

**Mali oranlar değiştiğinde** sadece bu modülü güncellersin. Tüm sistem otomatik adapt olur.

---

## BÖLÜM 8: Güvenlik ve Dağıtım

### 8.1 VBA Projesini Kilitleme

VBA Editör → **Tools → VBAProject Properties → Protection** → "Lock project for viewing" + parola.

Kullanıcı kodu **göremez, değiştiremez**, sadece çalıştırır. Kurumsal dağıtım için zorunlu.

**Uyarı:** VBA parolası sektörde **zayıf** kabul edilir — internette kırma araçları var. Gerçekten gizlenmesi gereken iş mantığı varsa **derlenmiş bir COM Add-in** (Visual Studio + C#) tercih edilir, ama VBA için bu yeterli koruma.

### 8.2 Dijital İmza

**Self-signed (kişisel) sertifika:**
1. Office klasöründe `SelfCert.exe` (genelde `C:\Program Files\Microsoft Office\rootXX\Office16\` altında)
2. Çalıştır, isim ver, sertifika sisteme yüklenir
3. VBA Editör → **Tools → Digital Signature** → sertifikayı seç

Sadece **senin** bilgisayarında "güvenilir" sayılır. Başka kullanıcıya verilecekse:
- Kurumsal CA (Certificate Authority) sertifikası → tüm domain için geçerli
- Veya kullanıcı sertifikayı **manuel olarak "Güvenilir Yayımcılar"** listesine ekler

### 8.3 Trusted Locations

Kurumsal ortamda makro yüklerken her seferinde "Makroları etkinleştir" uyarısı sinir bozucu. Çözüm:

**Excel → Dosya → Seçenekler → Güven Merkezi → Güven Merkezi Ayarları → Güvenilir Konumlar**

Bir klasör eklersen, o klasördeki tüm dosyalar uyarısız açılır. Add-in'ler için `AppData\Roaming\Microsoft\AddIns` zaten güvenilir.

### 8.4 GPO ile Toplu Dağıtım

Kurumda sistem yöneticisi varsa, Add-in dağıtımı **Group Policy** ile yapılır:
- Add-in dosyasını ortak konuma koy
- GPO scripti her kullanıcının `HKEY_CURRENT_USER\Software\Microsoft\Office\XX.0\Excel\Options` altında `OPENn` kayıt değeri oluşturur, bu add-in'i otomatik yükler
- Kullanıcı yeni bilgisayara geçse bile add-in otomatik gelir

---

## Kontrol Listesi — Üretim Hazırlığı

Bir add-in'i kuruma dağıtmadan önce:

- [ ] `Option Explicit` her modülün başında mı? (değişken yazım hatalarını yakalar)
- [ ] Tüm değişkenler `Dim` ile tip belirtilerek tanımlanmış mı?
- [ ] Her ana Sub'da hata yönetimi (`On Error GoTo`) var mı?
- [ ] `BaslangicAyarlari` / `BitisAyarlari` çağrıları doğru sırada mı?
- [ ] Büyük veri işlemleri **diziye al → işle → topluca yaz** mantığında mı?
- [ ] `.Select`, `.Activate` kullanımı **tamamen** kaldırıldı mı?
- [ ] Sabit değerler `mod_Ayarlar`'da merkezi mi (kanunla değişen oranlar)?
- [ ] Log sistemi çalışıyor mu? Test ettin mi?
- [ ] VBA Project parolayla kilitli mi?
- [ ] Dijital imza eklendi mi?
- [ ] Versiyon numarası güncel mi?
- [ ] Bir önceki sürüm yedeklendi mi?
- [ ] Kullanıcı kılavuzu/README hazır mı?
- [ ] En az iki gerçek veri setinde test edildi mi?
- [ ] Hata durumunda da `BitisAyarlari` çağrıldığından emin misin (Resume kullandın mı)?

---

## Sık Yapılan Hatalar (ve Çözümleri)

| Hata | Belirti | Çözüm |
|------|---------|-------|
| `.Select` döngüde | Makro yavaş, ekran titriyor | Doğrudan referans ver, Select kullanma |
| `ScreenUpdating` unutulmuş | Makro yavaş | Başta False, sonda True |
| Hücre döngüsünde yazma | 100K satır → dakikalar | Diziye yaz, tek seferde aktar |
| `EnableEvents` unutulmuş | Worksheet_Change sonsuz döngü | İçerde False, çıkarken True |
| `Application.Calculation` Manual kaldı | Diğer dosyalarda formüller güncellenmiyor | Çıkışta Automatic yap |
| Add-in'de sayfaya yazma denemesi | Görünmüyor | Add-in'de ThisWorkbook.IsAddin = True |
| Dictionary referansı eksik | "User-defined type not defined" | Tools → References → Microsoft Scripting Runtime |
| `For i = 1 To sonuncu` ile silme | Yanlış satırlar siliniyor | Sondan başa: `For i = sonuncu To 1 Step -1` |
| ReDim Preserve ilk boyutu | "Subscript out of range" | Sadece son boyut değişebilir — diziyi `Transpose` etmen gerek |
| Property doğrulama atlanmış | Negatif maaş kayıt oluyor | `Property Let` içinde kontrol koy |

---

## Hangi Aracı Ne Zaman Kullan?

| Durum | Tavsiye |
|-------|---------|
| 100 satırlık hesap, bir kere | Formül |
| 100K satırlık veri, döngülü | Dizi + Dictionary |
| Aylık tekrarlanan rapor | .xlsm makro, butona bağlı |
| 20 kişiye dağıtılan otomasyon | .xlam Add-in + Ribbon |
| Anlık veri doğrulama gerekli | Worksheet_Change olayı |
| Karmaşık form (5+ sekmeli) | UserForm + MultiPage |
| Excel'in tüm açılışlarında çalışan kontrol | Class Module + WithEvents Application |
| Birden fazla kitap arasında veri | ADO + SQL (ileri konu) |
| Outlook'a e-posta | Microsoft Outlook nesne modeli |

---

## Son Söz

Bu skill **production-ready** Excel otomasyonu içindir. Eğer makronu sadece **kendin** için kullanacaksan birçok bölüm aşırılık olabilir — `excel-makro-vba`'da kalabilirsin.

Ama **başka birine** dağıtacaksan: hata yönetimi, log, versiyon, kilitleme, dijital imza — hepsi gerek. Aksi takdirde ilk üç hafta içinde "hocam çalışmıyor" telefonları başlar.

Mali oranlar (KDV, SGK, gelir vergisi dilimleri, asgari ücret) **her yıl değişir**. `mod_Ayarlar` merkezi yapısı bunun içindir. Kanun değişti — bir modülü güncelle, tüm sistem doğru çalışsın.
