# kurumsal-turkce-yazim

---
name: "kurumsal-turkce-yazim"
description: "İsmailBEY'in tüm Türkçe konuşma metni ve yazışma taleplerinde kullan: TDK kurallarına tam uygun, kurumsal dilde, insan elinden çıkmış gibi metin üretir ve ilgili skill'leri otomatik devreye alır."
---

# Kurumsal Türkçe Yazım Standardı

Bu skill; üst yazı, dilekçe, tutanak, karar metni, e-posta, duyuru, konuşma metni, rapor ve benzeri her Türkçe metin talebinde devreye girer. Amaç, okuyanın "bunu bir memur titizliğiyle bir insan yazmış" diyeceği metni ilk denemede teslim etmektir.

## 1. Konuya göre skill seçimi (otomatik)

Kullanıcıya sormadan, talebin türüne göre şu skill'leri yükle ve birlikte uygula:

| Talep türü | Yüklenecek skill(ler) |
|---|---|
| EBYS üst yazısı, resmî kurum yazısı, ilgi/konu/arz-rica içeren yazı | `ebys-yazisma` + `turkce-dogallastirici` |
| Tutanak, komisyon kararı, resmî rapor | `ebys-yazisma` + `turkce-dogallastirici` |
| Konuşma metni, duyuru, tebrik, anma, açılış konuşması | `turkce-dogallastirici` |
| E-posta, bilgilendirme notu, kısa yazışma | `turkce-dogallastirici` |
| Word belgesi olarak istenen metin | yukarıdakiler + `word-ileri` / `docx` |
| Sunum metni | yukarıdakiler + `powerpoint-ustasi` |
| Tablo, liste, hesap | `excel-temel` (metin kısımlarına bu standart uygulanır) |
| Çok parçalı, karmaşık iş | `skill-yoneticisi` ile sırala |

Kullanıcı mesajında belirli bir skill adı geçerse o skill önceliklidir.

## 2. Yazım ve noktalama (TDK)

- Bitişik/ayrı yazım: "de/da", "ki", "mi" eklerini ve bağlaçlarını doğru ayır.
- Kesme işareti: özel adlara gelen ekler kesmeyle ayrılır (Nurhak'ta, Kahramanmaraş'ın); kurum adlarının sonuna gelen eklerde de aynı kural geçerlidir.
- Büyük harf: kurum ve kuruluş adlarının her kelimesi büyük harfle başlar (Nurhak İlçe Millî Eğitim Müdürlüğü).
- Şapka: "Millî" gibi resmî kullanımı yerleşmiş biçimleri koru.
- Tarih: 06.10.2026 biçimi; metin içinde "6 Ekim 2026".
- Sayılar ve para: 1.250,00 TL; yazıyla gerektiğinde "(Bin iki yüz elli Türk lirası)".
- Kısaltmalar TDK listesine uygun; ilk geçişte açık yazım tercih edilir.
- Yazıyı teslim etmeden önce her cümleyi yazım, noktalama ve ek uyumu açısından tek tek kontrol et.

## 3. Kurumsal dil yapısı

- Resmî yazılarda Resmî Yazışmalarda Uygulanacak Usul ve Esaslar Hakkında Yönetmelik'e uy (ayrıntı `ebys-yazisma` skill'inde).
- Üst makama: "…arz ederim." / "…arz ve rica ederim."; ast ya da eş düzey makama: "…rica ederim."
- Edilgen yapı ölçülü kullanılır; her cümle edilgen olmaz.
- Sade, açık, tek anlama gelen ifadeler; gereksiz yabancı kelime yok.
- Saygılı ama yaltaklanmayan, net ama sert olmayan bir ton.

## 4. İnsan elinden çıkmış gibi yazma

Şunlardan kaçın:
- Çeviri kokan kalıplar ("…olarak hizmet etmektedir", "…konusunda büyük önem arz etmektedir" tekrarı).
- Her paragrafı aynı uzunlukta ve aynı yapıda kurmak.
- Üçlü sıralama alışkanlığı, abartılı sıfatlar, içi boş vurgular.
- Gereksiz madde işaretleri ve başlıklar; resmî yazı düz paragrafla akar.
- "Sonuç olarak", "Özetle" gibi yapay kapanışlar (yönetmelik gerektirmedikçe).

Şunları yap:
- Cümle uzunluklarını doğal biçimde çeşitlendir.
- Kurum içinde gerçekten kullanılan ifadeleri tercih et.
- Metni bitirince bir kez sesli okur gibi gözden geçir; takılan, yapay duran her yeri düzelt.

## 5. Teslim

- Metni doğrudan, kullanıma hazır hâlde ver; uzun açıklama ekleme.
- Eksik bilgi (sayı, tarih, ilgi) varsa metinde boş bırakma: makul bir yer tutucu koy ([Tarih], [Sayı]) ve altında tek cümleyle belirt.
- Kalite çıtası her zaman en üst seviyedir; sıradan sonuç teslim edilmez.
