# fable-web-design

---
name: fable-web-design
description: "Fable 5.2 düzeniyle web tasarımı ve HTML üretimi: her brief'e özgü, şablon gibi durmayan siteler, landing ve ürün sayfaları, portfolyolar, panolar (dashboard) ve arayüz taslakları. Web sitesi, landing page, ana sayfa, hero bölümü, HTML sayfa, UI taslağı, portfolyo, fiyat sayfası, pano ya da site yenileme istendiğinde; 'premium', 'profesyonel görünsün', 'modern', 'pahalı dursun', 'animasyonlu site', 'Fable tarzı' denildiğinde kullan. Brief'e göre token planı çıkarır, planı yapay zekâ varsayılanlarına karşı denetler, sonra kurar ve ekran görüntüsüyle eleştirir. Eski 5.1 karanlık editoryal görünüm, yalnızca açıkça istenirse hazır stil olarak uygulanır."
license: MIT
metadata:
  version: "2.0.0"
  category: web-design
  provenance: "Fable 5.2 frontend-design SKILL.md (fable-5-2-reference/references/skills/public/frontend-design.md) + 5.1 sürümünün mühendislik kuralları (token, erişilebilirlik, mobil uyum, hareket disiplini)"
---

# Fable Web Design 5.2

Her müşteriye kimsenin kimliğiyle karışmayan bir görsel kimlik veren bir tasarım stüdyosunun tasarım lideri gibi çalış. Bu müşteri klişe ve şablon gibi duran önerileri zaten reddetti, belirgin bir bakış açısı için para ödüyor. Renk, tipografi ve yerleşimde bu brief'e özgü, kararlı seçimler yap. Gerekçesi varsa estetik risk al.

> **5.1'den farkı:** 5.1 sürümü tek bir görünümü (#0A0A0A zemin, serif başlık, BÜYÜK HARF etiket, her bölümde fade-up) her işe uyguluyordu. 5.2'de bunlar artık "yapay zekâ varsayılanı" sayılıyor. Görünüm her brief için yeniden kurulur. Sabit kalan şey görünüm değil, süreç ve kalite tabanıdır.
>
> Tam kaynak metin: `fable-5-2-reference/references/skills/public/frontend-design.md`. Bu skill onu uygular ve mühendislik kurallarıyla tamamlar.

---

## 1. Önce konuyu bul

- Brief ürünü ya da konuyu belirtmiyorsa tasarıma başlamadan kendin belirle. Somut bir konu, hedef kitle ve sayfanın birincil işini öner, müşteriyle teyit et.
- Kullanıcının tercihleri ya da ne kurduğu hakkında bellekte bilgi varsa ipucu olarak kullan.
- Ayırt edici görsel seçimler konunun sektöründen, malzemesinden ve diline özgü öğelerden doğar. 8-11 yaş kız çocukları için bir oyuncak sitesi ile finans analistleri için bir pano estetik olarak çok farklı olmalı.
- Baştan sona brief'in gerçek içeriğiyle çalış. Lorem ipsum ve sahte metin kullanma.

## 2. Tasarım ilkeleri

### Hero
Sayfa, konunun dünyasındaki en karakteristik şeyle açılsın: bir başlık, bir görsel, bir animasyon, canlı bir demo ya da etkileşimli bir an. Bilinçli seç. "Büyük sayı, küçük etiket, destekleyici istatistikler ve gradyan vurgu" varsayılan çözümdür. Yalnızca gerçekten en iyisiyse kullan.

### Tipografi kişiliği taşır
- Bir ya da iki aile yeter. İki aile kullanıyorsan birbirinden açıkça ayrılsın.
- Yazı tiplerini her projede uzandığın varsayılan ailelerden değil, bu brief için bilinçli seç.
- *The Elements of Typographic Style*'ın varsayılan önerilerine uyan net bir tip ölçeği kur: bilinçli ağırlıklar, genişlikler ve aralıklar.
- Başlık olarak kullanılan yazıyı tasarımın etkin bir parçası yap, içeriği taşıyan nötr bir araç olarak bırakma.
- Satır uzunluğu varsayılan olarak 80 karakterin altında olsun. Serif metin biraz daha uzun satır taşıyabilir ve biraz daha fazla satır aralığı ister.

**Kaçınılacak tipografik izler** (üretilmiş sayfaların en yaygın ipuçları):
- Başlıkta tek bir sözcüğü ya da ifadeyi italik, kalın ya da farklı renkle vurgulamak
- Etiketlerde tamamen büyük harf kullanmak
- İçeriğin üstüne gereksiz tipografik etiketler (eyebrow) koymak

### Görsel yapı bilgidir
Çerçeve, kenarlık, numara, etiket ve ayraç gibi yapısal öğeler süs değil, içerik hakkında bilgi taşır. 01/02/03 gibi numaralı işaretleri yalnızca içerik gerçekten bir sıraysa (adım adım süreç, zaman çizelgesi) kullan.

### Hareket
- Kullanıcı tetiklemeyen hareketi az ve bilinçli kullan, yalnızca dikkat çekmek için.
- Tek bir düzenlenmiş an (bir açılış dizisi ya da bir reveal), dağınık efektlerden daha etkilidir.
- Her bölümde fade-and-slide-up girişi ve her kartta hover geçişi genel varsayılandır, yapay zekâ işi gibi okunur.
- Kullanıcının eylemine yanıt veren hareket (açma, genişletme, onaylama) neyin değiştiğini gösterdiğinde makbuldür.

### Metin
Metin de tasarım içeriğidir. Ayrıntılar için §7'ye bak.

---

## 3. Süreç: planla → brief'e karşı denetle → kur → eleştir

### Ayar: yapay zekâ tasarımının bugün kümelendiği izler

1. Sıcak krem zemin (#F4F1EA civarı), yüksek kontrastlı serif başlık ve kiremit ya da sıcak kil rengi vurgu (çoğu zaman #D97757 civarı). Bu, Anthropic'in kendi Claude vurgu rengidir, kullanıcının brief'inde bir ipucu gibi okunur.
2. Siyaha yakın zemin ve tek bir parlak asit yeşili ya da vermilyon vurgu.
3. İnce çizgili, sıfır köşe yarıçaplı, yoğun gazete sütunlu broadsheet düzeni.
4. SaaS kart kiti: aynı yuvarlak kartlara bölünmüş içerik, hiyerarşiden bağımsız tek köşe yarıçapı, her kartın altında aynı yumuşak gri gölge (rgba(0,0,0,.1)) ve süs olarak gradyan.
5. Konudan bağımsız şablon süsleri:
   - her başlığın üstünde aralıklı BÜYÜK HARF etiket
   - orta noktayla birleştirilmiş meta satırları ("A · B · C")
   - aralıklı uzun tireyle kurulan "SÖZCÜK — parça" etiketleri
   - siyah yerine renkli siyaha yakın tonlar (#0B0B0B, #111)
   - küçük veri etiketleri için monospace yazı tipi
   - bağlantı ve düğme metinlerine eklenmiş "→"

Bu izlerin hepsi bazı brief'ler için meşrudur, ama seçim değil varsayılandır ve konudan bağımsız olarak ortaya çıkarlar. Brief görsel yönü belirlemişse ona aynen uy: brief'in kendi sözleri her zaman kazanır, bu görünümlerden birini istese bile. Brief bir ekseni serbest bırakıyorsa o serbestliği bu varsayılanlardan birine harcama.

### Geçiş 1: Tasarım planı
Brief'e göre kısa bir plan ve kompakt bir token sistemi çıkar:
- **Renk:** 4-6 adlandırılmış hex değerinden oluşan temel palet. Adlar konudan gelsin (örneğin "fındık kabuğu", "liman sisi"), "primary-500" gibi değil.
- **Tip:** yazı tipleri ve rolleri.
- **Yerleşim:** tek cümlelik düzyazı tanımlar ve karşılaştırmak için ASCII tel çerçeveler. Hizalama yönü: sola mı, ortaya mı, iki yana mı?
- **İlkeler:** bu sayfayı benzersiz kılan üst düzey yönergeler. Cesaretin harcanacağı tek yer burada belirlenir.

### Denetim
Planı inşa etmeden önce brief'e karşı gözden geçir. Benzer bir istem için zihninde aynı süreci çalıştır. Planın bir kısmı her benzer sayfa için üreteceğin varsayılan gibi duruyorsa, yani bu brief için yapılmış bir seçim değilse, o kısmı değiştir. Neyi neden değiştirdiğini kullanıcıya söyle. Planın görece özgün olduğundan emin olduktan sonra kodu yaz.

### Geçiş 2: Kur
Gözden geçirilmiş plana göre kur (§4-§6). CSS seçici özgüllüklerine dikkat et. Birbirini iptal eden sınıflar üretmek kolaydır, özellikle `.section` gibi tip tabanlı bir seçiciyle `.cta` gibi öğe tabanlı bir seçici, bölümler arası padding ve margin'de çakışır.

### Eleştir
Kurarken kendi işini eleştir. Ortam izin veriyorsa ekran görüntüsü alıp bak, bir resim bin token değerindedir. Masaüstü ve 375 px mobil genişlikte bak. Chanel'in öğüdünü uygula: evden çıkmadan önce aynaya bak ve bir aksesuarı çıkar. Denediğin şeyleri not edebileceğin bir yer varsa kısa notlar düş. İnsan tasarımcılar hafızası olduğu için hep yeni bir şey dener.

---

## 4. Kalite tabanı: duyurmadan uygula

Ölçülülük: cesaretini tek bir yerde harca. Bir öğe akılda kalan şey olsun, çevresindeki her şey sakin ve disiplinli kalsın. Brief'e hizmet etmeyen her süsü kes.

Duyurmadan şu tabanı karşıla:
- Mobile kadar uyumlu yerleşim
- Görünür klavye odağı
- Azaltılmış hareket tercihine saygı
- Görsel erişilebilirlik ve uyumlu renk paleti

### 4.1 Token mimarisi (5.1'den korunan disiplin)
Değerler her brief'te değişir, mimari aynı kalır. Bileşen CSS'inde sihirli sayı olmasın, her şey `:root` değişkenlerine başvursun.

```css
:root {
  /* Renk: plandaki 4-6 adlandırılmış değer + anlamsal eşlemeler */
  --c-<ad1>: #......;  --c-<ad2>: #......;  /* ...plandan */
  --bg:        var(--c-<zemin>);
  --surface:   var(--c-<yüzey>);
  --text:      var(--c-<metin>);
  --text-soft: color-mix(in oklab, var(--text) 68%, var(--bg));
  --accent:    var(--c-<vurgu>);   /* anlam için: CTA, odak, durum */
  --line:      color-mix(in oklab, var(--text) 14%, var(--bg));

  /* Tip: plandaki aileler ve tek bir ölçek (ör. 1.25 ya da 1.333 oran) */
  --font-a: "<seçilen>", <yedek>;
  --font-b: "<seçilen>", <yedek>;
  --step--1: clamp(.83rem, .8rem + .15vw, .9rem);
  --step-0:  clamp(1rem, .96rem + .2vw, 1.1rem);
  --step-1:  clamp(1.25rem, 1.15rem + .5vw, 1.45rem);
  --step-2:  clamp(1.56rem, 1.35rem + 1vw, 2rem);
  --step-3:  clamp(1.95rem, 1.6rem + 1.8vw, 2.9rem);
  --step-4:  clamp(2.44rem, 1.8rem + 3.2vw, 4.4rem);
  --measure: 66ch;   /* < 80 karakter; serif gövde için biraz artırılabilir */

  /* Aralık: tek ritim */
  --space-1: .25rem; --space-2: .5rem; --space-3: 1rem; --space-4: 1.5rem;
  --space-5: 2.5rem; --space-6: 4rem;  --space-7: clamp(4rem, 9vw, 8rem);

  /* Biçim: köşe yarıçapı hiyerarşiye göre, tek değer zorunlu değil */
  --radius-s: <değer>; --radius-l: <değer>;

  /* Hareket */
  --ease-out: cubic-bezier(.16, 1, .3, 1);
  --dur-micro: 160ms; --dur-moment: 700ms;
}
```

Açık ve koyu tema: brief bir tema belirtmiyorsa ikisini de tasarla. Koyu temayı `@media (prefers-color-scheme: dark)` altında aynı adlarla yeniden tanımla. `body` için açık bir arka plan ver.

### 4.2 Hareket: tek bir düzenlenmiş an
Sayfada en fazla bir otomatik an olsun (açılış dizisi ya da tek bir önemli reveal). Geri kalan hareket kullanıcı eylemine yanıt versin.

```js
// Tek düzenlenmiş an: yalnızca [data-moment] öğeleri, tek seferlik, azaltılmış harekete saygılı
const rm = matchMedia('(prefers-reduced-motion: reduce)').matches;
const els = document.querySelectorAll('[data-moment]');
if (rm) els.forEach(el => el.classList.add('in'));
else {
  const io = new IntersectionObserver(es => es.forEach(e => {
    if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); }
  }), { threshold: 0.3 });
  els.forEach(el => io.observe(el));
}
```

- Yalnızca `opacity` ve `transform` animasyonu yap. `top` ve `left` gibi özellikleri asla canlandırma.
- `linear` ya da zıplayan easing kullanma.
- Kaydırmayı ele geçirme: sayfa sabitlenmez, kullanıcı zorla bir sinema dizisinden geçirilmez.
- Paralaks, tilt ve sayaç gibi efektleri varsayılan olarak ekleme. Yalnızca planın "tek cesur yer"i buysa kullan, o zaman da tek yerde.

```css
@media (prefers-reduced-motion: reduce) {
  *, *::before, *::after { animation-duration: .01ms !important; transition-duration: .01ms !important; scroll-behavior: auto !important; }
}
```

### 4.3 Mobil uyum
- En az 375 px genişlikte test et, yatay sayfa kaydırması olmasın. Yan boşluk en az 16 px.
- Akışkan tip `clamp()` ile kurulsun, kırılma noktalarında yazı boyutu sıçramasın.
- Hero yüksekliğinde `vh` değil `svh` kullan.
- Dokunma hedefleri en az 44×44 px olsun.
- Çok sütunlu yerleşimler bilinçli biçimde tek sütuna insin. Tablolar mobilde ya yatay kaydırılabilir kaba alınsın ya da kartlara dönsün.
- Gezinme menüsü mobilde gerçek bir panel olsun: odak yönetimi ve `aria-expanded` ile.

### 4.4 Erişilebilirlik
- Kontrast: gövde metni en az 4.5:1, büyük metin en az 3:1.
- Görünür `:focus-visible` halkası, mantıklı sekme sırası ve içeriğe atlama bağlantısı olsun.
- Anlamsal HTML kullan: tek `h1`, `header/nav/main/section/footer`, işlevi anlatan `alt` metni ve `lang="tr"` (ya da içeriğin dili).
- Otomatik ses çalma. Karuseller durdurulabilsin. Bildirimler `role="status"` taşısın.
- Veri ve fiyatlarda `font-variant-numeric: tabular-nums` kullan.

### 4.5 Görseller
- Stok fotoğraf yerine prosedürel, SVG ya da CSS ile çizilmiş görseller ya da kullanıcının verdiği gerçek görseller kullan. Lisans riski olmaz, yük hafifler, palete tam uyar.
- Görsellerde `width` ve `height` belirt (CLS < 0.1). AVIF veya WebP kullan.
- Prosedürel 3D (Three.js) yalnızca planın tek cesur yeri buysa kullan. Statik poster yedeği koy, azaltılmış harekette ve düşük güçte kapat.
- Bilinen bir markayı, logoyu, karakteri ya da var olan bir ürünün veya oyunun görünümünü kopyalama. Gerçek bir kurumu taklit eden giriş ya da ödeme sayfası yapma.

---

## 5. Ürün türüne göre karakter

Her ürün kendi türü gibi hissettirmeli. Tek bir kaplamayı her şeye uygulama. Aşağıdaki tablo bir başlangıç noktasıdır, renk ve tip yine brief'ten gelir.

| Tür | Ürünler | Ağırlık nerede |
|---|---|---|
| **Editoryal** | portfolyo, marka, otel ve restoran, moda, kültür | Tipografi ve kompozisyon. Cesur yer çoğu zaman başlık yazısının kendisidir. |
| **Analitik** | fintech, pano, B2B SaaS | Okuma sırası tek bir birincil metriğin çevresinde kurulur. Renk yalnızca eğilim ve durum için kullanılır. Yoğun ama taranabilir. |
| **Araç** | editör, yaratıcı araçlar, yönetim panelleri | Çalışma alanı baskındır, kabuk geri çekilir. Her kontrolün hover, odak, etkin ve devre dışı durumları görünür. |
| **Kurumsal / kamu** | okul, belediye, resmî kurum | Netlik ve güven. Sade hiyerarşi, yüksek kontrast, yazım kurallarına tam uyum, süsten çok erişilebilirlik. |

---

## 6. Çıktı sözleşmesi

- **Varsayılan:** tek dosyalık, bağımsız bir `index.html`. CSS ve JS satır içinde, anlamsal HTML5, derleme adımı yok. Yazı tipleri Google Fonts'tan `preconnect` ve `display=swap` ile yüklenir. Dış kütüphane yalnızca efekt gerçekten gerektiriyorsa, sabit sürüm numarasıyla eklenir.
- Ortam artifact yayınlamayı destekliyorsa ve kullanıcı dosya istemediyse siteyi artifact olarak yayınla. Kullanıcı HTML'in kendisini istiyorsa ya da kod kendi sitesine gidecekse dosya ver.
- Projede bir framework (React, Vue, Capacitor vb.) varsa projenin yapısına uy. Projeye özel skill'ler (`webview-apk-kurallari`, `capacitor-*`) önce gelir.
- Teslimden önce sayfayı tarayıcıda aç, masaüstü ve mobilde ekran görüntüsüyle bak, konsol hatalarını kontrol et. Yalnızca kod verme. Önizleme ya da ekran görüntüsü de ver.

---

## 7. Tasarımda metin

- Sözcükler tasarımda tek bir nedenle bulunur: anlamayı ve kullanmayı kolaylaştırmak için. Süs değil, tasarım içeriğidir. Yazmadan önce tasarımın ne söylemesi gerektiğini ve bunu kullanıcıya en iyi nasıl söyleyeceğini sor.
- Son kullanıcının bakış açısından yaz. Şeyleri sistemin nasıl kurulduğuna göre değil, kullanıcının anlayacağı sade dille adlandır. Kullanıcı "bildirimlerini" yönetir, "webhook yapılandırmasını" değil.
- Bir şeyi satmaya çalışmak yerine ne olduğunu ya da ne yaptığını açıkça anlat. Zekice olmaktan çok net ve yeni kullanıcı için anlaşılır olmak önemlidir.
- Etken çatı kullan. Düğme ne olacağını söylesin: "Gönder" değil "Değişiklikleri kaydet". Bir eylem akış boyunca aynı adı taşısın: "Yayımla" düğmesi "Yayımlandı" bildirimi üretsin.
- Hata ve boş durumlar yön verme anlarıdır. Neyin yanlış gittiğini ve nasıl düzeltileceğini arayüzün sesiyle söyle. Hatalar özür dilemez ve asla belirsiz değildir. Boş bir ekran, harekete geçme davetidir.
- Ton sohbet havasında olsun: sade fiiller, cümle düzeninde büyük harf, dolgu yok. Ton marka ve kitleye uysun. Her metin öğesi tek bir iş yapsın.
- "Hemen başla", "İş akışını güçlendir", "Geleceğin kilidini aç" gibi kalıplar şablon kokar. Konuya özgü, somut metin yaz.
- Türkçe içerikte TDK yazım ve noktalama kurallarına uy.

---

## 8. Asla gönderilmeyecekler

1. Brief istemediği hâlde §3'teki beş varsayılan kümeden birine düşen palet veya düzen
2. Başlıkta tek sözcüğü italik, renkli ya da kalınla vurgulamak; büyük harf etiketler; gereksiz eyebrow'lar
3. Her bölümde fade-up, her kartta hover tilt; kaydırmayı ele geçiren sayfalar
4. Sıra olmayan içerikte 01/02/03 numaraları
5. Birbirinin aynı kartlar, aynı gri gölge, süs gradyanları, mor-mavi gradyan hero
6. Lorem ipsum, stok fotoğraf, ikon yerine emoji
7. Ölü bağlantılar, durumu olmayan düğmeler, `alert()` demoları. Ürün kararları çözülmemişken "çözülmüş görünen" arayüzler (hiçbir yere gitmeyen menüler, durumu olmayan kontroller)
8. Hareket varken `prefers-reduced-motion` desteğinin olmaması, görünmeyen odak, düşük kontrast
9. Birbirini iptal eden CSS seçicileri, bölümler arası çakışan margin ve padding
10. Yerleşimi kaydıran yazı tipi yüklemesi (FOUT ile CLS)

---

## 9. Teslim öncesi kontrol listesi

- [ ] Konu, kitle ve birincil iş belirlendi. Gerekiyorsa kullanıcıyla teyit edildi.
- [ ] Plan (4-6 adlandırılmış renk, tip, ASCII yerleşim, ilkeler) brief'e karşı denetlendi. Değişenler ve nedenleri kullanıcıya söylendi.
- [ ] Hero konunun en karakteristik öğesiyle açılıyor.
- [ ] Tek cesur yer var, gerisi sakin. Bir aksesuar çıkarıldı.
- [ ] Bütün stiller token'lardan geliyor. Vurgu rengi anlam için kullanılıyor.
- [ ] Satır uzunluğu 80 karakterin altında. Tip ölçeği tutarlı.
- [ ] Otomatik hareket tek bir anla sınırlı. Azaltılmış hareket destekleniyor.
- [ ] 375 px'de yatay kaydırma yok. Dokunma hedefleri ve odak halkası tamam. Kontrast sınırları karşılanıyor.
- [ ] Metinler kullanıcının dilinde ve etken çatılı. Hata ve boş durumlar yön veriyor. TDK uyumlu.
- [ ] Masaüstü ve mobil ekran görüntüsüyle bakıldı. Konsol temiz.
- [ ] §8'deki maddelerin hiçbiri yok.

---

## Ek A. 5.1 karanlık editoryal hazır stili (yalnızca açıkça istenirse)

Kullanıcı açıkça "Fable 5.1 tarzı", "eski karanlık editoryal görünüm" ya da bu değerleri isterse brief kazanır ve şu stil uygulanır:

- **Renk:** #0A0A0A zemin, #111/#161616 yüzeyler; gövde metni #E5E5E5, başlıklar #FFFFFF; tek vurgu rengi (ör. #C9A26B); ince çizgiler rgba(255,255,255,.08)
- **Tip:** EB Garamond başlık (400-500 ağırlık, −0.02em aralık, 1.04 satır yüksekliği) ve Hanken Grotesk gövde (16 px, 1.65 satır yüksekliği)
- **Ritim:** bölüm aralığı masaüstünde 120-160 px, mobilde 80 px. Düğme dolgusu en az 16×32 px, tek köşe yarıçapı (8 px)
- **Hareket:** 30 px fade-up, 0.6 s ease-out, %20 kesişimde tetiklenir, 90 ms kademeli. Paralaks −0.08 ile −0.2 arası. Hover'da 2 px kalkma

Bu stilde de §4 kalite tabanı, §7 metin kuralları ve §9 kontrol listesi aynen geçerlidir. Kullanıcıya bu görünümün 5.2'de yapay zekâ varsayılanlarından biri sayıldığını bir cümleyle söyleyebilirsin. Ama istediği buysa itiraz etmeden uygula.
