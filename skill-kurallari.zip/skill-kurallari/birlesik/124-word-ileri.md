# word-ileri

---
name: word-ileri
description: Microsoft Word'de profesyonel düzeyde belge oluşturma, düzenleme ve otomasyon için kullanılır. Kullanıcı "Word belgesi", "üst yazı şablonu", "içindekiler", "stil", "başlık formatı", "şablon", "alan kodu", "otomatik içindekiler", "üstbilgi/altbilgi", "bölüm sonu", "filigran", "izlenen değişiklikler", "form alanı", "şablon oluştur" gibi ifadeler kullandığında devreye girer. Word'ün gerçek profesyonel araçlarını (stiller, alan kodları, makro çağırma, içindekiler, alıntı yöneticisi) öğretir ve uygular.
---

# Word İleri Kullanım Ustası

## Genel İlke

Word'ü **kelime işlemci** olarak kullanmak ile **belge sistemi** olarak kullanmak iki farklı şeydir. Profesyonel kullanıcı her şeyi elle biçimlendirmez; **stiller, alan kodları ve şablonlar** kullanır. Bu skill, Word'ün gerçek gücünü ortaya çıkarır.

Bu skill `docx` resmi skill'iyle birlikte çalışır: O dosyayı **üretir**, bu skill ise **profesyonel teknikleri** kullanır.

---

## BÖLÜM 1: Stil Sistemi (En Önemli)

### Stil Nedir, Niye Kritik?

**Stil**, bir paragrafa/karaktere uygulanan **biçim paketinin adıdır**. "Başlık 1" stili, font + boyut + renk + boşluk + numara biçimi hepsini bir arada tutar.

**Stil kullanmadan biçimlendirme yapılırsa:**
- Belgede tutarsızlık çıkar (her başlık biraz farklı görünür)
- İçindekiler tablosu otomatik oluşturulamaz
- Tek tıkla biçim değişikliği yapılamaz
- 50 sayfalık belgede 5 saatlik düzeltme işi olur

**Stil kullanılırsa:**
- Tek tıkla tüm "Başlık 1"ler değişir
- İçindekiler otomatik oluşur
- Belge bir bütün olarak tutarlı olur

### Standart Stil Listesi (Mutlaka Kullanılacaklar)

| Stil Adı | Kullanım |
|----------|----------|
| **Normal** | Ana metin (varsayılan) |
| **Başlık 1** | Ana bölüm başlıkları |
| **Başlık 2** | Alt bölüm başlıkları |
| **Başlık 3** | Üçüncü seviye başlıklar |
| **Alıntı** | Uzun alıntılar (girintili) |
| **Resim Yazısı** | Şekil/tablo açıklamaları |
| **Vurgu** | Karakter stili — italik vurgu |
| **Güçlü Vurgu** | Karakter stili — kalın vurgu |

### Stil Nasıl Düzenlenir?

1. Word'de **Stiller bölmesi** açık olmalı (Ctrl+Alt+Shift+S)
2. Düzenlenecek stile **sağ tık → Değiştir**
3. Yapılan değişiklik **belgenin tamamına** uygulanır
4. "Bu şablona göre yeni belgeler" işaretlenirse şablona da işler

### Stil Tabanlı Çalışma Akışı

**Doğru:**
1. Önce bütün başlıkları **"Başlık 1"** olarak işaretle (henüz görsel önemli değil)
2. Bütün metni **"Normal"** olarak bırak
3. **Sonra** stilleri **bir kez** istediğin gibi düzenle
4. Her şey otomatik güncellenir

**Yanlış:**
1. Her başlığı tek tek seç, fontunu büyüt, kalın yap, renklendir...
2. (200 başlık varsa 200 kez yap)
3. Stil değişikliği gerektiğinde 200 kez tekrar et

---

## BÖLÜM 2: Otomatik İçindekiler

### Önkoşul

İçindekiler tablosu **stillerle** oluşur. Eğer başlıklar "Başlık 1, 2, 3" stili kullanıyorsa, Word otomatik içindekiler tablosu çıkarır.

### Ekleme

**Ekle (Insert) → İçindekiler (Table of Contents)**

İki ana seçenek:
- **Otomatik tablo:** Hazır şablonlardan biri
- **Özel içindekiler:** Hangi başlık seviyelerini dahil edeceğinizi seçersiniz (genelde 1-3 seviye yeterli)

### Güncelleme

Belgede başlık eklendi/değiştirildi mi? **İçindekiler tablosuna sağ tık → Alanı Güncelle**.

İki seçenek:
- **Sadece sayfa numaralarını güncelle**
- **Tüm tabloyu güncelle** (yeni başlıklar dahil)

**Kural:** Belgeyi PDF'e çevirmeden ÖNCE mutlaka güncelle. Yoksa PDF'te yanlış sayfa numarası olur.

---

## BÖLÜM 3: Üstbilgi ve Altbilgi (Header/Footer)

### Temel

**Ekle → Üstbilgi/Altbilgi**

İçeriğine yazdığın şey **her sayfada** tekrarlanır.

### Profesyonel İpuçları

**1. İlk Sayfada Farklı**
- "Tasarım → İlk Sayfada Farklı" kutusunu işaretle
- Kapak sayfasında üstbilgi/altbilgi olmaz

**2. Tek/Çift Sayfada Farklı**
- Kitap düzeni için (sol-sağ sayfalar farklı)

**3. Bölüme Göre Farklı**
- Bölüm 1: "Giriş" yazsın
- Bölüm 2: "Ana Metin" yazsın
- Bunun için **bölüm sonları** kullanılır (aşağıda)

### Sayfa Numarası Ekleme

**Ekle → Sayfa Numarası**

- "Sayfa X / Y" formatı için: Ekle → Hızlı Parçalar → Alan → "NumPages"

---

## BÖLÜM 4: Bölüm Sonları (Section Breaks)

### Niye Önemli?

Bir Word belgesinde **farklı düzenler** istediğinde bölüm sonu kullanılır:

- Bir kısmı dikey, bir kısmı yatay
- Bir kısmı tek sütun, bir kısmı iki sütun
- Bir kısmında üstbilgi olsun, diğerinde olmasın
- Bir bölümde sayfa numarası "i, ii, iii", diğerinde "1, 2, 3"

### Ekleme

**Düzen → Sonlar → Bölüm Sonları**

Türleri:
- **Sonraki Sayfa:** Yeni bölüm sonraki sayfadan başlar
- **Sürekli:** Aynı sayfada yeni bölüm
- **Tek Sayfa / Çift Sayfa:** Tek/çift numaralı sayfadan başlar

### Profesyonel Kullanım

**Tipik akademik belge yapısı:**
```
Kapak (numara yok)
[Bölüm Sonu]
Önsöz, İçindekiler (i, ii, iii)
[Bölüm Sonu]
Ana Metin (1, 2, 3)
[Bölüm Sonu]
Kaynakça (devam eden numara)
[Bölüm Sonu]
Ekler (A-1, A-2, B-1...)
```

---

## BÖLÜM 5: Alan Kodları (Fields)

### Alan Nedir?

Otomatik güncellenen "akıllı içerik". Örnekleri:

| Alan | Ne yapar |
|------|----------|
| `{ DATE }` | Bugünün tarihi (her açılışta günceller) |
| `{ TIME }` | Şu anki saat |
| `{ PAGE }` | Mevcut sayfa numarası |
| `{ NUMPAGES }` | Toplam sayfa sayısı |
| `{ AUTHOR }` | Belge yazarı |
| `{ FILENAME }` | Belge adı |
| `{ TOC }` | İçindekiler tablosu |
| `{ REF Yer İmi }` | Belgenin başka yerine referans |

### Ekleme

**Ekle → Hızlı Parçalar → Alan**

### Güncelleme

- Tek alan: Üzerine sağ tık → Alanı Güncelle (veya F9)
- Tüm alanlar: Tüm belgeyi seç (Ctrl+A) → F9

### Profesyonel İpucu

**Kapak sayfasında:**
- "Tarih: { DATE \@ "dd MMMM yyyy" }" → "Tarih: 08 Mayıs 2026"
- Belge her açıldığında tarih güncellenir

**Üstbilgide:**
- "Sayfa { PAGE } / { NUMPAGES }" → "Sayfa 5 / 23"

---

## BÖLÜM 6: İzlenen Değişiklikler ve Yorumlar

### Track Changes (İzlenen Değişiklikler)

**Gözden Geçir → İzlenen Değişiklikler**

Açıkken yapılan her değişiklik **kaydedilir** ve farklı renkle görünür.

**Kullanım Senaryosu:**
- Bir yazıyı düzenliyorsun, **patron neyi değiştirdiğini görsün** istiyorsun → İzlenen Değişiklikler aç
- Patron isterse **kabul/red** edebilir
- Eğer kabul edilirse değişiklik kalıcı olur

### Yorumlar (Comments)

**Gözden Geçir → Yeni Yorum**

Metnin yanına bir **not iliştirilir**. Belge çıktısında görünmez (genelde) ama dijital incelemede görünür.

**Kullanım:**
- "Bu paragrafı tekrar yazalım" notu
- "Mevzuat referansı eksik" uyarısı
- "Burayı sonra dolduracağız" hatırlatması

### Profesyonel Akış

1. Taslak yaz
2. **Track Changes aç**, kontrol et
3. Şüpheli yerlere **yorum** ekle
4. Patron/meslektaşa gönder
5. Onların yorumlarını/değişikliklerini al
6. **Hepsini kabul et** veya tek tek değerlendir
7. Track Changes kapat
8. Yorumları sil
9. Final belge

---

## BÖLÜM 7: Tablolar (Profesyonel Düzeyde)

### Temel Sorunlar

**Çoğu Word kullanıcısının yaptığı hatalar:**
- Tabloya **boşlukla hizalama** yapmak (Tab/Enter ile)
- Hücreleri **görsel olarak** birleştirip içerik kaybetmek
- Tablonun **otomatik genişliğini** bozmak

### Doğru Kullanım

1. **Tablo araçları → Düzen → Hücre Boyutu**: Eşit dağıt
2. **Tablo araçları → Tasarım**: Hazır stil seç (basit ve okunaklı olanı)
3. **Başlık satırını tekrar et:** Birden fazla sayfaya yayılan tablolarda **her sayfada başlık satırı** görünmeli (Düzen → Başlık Satırlarını Yinele)
4. **Hücre içi hizalama:** Sağ tık → Hücre Hizalama (sayılar sağa, metin sola, başlık ortaya)

### Tablo Açıklaması

Tablonun ÜSTÜNDE veya ALTINDA "Tablo 1: Başlık" yazılır.

**Ekle → Resim Yazısı** ile otomatik numaralı yazılır. Sonradan tablo eklerseniz numaralar otomatik güncellenir.

---

## BÖLÜM 8: Resimler ve Şekil Yerleşimi

### "Metnin İçinde" mi "Metnin Üzerine" mi?

| Mod | Kullanım |
|-----|----------|
| **Metnin içinde** | Resim metin gibi davranır, satır içinde durur (varsayılan) |
| **Kare** | Metin resmin etrafından akar |
| **Sıkı** | Metin resmin tam kenarından akar |
| **Metnin önünde** | Resim metnin üstünde "yüzer" (dikkatli kullan) |

### Profesyonel Tavsiye

Resmi belgelerde **"metnin içinde"** veya **"kare"** kullanın. "Yüzen" resimler düzeni bozar, baskıda yer değiştirir.

### Resim Açıklaması

Tablodaki gibi: Resim altında "Şekil 1: Açıklama". Otomatik numaralandırma için **Ekle → Resim Yazısı**.

---

## BÖLÜM 9: Şablon Oluşturma

### Niye?

Aynı tipte belge çok yazılıyorsa (üst yazı, rapor, sözleşme), her seferinde sıfırdan başlamak yerine **şablon** oluşturulur.

### Adımlar

1. **Yeni belge oluştur** ve istediğin biçimi ver:
   - Stiller ayarla
   - Üstbilgi/altbilgi yerleştir
   - Logo, antet ekle
   - Yer tutucu metinler koy ("[Tarih buraya]", "[Kurum adı]")
2. **Dosya → Farklı Kaydet**
3. **Dosya türü:** Word Şablonu (.dotx)
4. Bu dosyayı açtığında her seferinde **yeni boş kopya** alırsın, orijinal şablon korunur.

### EBYS için Şablon Mantığı

EBYS'de zaten antet, sayı, tarih otomatik geliyor. Word şablonu oraya **dışarıdan giren içerikler** için işe yarar:
- "İlgi" satırı şablonu
- "Konu" başlık şablonu
- "Sonuç ifadesi" hazır kalıpları
- İmza bloğu şablonu

---

## BÖLÜM 10: Klavye Kısayolları (Hız Kazandıran)

| Kısayol | Ne yapar |
|---------|----------|
| Ctrl + Enter | Sayfa sonu |
| Ctrl + Shift + Enter | Sütun sonu |
| Ctrl + L / E / R | Sola / ortaya / sağa hizala |
| Ctrl + J | İki yana yasla |
| Ctrl + Shift + N | Stili "Normal"e döndür |
| Alt + Shift + Yukarı/Aşağı | Paragrafı taşı |
| F4 | Son işlemi tekrarla (çok güçlü) |
| Ctrl + Shift + C | Biçim kopyala |
| Ctrl + Shift + V | Biçim yapıştır |
| F7 | Yazım denetimi |
| Shift + F3 | BÜYÜK / küçük / İlk Harf Büyük döngüsü |

---

## Kontrol Listesi: Profesyonel Belge

Belgeyi bitirmeden önce:

- [ ] **Stilleri** kullandım mı, yoksa elle mi biçimlendirdim?
- [ ] **Başlıklar** "Başlık 1, 2, 3" stilinde mi?
- [ ] **İçindekiler** otomatik mi, güncel mi?
- [ ] **Sayfa numarası** ekli mi, doğru başlıyor mu?
- [ ] **Üstbilgi/altbilgi** uygun mu?
- [ ] **Tablolar** ve **resimler** açıklamalı (numarayla) mı?
- [ ] **Yazım denetimi** çalıştırdım mı?
- [ ] Track Changes **kapalı** mı (final belge için)?
- [ ] **Yorumlar** silindi mi?
- [ ] **Bölüm sonları** doğru yerde mi?
- [ ] PDF'e çevirmeden önce **alan kodları güncellendi** mi?

---

## Son Söz

Word'ü iyi kullanan kişi, **belgeyi yazmaya değil, yapısını düşünmeye** zaman ayırır. Doğru yapı kurulursa belge kendi kendini yönetir.

İyi belge = Doğru stil + temiz yapı + akıllı otomasyon.
