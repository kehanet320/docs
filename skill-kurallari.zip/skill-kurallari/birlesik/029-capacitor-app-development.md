# capacitor-app-development


---

## Dosya: `SKILL.md`

---
name: capacitor-app-development
description: "Guides the agent through general Capacitor app development topics. Covers core concepts (native bridge, plugins, web layer), Capacitor CLI usage, app configuration (capacitor.config.ts, splash screens, app icons, deep links), platform management (Android, iOS, Electron, PWA), edge-to-edge and safe area handling on Android, live reload setup, storage solutions, file handling, security best practices, CI/CD references, iOS package managers (SPM, CocoaPods), and troubleshooting for Android and iOS. Do not use for creating new Capacitor apps, Capacitor plugin APIs, creating Capacitor plugins, in-app purchases, upgrading Capacitor versions, Cordova or PhoneGap migration, or framework-specific patterns (Angular, React, Vue)."
metadata:
  author: capawesome-team
  source: https://github.com/capawesome-team/skills/tree/main/skills/capacitor-app-development
---

# Capacitor App Development

General guidance for developing cross-platform apps with Capacitor, covering core concepts, CLI usage, app configuration, platform management, and troubleshooting.

## Prerequisites

1. **Capacitor 6, 7, or 8** app already created and initialized.
2. Node.js and npm installed (Node 18+ for Cap 6, Node 20+ for Cap 7, Node 22+ for Cap 8).
3. For **Android**: Android Studio installed.
4. For **iOS**: Xcode installed on macOS.

## Agent Behavior

- **Auto-detect before asking.** Inspect the project for platforms (`android/`, `ios/`), framework (`vite.config.ts`, `angular.json`, `webpack.config.js`, `next.config.js`), Capacitor version (`@capacitor/core` in `package.json`), and iOS dependency manager (`ios/App/Podfile` for CocoaPods vs. SPM).
- **Route to the right reference file.** Use the topic index below to identify the correct reference file and read it before providing guidance.
- **One topic at a time.** Address the user's specific question. Do not provide a general overview unless explicitly requested.
- **Prefer actionable instructions.** Provide exact file paths, commands, and diff blocks rather than conceptual explanations.

## Procedures

### Step 1: Identify the Topic

Match the user's request to a topic from the index below. If the request spans multiple topics, address them sequentially.

If the request matches a topic covered by a **different skill**, redirect the user to that skill (see Related Skills at the bottom).

### Step 2: Analyze the Project

Auto-detect the following by reading project files:

1. **Capacitor version**: Read `@capacitor/core` version from `package.json`.
2. **Platforms**: Check which directories exist (`android/`, `ios/`).
3. **Framework**: Check for build tool config files.
4. **Capacitor config format**: Check for `capacitor.config.ts` or `capacitor.config.json`.
5. **iOS dependency manager**: Check for `ios/App/Podfile` (CocoaPods) or SPM usage.

### Step 3: Read the Reference File and Apply Guidance

Read the reference file for the matched topic and apply the instructions to the user's project.

## Topic Index

| Topic | Reference |
| ----- | --------- |
| Core concepts (native bridge, how Capacitor works) | `references/core-concepts.md` |
| Capacitor platforms (Android, iOS, Electron, PWA) | `references/platforms.md` |
| Capacitor CLI commands | `references/cli.md` |
| App configuration (`capacitor.config.ts`) | `references/app-configuration.md` |
| Splash screens and app icons | `references/splash-screens-and-icons.md` |
| Deep links and universal links | `references/deep-links.md` |
| Android edge-to-edge support | `references/edge-to-edge.md` |
| Android safe area handling | `references/safe-area.md` |
| Live reload setup | `references/live-reload.md` |
| Storage solutions | `references/storage.md` |
| File handling best practices | `references/file-handling.md` |
| Security best practices | `references/security.md` |
| iOS package managers (SPM, CocoaPods) | `references/ios-package-managers.md` |
| CI/CD for Capacitor apps | `references/ci-cd.md` |
| Testing (unit and E2E) | `references/testing.md` |
| Cross-platform best practices | `references/cross-platform-best-practices.md` |
| Android troubleshooting | `references/troubleshooting-android.md` |
| iOS troubleshooting | `references/troubleshooting-ios.md` |

## Error Handling

- **`npx cap sync` fails**: Verify `@capacitor/core` and `@capacitor/cli` versions match. On iOS with CocoaPods, run `cd ios/App && pod install`. On Android, sync Gradle files in Android Studio.
- **Android build fails after configuration changes**: Clean the build with `cd android && ./gradlew clean`, then rebuild.
- **iOS build fails after configuration changes**: Clean the build folder in Xcode (Product > Clean Build Folder) or delete `ios/App/Pods` and run `cd ios/App && pod install`.
- **Plugin not found at runtime**: Run `npx cap sync` after any plugin installation. Verify the plugin appears in `capacitor.config` or the native project.
- **Live reload not connecting**: Verify the device and development machine are on the same network. Check that the server URL in `capacitor.config` uses the correct LAN IP address.
- **Deep links not working**: Verify the site association file is accessible at `https://<domain>/.well-known/apple-app-site-association` (iOS) or `https://<domain>/.well-known/assetlinks.json` (Android). Verify the app is signed with the correct certificate.

## Related Skills

- **`capacitor-app-creation`** — Create a new Capacitor app.
- **`capacitor-angular`** — Angular-specific Capacitor development.
- **`capacitor-react`** — React-specific Capacitor development.
- **`capacitor-vue`** — Vue-specific Capacitor development.
- **`capacitor-plugins`** — Install and configure Capacitor plugins.
- **`capacitor-plugin-development`** — Create custom Capacitor plugins.
- **`capacitor-app-upgrades`** — Upgrade Capacitor to a newer major version.
- **`capacitor-in-app-purchases`** — Set up in-app purchases.
- **`capawesome-cloud`** — Cloud builds, live updates, and app store publishing.


---

## Dosya: `references/app-configuration.md`

# App Configuration

Capacitor is configured through `capacitor.config.ts` (TypeScript) or `capacitor.config.json` (JSON) in the project root.

## Configuration File Formats

### TypeScript (recommended)

```typescript
import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.example.myapp',
  appName: 'My App',
  webDir: 'dist',
};

export default config;
```

### JSON

```json
{
  "appId": "com.example.myapp",
  "appName": "My App",
  "webDir": "dist"
}
```

TypeScript is preferred because it enables IDE autocompletion and type checking for all configuration options.

## Core Properties

| Property | Type | Description |
| -------- | ---- | ----------- |
| `appId` | `string` | App identifier in reverse-domain format (e.g., `com.example.myapp`). Must match the native project's bundle/application ID. |
| `appName` | `string` | Display name of the app. |
| `webDir` | `string` | Directory containing the built web assets (e.g., `dist`, `www`, `build`). Relative to the project root. |
| `bundledWebRuntime` | `boolean` | Deprecated. Do not use. |

## Server Configuration

Control how the WebView loads content:

```typescript
const config: CapacitorConfig = {
  server: {
    url: 'http://192.168.1.68:8100',    // Load from a remote URL (for live reload)
    cleartext: true,                      // Allow HTTP (non-HTTPS) traffic
    androidScheme: 'https',               // URL scheme for Android (default: 'https')
    iosScheme: 'capacitor',               // URL scheme for iOS (default: 'capacitor')
    hostname: 'localhost',                 // Hostname for the local server
    allowNavigation: ['example.com'],      // Allowed navigation hosts
    errorPath: 'error.html',              // Custom error page
  },
};
```

- **`url`**: Override the default local file serving to load from a remote URL. Used primarily for live reload during development. **Do not commit to version control.**
- **`cleartext`**: Set to `true` to allow HTTP traffic. Required when `url` uses `http://`.
- **`androidScheme`**: The URL scheme used on Android. Default is `https`. Changing this affects CORS, localStorage, and cookie behavior.
- **`iosScheme`**: The URL scheme used on iOS. Default is `capacitor`.
- **`allowNavigation`**: List of hostnames or URL patterns the WebView is allowed to navigate to.

## Plugin Configuration

Configure plugin-specific options under the `plugins` key:

```typescript
const config: CapacitorConfig = {
  plugins: {
    SplashScreen: {
      launchShowDuration: 2000,
      backgroundColor: '#ffffff',
    },
    Keyboard: {
      resize: 'body',
      resizeOnFullScreen: true,
    },
    SystemBars: {
      insetsHandling: 'disable',
    },
  },
};
```

Each plugin documents its own configuration options. Refer to the plugin's documentation for available keys.

## Android-Specific Configuration

```typescript
const config: CapacitorConfig = {
  android: {
    path: 'android',                      // Path to the Android project
    buildOptions: {
      releaseType: 'AAB',                 // 'AAB' or 'APK'
      signingType: 'apksigner',
      keystorePath: '/path/to/keystore',
      keystorePassword: 'password',
      keystoreAlias: 'alias',
      keystoreAliasPassword: 'password',
    },
    flavor: 'production',                 // Default flavor
    allowMixedContent: false,             // Allow HTTP content in HTTPS WebView
    backgroundColor: '#ffffff',           // WebView background color
    loggingBehavior: 'debug',             // Logging level: 'none', 'debug', 'production'
    webContentsDebuggingEnabled: true,    // Enable Chrome DevTools for WebView (debug only)
  },
};
```

## iOS-Specific Configuration

```typescript
const config: CapacitorConfig = {
  ios: {
    path: 'ios',                          // Path to the iOS project
    scheme: 'App',                        // Xcode scheme
    backgroundColor: '#ffffff',           // WebView background color
    contentInset: 'automatic',            // 'automatic', 'scrollableAxes', 'never', 'always'
    limitsNavigationsToAppBoundDomains: false,
    preferredContentMode: 'mobile',       // 'mobile' or 'desktop'
    webContentsDebuggingEnabled: true,    // Enable Safari Web Inspector (debug only)
  },
};
```

## Environment-Specific Configuration

Use the TypeScript config format to conditionally apply settings based on environment variables:

```typescript
import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.example.myapp',
  appName: 'My App',
  webDir: 'dist',
};

if (process.env.NODE_ENV === 'development') {
  config.server = {
    url: 'http://192.168.1.68:8100',
    cleartext: true,
  };
}

export default config;
```

This avoids accidentally shipping development settings in production builds.


---

## Dosya: `references/ci-cd.md`

# CI/CD for Capacitor Apps

Set up continuous integration and continuous deployment for Capacitor apps.

## Capawesome Cloud (Recommended)

Capawesome Cloud provides a managed CI/CD solution for Capacitor apps with native builds, live updates, and app store publishing.

For full setup and usage, use the **`capawesome-cloud`** skill.

Key features:
- Cloud-based native builds for iOS and Android (no local Xcode/Android Studio required for builds).
- Live updates (OTA) to push web layer changes without app store review.
- Automated app store publishing to Apple App Store and Google Play Store.
- Signing certificate management.
- Environment variables and secrets.
- CI/CD integration via the `@capawesome/cli`.

## Self-Hosted CI/CD

For self-hosted CI/CD pipelines (GitHub Actions, GitLab CI, Bitbucket Pipelines, etc.), the general workflow is:

### Web Build

```bash
npm ci
npm run build
```

### Android Build

```bash
npm ci
npm run build
npx cap sync android
cd android && ./gradlew assembleRelease
```

The APK is at `android/app/build/outputs/apk/release/app-release.apk`.

For AAB (Android App Bundle):

```bash
cd android && ./gradlew bundleRelease
```

The AAB is at `android/app/build/outputs/bundle/release/app-release.aab`.

Android builds require:
- Java (JDK 17 for Capacitor 7, JDK 21 for Capacitor 8).
- Android SDK and build tools.
- A signing keystore for release builds.

### iOS Build

```bash
npm ci
npm run build
npx cap sync ios
cd ios/App && xcodebuild -workspace App.xcworkspace -scheme App -configuration Release -archivePath build/App.xcarchive archive
cd ios/App && xcodebuild -exportArchive -archivePath build/App.xcarchive -exportOptionsPlist ExportOptions.plist -exportPath build/output
```

iOS builds require:
- macOS runner.
- Xcode.
- Apple signing certificate and provisioning profile installed on the runner.
- An `ExportOptions.plist` file specifying the export method and signing identity.

### Live Updates via CI/CD

Upload web bundles to Capawesome Cloud from CI:

```bash
npm ci
npm run build
npx @capawesome/cli login --token $CAPAWESOME_TOKEN
npx @capawesome/cli apps:bundles:create --app-id $APP_ID --path dist/
```

For full live update setup, use the **`capawesome-cloud`** skill.

## Automated Configuration with Trapeze

Use Trapeze (`@trapezedev/configure`) to automate native project configuration changes in CI/CD. This is useful for:

- Setting version numbers and build numbers per environment.
- Configuring different app IDs for staging vs. production.
- Injecting environment-specific values.

Define configuration in a YAML file (e.g., `trapeze.yaml`):

```yaml
platforms:
  android:
    versionName: $VERSION
    versionCode: $BUILD_NUMBER
    manifest:
      - file: AndroidManifest.xml
        target: manifest
        attrs:
          package: $APP_ID
  ios:
    version: $VERSION
    buildNumber: $BUILD_NUMBER
    targets:
      App:
        bundleId: $APP_ID
```

Apply in CI:

```bash
npx @trapezedev/configure run trapeze.yaml --diff
```

## Environment Variables

Use environment variables to manage secrets and configuration across environments. Never hardcode secrets in source code.

Common CI/CD environment variables for Capacitor projects:

| Variable | Purpose |
| -------- | ------- |
| `APP_ID` | Application identifier |
| `VERSION` | App version string |
| `BUILD_NUMBER` | Build number (auto-incremented) |
| `KEYSTORE_PATH` | Path to Android signing keystore |
| `KEYSTORE_PASSWORD` | Android keystore password |
| `KEY_ALIAS` | Android key alias |
| `KEY_PASSWORD` | Android key alias password |
| `CAPAWESOME_TOKEN` | Capawesome Cloud auth token |


---

## Dosya: `references/cli.md`

# Capacitor CLI

Command reference for the Capacitor CLI (`@capacitor/cli`). All commands are invoked via `npx cap <command>`.

## Commands

### `npx cap init`

Initialize Capacitor in an existing web project. Creates `capacitor.config.ts` and `package.json` entries.

```bash
npx cap init <appName> <appId>
```

- `appName`: The display name of the app (e.g., `"My App"`).
- `appId`: The app identifier in reverse-domain format (e.g., `com.example.myapp`).

### `npx cap add <platform>`

Add a native platform to the project.

```bash
npx cap add android
npx cap add ios
```

Creates the `android/` or `ios/` directory with a full native project.

### `npx cap sync`

Copy web assets and update native plugins and dependencies. This is the most commonly used command.

```bash
npx cap sync [platform]
```

Options:
- `--deployment` — Prevent deletion of `Podfile.lock` and use `pod install --deployment`.
- `--inline` — Inline JS source maps for Android WebView debugging.

Run `npx cap sync` after:
- Building web assets (`npm run build`)
- Installing or removing plugins
- Changing `capacitor.config.ts` or `capacitor.config.json`

### `npx cap copy`

Copy web assets only (no native dependency updates). Faster than `sync` when only web code has changed.

```bash
npx cap copy [platform]
```

### `npx cap update`

Update native plugins and dependencies only (no web asset copy).

```bash
npx cap update [platform]
```

### `npx cap run`

Build, sync, and deploy to a device or emulator.

```bash
npx cap run <platform> [options]
```

Options:
- `--list` — List available target devices.
- `--target <id>` — Deploy to a specific device by ID.
- `--target-name <name>` — Deploy to a device by name (e.g., `"iPhone 17 Pro"`).
- `--target-name-sdk-version <version>` — Target devices with a specific OS version.
- `--flavor <name>` — Android build flavor.
- `--scheme <name>` — iOS build scheme.
- `--configuration <name>` — iOS scheme configuration.
- `--live-reload` or `-l` — Enable live reload (see `references/live-reload.md`).
- `--host <host>` — Live reload host.
- `--port <port>` — Live reload port.
- `--https` — Use HTTPS for live reload.
- `--forwardPorts <port1:port2>` — Run `adb reverse` for Android live reload.
- `--no-sync` — Skip the sync step before building.

### `npx cap open`

Open the native project in the platform's IDE.

```bash
npx cap open android   # Opens Android Studio
npx cap open ios       # Opens Xcode
```

### `npx cap build`

Build the native project.

```bash
npx cap build <platform> [options]
```

Options:
- `--scheme <name>` — iOS scheme name.
- `--configuration <name>` — iOS build configuration (e.g., `Debug`, `Release`).
- `--flavor <name>` — Android flavor.
- `--androidreleasetype <type>` — Android release type (`AAB` or `APK`).
- `--signing <type>` — Android signing type.
- `--keystorepath <path>` — Android keystore path.
- `--keystorepass <pass>` — Android keystore password.
- `--keystorealias <alias>` — Android key alias.
- `--keystorealiaspass <pass>` — Android key alias password.

### `npx cap doctor`

Diagnose common configuration issues.

```bash
npx cap doctor [platform]
```

Checks environment, dependencies, and configuration. Use when something is not working as expected.

### `npx cap ls`

List installed Capacitor plugins.

```bash
npx cap ls [platform]
```

### `npx cap migrate`

Interactive command intended to migrate a project to a newer Capacitor version. **Do not invoke from an agent** — it requires interactive input and cannot be driven by a script. For all upgrade work, use the `capacitor-app-upgrades` skill, which performs the upgrade manually step-by-step.

## Lifecycle Hooks

Capacitor supports lifecycle hooks in `capacitor.config.ts` that run at specific points during CLI operations:

- `capacitor:copy:before` / `capacitor:copy:after`
- `capacitor:sync:before` / `capacitor:sync:after`
- `capacitor:update:before` / `capacitor:update:after`
- `capacitor:build:before` / `capacitor:build:after`
- `capacitor:run:before` / `capacitor:run:after`

Hooks are scripts defined in `package.json`:

```json
{
  "scripts": {
    "capacitor:sync:before": "echo 'Running before sync'"
  }
}
```


---

## Dosya: `references/core-concepts.md`

# Core Concepts

How Capacitor works and its fundamental architecture.

## What Is Capacitor

Capacitor is a cross-platform native runtime that makes it possible to build web apps that run natively on iOS, Android, and the web (as a Progressive Web App). The web app runs in a native WebView, and Capacitor provides a bridge between the web layer and native APIs.

## Architecture

A Capacitor app consists of three layers:

1. **Web layer** — The HTML/CSS/JavaScript app that runs inside a native WebView. This is the standard web app built with any framework (Angular, React, Vue, plain JS, etc.).
2. **Native bridge** — A communication layer that connects the web layer to native platform APIs. When JavaScript calls a Capacitor plugin method, the bridge serializes the call, passes it to the native side, executes the native code, and returns the result back to JavaScript.
3. **Native layer** — Platform-specific code (Swift/Objective-C on iOS, Kotlin/Java on Android) that implements native functionality exposed through plugins.

## How the Native Bridge Works

1. The web app calls a plugin method, e.g., `Camera.getPhoto()`.
2. The Capacitor bridge serializes the method name and arguments into a message.
3. The message is sent to the native side via the WebView's native-to-JS communication channel.
4. The native plugin implementation receives the call, executes the platform-specific code (e.g., opens the camera), and returns the result.
5. The result is serialized back to JavaScript and resolved as a Promise.

Data passed across the bridge must be JSON-serializable. Binary data (images, files) should be passed as file paths or base64 strings, though file paths are preferred for performance (see `references/file-handling.md`).

## Plugins

Plugins are the primary extension mechanism. Each plugin exposes a JavaScript API that maps to native implementations on each platform. Capacitor provides:

- **Official plugins** (`@capacitor/*`) — Maintained by the Capacitor team.
- **Community plugins** (`@capacitor-community/*`) — Maintained by the community.
- **Third-party plugins** (e.g., `@capawesome/*`, `@capacitor-firebase/*`) — Maintained by third parties.

Plugins that have no native implementation for a given platform fall back to a web implementation if one is provided.

## Web Views

- **iOS**: Uses `WKWebView`.
- **Android**: Uses Android System WebView (Chromium-based).
- **Electron**: Uses Chromium (via Electron).

The WebView loads the web app from the device's local filesystem (not from a remote server by default), which provides fast load times and offline capability.

## Project Structure

A typical Capacitor project has this structure:

```
my-app/
  android/                  # Native Android project (Android Studio)
  ios/                      # Native iOS project (Xcode)
    App/
      App/                  # iOS app source files
      App.xcodeproj/        # Xcode project file
      Podfile                # CocoaPods dependencies (if using CocoaPods)
  src/                      # Web app source code
  www/ or dist/ or build/   # Built web assets (output directory)
  capacitor.config.ts       # Capacitor configuration
  package.json
```

The `android/` and `ios/` directories are full native projects. They can be opened in Android Studio and Xcode respectively for native development, debugging, and building.

## Key Concepts

### Capacitor Config

The `capacitor.config.ts` (or `capacitor.config.json`) file configures the app's behavior. See `references/app-configuration.md` for details.

### Sync

`npx cap sync` is the primary command for keeping the native projects in sync with the web project. It copies built web assets to the native projects and updates native dependencies. Run it after:

- Installing or removing plugins
- Changing `capacitor.config.ts`
- Building new web assets

### Native Project Ownership

Unlike some frameworks, Capacitor treats the native projects as source-controlled first-class citizens. The `android/` and `ios/` directories are committed to version control and can be modified directly. This allows full access to native APIs, custom native code, and third-party native SDKs.


---

## Dosya: `references/cross-platform-best-practices.md`

# Cross-Platform Best Practices

Guidelines for building Capacitor apps that work well across Android, iOS, and the web.

## Platform Detection

Use `Capacitor.getPlatform()` and `Capacitor.isNativePlatform()` to handle platform differences:

```typescript
import { Capacitor } from '@capacitor/core';

const platform = Capacitor.getPlatform(); // 'android', 'ios', or 'web'

if (Capacitor.isNativePlatform()) {
  // Native-only code (Android or iOS)
}
```

## Plugin Availability

Not all plugins are available on all platforms. Check availability before calling a plugin method:

```typescript
import { Capacitor } from '@capacitor/core';

if (Capacitor.isPluginAvailable('Camera')) {
  // Camera plugin is available on this platform
  const photo = await Camera.getPhoto({ ... });
} else {
  // Provide a fallback (e.g., file input on web)
}
```

## Responsive Design

- Design for mobile-first, then adapt for larger screens (tablets, desktop via Electron or PWA).
- Use CSS media queries and flexible layouts.
- Test on multiple screen sizes and orientations.
- Use `env(safe-area-inset-*)` CSS variables for safe area handling (see `references/safe-area.md`).

## Performance

### Minimize Bridge Calls

Each call across the native bridge has overhead (serialization, async context switch). Batch operations when possible rather than making many individual calls.

```typescript
// BAD — many individual bridge calls
for (const key of keys) {
  await Preferences.set({ key, value: data[key] });
}

// BETTER — batch into a single operation if the plugin supports it
// Or serialize all data into one value
await Preferences.set({ key: 'all_settings', value: JSON.stringify(data) });
```

### Avoid Large Data Transfers

Do not pass large binary data (images, files) across the bridge as base64 strings. Use file paths instead (see `references/file-handling.md`).

### Lazy Load Plugins

Import plugins only where they are used. Most bundlers (Vite, Webpack) tree-shake unused imports, but dynamic imports ensure plugin code is only loaded when needed:

```typescript
async function takePhoto() {
  const { Camera } = await import('@capacitor/camera');
  return Camera.getPhoto({ ... });
}
```

## Error Handling

Always wrap plugin calls in try-catch blocks. Native operations can fail due to permission denial, hardware unavailability, or user cancellation:

```typescript
import { Camera, CameraResultType } from '@capacitor/camera';

try {
  const photo = await Camera.getPhoto({
    resultType: CameraResultType.Uri,
  });
} catch (error) {
  if (error.message === 'User cancelled photos app') {
    // User cancelled — not an error
  } else {
    // Handle actual error
    console.error('Camera error:', error);
  }
}
```

## Permissions

Follow the check-then-request pattern for all plugins that require permissions:

```typescript
import { Camera } from '@capacitor/camera';

// 1. Check current status
const status = await Camera.checkPermissions();

if (status.camera !== 'granted') {
  // 2. Request if not granted
  const requested = await Camera.requestPermissions();

  if (requested.camera === 'denied') {
    // 3. Handle permanent denial — guide user to app settings
    return;
  }
}

// 4. Proceed with the operation
const photo = await Camera.getPhoto({ ... });
```

On iOS, if a permission is denied, it cannot be re-requested programmatically. The user must enable it in device Settings > app > Permissions.

## Configuration Management

- Use `capacitor.config.ts` (TypeScript) over `capacitor.config.json` for environment-specific configuration (see `references/app-configuration.md`).
- Never commit development server URLs to version control.
- Use environment variables for build-time configuration.

## Native Project Management

- Commit `android/` and `ios/` directories to version control. They are source-of-truth native projects.
- Run `npx cap sync` after every plugin install/uninstall and after every web build.
- Keep native dependencies up to date alongside web dependencies.
- Avoid modifying files in `android/app/src/main/assets/public/` or `ios/App/App/public/` directly — these are overwritten by `npx cap copy`.


---

## Dosya: `references/deep-links.md`

# Deep Links and Universal Links

Set up deep linking to open specific content in a Capacitor app from external URLs.

## Overview

- **iOS**: Universal Links — uses HTTPS domain verification via `apple-app-site-association`.
- **Android**: App Links — uses HTTPS domain verification via `assetlinks.json`.

Both mechanisms require a two-way association: the app declares it handles URLs for a domain, and the domain hosts a file that confirms the app is authorized.

## Prerequisites

- A domain with HTTPS hosting for the site association files.
- For iOS: Enrollment in the Apple Developer Program.
- For Android: A signing keystore with a known SHA256 fingerprint.

## Step 1: Listen for Deep Link Events

Add a listener for the `appUrlOpen` event using the `@capacitor/app` plugin. This should run early in the app initialization.

```typescript
import { App } from '@capacitor/app';

App.addListener('appUrlOpen', (event) => {
  const url = new URL(event.url);
  const path = url.pathname;
  // Route to the appropriate page based on the path
  // Example: router.push(path);
});
```

Adapt the routing logic to the framework in use (Angular Router, React Router, Vue Router, etc.).

## Step 2: Create Site Association Files

### iOS — `apple-app-site-association`

Create the file (no `.json` extension) and host it at `https://<domain>/.well-known/apple-app-site-association`:

```json
{
  "applinks": {
    "details": [
      {
        "appIDs": ["<TEAM_ID>.<BUNDLE_ID>"],
        "components": [
          {
            "/": "/products/*",
            "comment": "Match all product URLs"
          },
          {
            "/": "/settings",
            "comment": "Match settings page"
          }
        ]
      }
    ]
  }
}
```

- Replace `<TEAM_ID>` with the Apple Developer Team ID (found in the Apple Developer portal under Membership).
- Replace `<BUNDLE_ID>` with the app's bundle identifier (e.g., `com.example.myapp`).
- The `components` array defines which URL paths the app should handle.

The file must be served with `Content-Type: application/json`.

### Android — `assetlinks.json`

Create the file and host it at `https://<domain>/.well-known/assetlinks.json`:

```json
[
  {
    "relation": ["delegate_permission/common.handle_all_urls"],
    "target": {
      "namespace": "android_app",
      "package_name": "<APPLICATION_ID>",
      "sha256_cert_fingerprints": ["<SHA256_FINGERPRINT>"]
    }
  }
]
```

- Replace `<APPLICATION_ID>` with the Android application ID (e.g., `com.example.myapp`).
- Replace `<SHA256_FINGERPRINT>` with the SHA256 fingerprint of the signing certificate.

To obtain the SHA256 fingerprint from a keystore:

```bash
keytool -list -v -keystore /path/to/keystore.jks -alias <alias>
```

Copy the `SHA256` value from the output and format it as colon-separated uppercase hex (e.g., `14:6D:E9:...`).

## Step 3: Configure iOS

Add an Associated Domain capability to the Xcode project:

1. Open `ios/App/App.xcodeproj` in Xcode.
2. Select the **App** target > **Signing & Capabilities** tab.
3. Click **+ Capability** > **Associated Domains**.
4. Add an entry: `applinks:<domain>` (e.g., `applinks:example.com`).

Alternatively, add the associated domain directly in `ios/App/App/App.entitlements`:

```diff
 <?xml version="1.0" encoding="UTF-8"?>
 <!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
 <plist version="1.0">
 <dict>
     <key>com.apple.developer.associated-domains</key>
     <array>
+        <string>applinks:example.com</string>
     </array>
 </dict>
 </plist>
```

## Step 4: Configure Android

Add an intent filter to `android/app/src/main/AndroidManifest.xml` inside the `<activity>` tag for the main activity:

```diff
 <activity
     android:name=".MainActivity"
     ...>
+    <intent-filter android:autoVerify="true">
+        <action android:name="android.intent.action.VIEW" />
+        <category android:name="android.intent.category.DEFAULT" />
+        <category android:name="android.intent.category.BROWSABLE" />
+        <data android:scheme="https" android:host="example.com" />
+    </intent-filter>
 </activity>
```

The `android:autoVerify="true"` attribute tells Android to verify the domain association automatically.

## Step 5: Deploy and Verify

### Host the Association Files

Deploy the site association files to the web server. They must be accessible at:

- `https://<domain>/.well-known/apple-app-site-association`
- `https://<domain>/.well-known/assetlinks.json`

For web frameworks, place the files in the correct directory:

- **Angular**: Add to `src/.well-known/` and configure `angular.json` assets array to include `.well-known`.
- **React (CRA / Vite)**: Place in `public/.well-known/`.
- **Vue**: Place in `public/.well-known/`.

### Test

1. Build and deploy the native app to a physical device.
2. Open a link to `https://<domain>/products/123` in the device browser or tap a link from an external app (e.g., Notes, Messages).
3. If configured correctly, the app opens and the `appUrlOpen` listener fires.

### Debugging

- **iOS**: Use Apple's [Search API Validation Tool](https://search.developer.apple.com/appsearch-validation-tool/) to verify the association file.
- **Android**: Use the Digital Asset Links tool at `https://developers.google.com/digital-asset-links/tools/generator` to verify the association file.
- **iOS not opening the app**: Ensure the app was installed from TestFlight or the App Store (development builds may not verify domains). Long-press a link and check if "Open in App" appears.
- **Android not opening the app**: Verify `android:autoVerify="true"` is set. Check that the SHA256 fingerprint matches the signing key used for the installed build.


---

## Dosya: `references/edge-to-edge.md`

# Android Edge-to-Edge Support

Configure Android apps to draw content behind the status bar and navigation bar for immersive, full-screen layouts.

## Overview

Edge-to-edge means the app content extends behind the system bars (status bar and navigation bar). The app is responsible for handling insets to prevent content from being obscured.

Starting with **Android 15 (API 35)**, edge-to-edge is enforced by the system. Apps targeting API 35+ are edge-to-edge by default.

## Capacitor 8+: Built-in Support

Capacitor 8 includes a built-in `SystemBars` plugin that handles edge-to-edge automatically. It manages status and navigation bar appearance and applies insets to the WebView.

The `SystemBars` plugin provides a public API for granular control:

```typescript
import { SystemBars } from '@capacitor/core';

// Set status bar style
await SystemBars.setStyle({ statusBar: 'DARK', navigationBar: 'LIGHT' });

// Hide system bars
await SystemBars.setVisible({ statusBar: false, navigationBar: false });
```

For apps using the `@capacitor/status-bar` plugin (Capacitor 7 and earlier), the two can be used together. Capacitor automatically applies the correct behavior based on the device's Android version.

### Disabling Built-in Inset Handling

If using a third-party edge-to-edge plugin (e.g., `@capawesome/capacitor-android-edge-to-edge-support` or `@capacitor-community/safe-area`), disable the built-in insets handling in `capacitor.config.ts`:

```typescript
const config: CapacitorConfig = {
  plugins: {
    SystemBars: {
      insetsHandling: 'disable',
    },
  },
};
```

## Capacitor 7 and Earlier: Plugin Options

For Capacitor 7 and earlier, use one of these plugins:

### Option A: `@capawesome/capacitor-android-edge-to-edge-support`

This plugin enables edge-to-edge mode on Android while preserving traditional inset handling by applying proper insets to the WebView.

```bash
npm install @capawesome/capacitor-android-edge-to-edge-support
npx cap sync
```

Configuration in `capacitor.config.ts`:

```typescript
const config: CapacitorConfig = {
  plugins: {
    EdgeToEdge: {
      backgroundColor: '#ffffff',
      statusBarColor: '#ffffff',
      navigationBarColor: '#ffffff',
    },
  },
};
```

API:

```typescript
import { EdgeToEdge } from '@capawesome/capacitor-android-edge-to-edge-support';

await EdgeToEdge.enable();
await EdgeToEdge.disable();
const insets = await EdgeToEdge.getInsets();
// insets = { top: 24, bottom: 48, left: 0, right: 0 }
```

For full plugin setup, use the `capacitor-plugins` skill.

### Option B: `@capacitor-community/safe-area`

This plugin handles both edge-to-edge and safe area insets. See `references/safe-area.md` for details.

## CSS Inset Handling

When edge-to-edge is enabled, use CSS environment variables to prevent content from being obscured by system bars:

```css
.content {
  padding-top: env(safe-area-inset-top);
  padding-bottom: env(safe-area-inset-bottom);
  padding-left: env(safe-area-inset-left);
  padding-right: env(safe-area-inset-right);
}
```

For the `viewport-fit=cover` meta tag to work correctly, add it to `index.html`:

```html
<meta name="viewport" content="viewport-fit=cover, width=device-width, initial-scale=1.0">
```

**Note on Android WebView bug**: Chromium WebView versions below 140 have a bug where `env(safe-area-inset-*)` values may report incorrect values. The `@capacitor-community/safe-area` plugin includes a workaround for this issue.


---

## Dosya: `references/file-handling.md`

# File Handling Best Practices

Handle files efficiently in Capacitor apps without causing memory issues.

## The Core Problem

Loading files into the WebView as base64 strings or data URLs consumes excessive memory and can cause out-of-memory crashes, especially with large files (images, videos, PDFs). The WebView's JavaScript heap has limited memory.

## Best Practices

### Reading Files

**Do not** use the Filesystem plugin's `readFile()` to load large files as base64:

```typescript
// BAD — loads entire file into WebView memory as base64
const result = await Filesystem.readFile({ path: 'photo.jpg', directory: Directory.Data });
const base64 = result.data; // Large string in JS heap
```

**Instead**, use `Capacitor.convertFileSrc()` with the Fetch API to load files as blobs:

```typescript
import { Capacitor } from '@capacitor/core';
import { Filesystem, Directory } from '@capacitor/filesystem';

// Get the native file URI
const file = await Filesystem.getUri({ path: 'photo.jpg', directory: Directory.Data });

// Convert to a web-accessible URL
const webUrl = Capacitor.convertFileSrc(file.uri);

// Load as a blob (memory-efficient — uses disk backing automatically)
const response = await fetch(webUrl);
const blob = await response.blob();
```

### Displaying Files

Convert native file paths to web-accessible URLs using `Capacitor.convertFileSrc()`, then use as `src` attributes:

```typescript
import { Capacitor } from '@capacitor/core';

const webUrl = Capacitor.convertFileSrc(nativeFilePath);

// Set as image source
const img = document.querySelector('img');
img.src = webUrl;

// Or in a framework template
// Angular: <img [src]="webUrl">
// React: <img src={webUrl} />
// Vue: <img :src="webUrl">
```

This avoids loading the file content into JavaScript memory entirely.

### Downloading Files

Use the Filesystem plugin's `downloadFile()` to write directly to device storage:

```typescript
import { Filesystem, Directory } from '@capacitor/filesystem';

await Filesystem.downloadFile({
  url: 'https://example.com/large-file.pdf',
  path: 'downloads/file.pdf',
  directory: Directory.Data,
});
```

This bypasses the WebView completely — the native layer handles the download.

### Uploading Files

Use the Fetch API with `FormData` after reading the file as a blob:

```typescript
import { Capacitor } from '@capacitor/core';
import { Filesystem, Directory } from '@capacitor/filesystem';

const file = await Filesystem.getUri({ path: 'photo.jpg', directory: Directory.Data });
const webUrl = Capacitor.convertFileSrc(file.uri);

const response = await fetch(webUrl);
const blob = await response.blob();

const formData = new FormData();
formData.append('file', blob, 'photo.jpg');

await fetch('https://api.example.com/upload', {
  method: 'POST',
  body: formData,
});
```

### Opening Files

Use a file opener plugin to open files in external apps (e.g., PDF viewer, image gallery):

- `@capawesome-team/capacitor-file-opener` (recommended)
- `@capacitor-community/file-opener`

For plugin installation and configuration, use the `capacitor-plugins` skill.

### Picking Files

Use a file picker plugin to let the user select files without loading them into the WebView:

- `@capawesome/capacitor-file-picker` (recommended)

The picker returns file paths or URIs. Convert them with `Capacitor.convertFileSrc()` for display, or read them as blobs for upload.

For plugin installation and configuration, use the `capacitor-plugins` skill.

## Filesystem Directories

The `@capacitor/filesystem` plugin provides these directory constants:

| Directory | Description | Persists Across Updates |
| --------- | ----------- | ----------------------- |
| `Directory.Data` | App-specific data directory | Yes |
| `Directory.Documents` | User documents (iOS: backed up to iCloud) | Yes |
| `Directory.Library` | App library directory (iOS only) | Yes |
| `Directory.Cache` | Temporary cache (OS may clear) | No |
| `Directory.External` | External storage (Android only) | Yes |
| `Directory.ExternalStorage` | Shared external storage (Android only, requires permissions) | Yes |

## Summary

| Operation | Approach |
| --------- | -------- |
| Read large files | `convertFileSrc()` + `fetch()` as blob |
| Display images/videos | `convertFileSrc()` as `src` attribute |
| Download files | `Filesystem.downloadFile()` |
| Upload files | `convertFileSrc()` + `fetch()` blob + `FormData` |
| Open in external app | File opener plugin |
| Pick files | File picker plugin |


---

## Dosya: `references/ios-package-managers.md`

# iOS Package Managers

Capacitor supports two dependency managers for iOS: Swift Package Manager (SPM) and CocoaPods.

## Swift Package Manager (SPM)

SPM is the default for new Capacitor 8+ projects. It is Apple's official package manager, integrated directly into Xcode.

### How to Detect SPM

- The `ios/App/Podfile` does **not** exist.
- Dependencies are managed in the Xcode project file (`ios/App/App.xcodeproj/project.pbxproj`).
- The `ios/App/App.xcworkspace` may still exist but is not required for SPM-based builds.

### Adding Dependencies with SPM

Capacitor plugins that support SPM are added automatically when running `npx cap sync`. The Capacitor CLI modifies the Xcode project to include SPM package references.

To manually add an SPM package:

1. Open `ios/App/App.xcodeproj` in Xcode.
2. Select the project in the navigator > **Package Dependencies** tab.
3. Click **+** to add a package.
4. Enter the package URL and select a version rule.

### Advantages

- No additional tooling required (built into Xcode).
- Faster dependency resolution than CocoaPods.
- No `Podfile` or `Podfile.lock` to maintain.
- No `pod install` step required.

### Limitations

- Not all Capacitor plugins support SPM yet. Check the plugin's documentation.
- Some third-party native SDKs only distribute via CocoaPods.

## CocoaPods

CocoaPods is the legacy dependency manager. It is the default for Capacitor 7 and earlier projects.

### How to Detect CocoaPods

- The `ios/App/Podfile` exists.
- The `ios/App/Podfile.lock` exists.
- The `ios/App/Pods/` directory exists (after installation).

### Installation

CocoaPods requires Ruby. Install via:

```bash
sudo gem install cocoapods
```

Or via Homebrew:

```bash
brew install cocoapods
```

### Adding Dependencies with CocoaPods

Dependencies are declared in `ios/App/Podfile`. Capacitor plugins are added automatically when running `npx cap sync`.

After any change to `Podfile`:

```bash
cd ios/App && pod install
```

Always open the `.xcworkspace` file (not `.xcodeproj`) when using CocoaPods:

```bash
npx cap open ios
# This opens the .xcworkspace automatically
```

### Common Issues

- **`pod install` fails with version conflicts**: Run `pod repo update` to refresh the local spec repository, then retry.
- **`pod install` hangs**: The CDN source may be slow. Add `source 'https://cdn.cocoapods.org/'` at the top of the `Podfile`.
- **Missing pods after `npx cap sync`**: Run `cd ios/App && pod install` manually.

## Migrating from CocoaPods to SPM

Capacitor 8 supports migrating existing projects from CocoaPods to SPM. This is done during the Capacitor 8 upgrade. For upgrade procedures, use the `capacitor-app-upgrades` skill.

Requirements for migration:
- All Capacitor plugins used in the project must support SPM.
- Third-party native SDKs must be available via SPM.

If any dependency does not support SPM, continue using CocoaPods. Capacitor 8 fully supports both.

## Checking Plugin SPM Support

To verify whether a plugin supports SPM, check for a `Package.swift` file in the plugin's iOS source directory. Plugins distributed via the `@capacitor/*`, `@capawesome/*`, and `@capacitor-firebase/*` namespaces generally support SPM for their latest major versions.

For adding SPM support to custom Capacitor plugins, use the `capacitor-plugin-spm-support` skill.


---

## Dosya: `references/live-reload.md`

# Live Reload

Set up live reload to instantly see web code changes on a native device or emulator without rebuilding the native binary.

## Overview

Live reload connects the native app's WebView to a development server running on the developer's machine instead of loading bundled web assets from the device filesystem. When web code changes, the dev server triggers a reload in the WebView.

## Prerequisites

- The development machine and the target device must be on the **same Wi-Fi network** (for physical devices).
- The development server must bind to `0.0.0.0` to accept connections from the device.

## Option A: `npx cap run --live-reload` (Recommended)

The simplest approach. The Capacitor CLI handles configuration automatically:

```bash
npx cap run android --live-reload --port 8100
npx cap run ios --live-reload --port 8100
```

Options:
- `--port <port>` — Dev server port (default: framework default).
- `--host <host>` — Dev server host.
- `--https` — Use HTTPS instead of HTTP.
- `--forwardPorts <port1:port2>` — Run `adb reverse` for Android (useful when USB debugging).

This command starts the dev server, configures the native project to point to it, builds, and deploys to the device.

## Option B: Ionic CLI

If using the Ionic CLI:

```bash
ionic cap run android -l --external
ionic cap run ios -l --external
```

The `--external` flag binds the dev server to `0.0.0.0`.

## Option C: Manual Configuration

For cases where the CLI options do not work, configure live reload manually.

### Step 1: Find the Development Machine's LAN IP Address

**macOS**:

```bash
ifconfig en0 | grep 'inet '
```

**Windows**:

```bash
ipconfig
```

Look for the `IPv4 Address` on the active network adapter.

### Step 2: Start the Dev Server

Start the framework's dev server bound to `0.0.0.0`:

```bash
# Vite
npx vite --host 0.0.0.0

# Angular
ng serve --host 0.0.0.0

# React (Create React App)
HOST=0.0.0.0 npm run start

# Vue CLI
npx vue-cli-service serve --host 0.0.0.0
```

### Step 3: Update Capacitor Config

Add the server URL to `capacitor.config.ts`:

```typescript
const config: CapacitorConfig = {
  server: {
    url: 'http://<LAN_IP>:<PORT>',
    cleartext: true,
  },
};
```

Replace `<LAN_IP>` with the IP from Step 1 and `<PORT>` with the dev server port.

### Step 4: Copy and Run

```bash
npx cap copy
npx cap run android
# or
npx cap run ios
```

### Step 5: Clean Up

**Remove the `server` block from `capacitor.config.ts` before building a production release.** Do not commit the server URL to version control.

## Troubleshooting

- **Device cannot reach the dev server**: Verify both are on the same network. Check if a firewall is blocking the port. Try pinging the dev machine from the device.
- **Android emulator cannot connect**: The emulator has its own network. Use `10.0.2.2` to reach the host machine from the emulator, or use `--forwardPorts` with `npx cap run`.
- **iOS simulator works but physical device does not**: The simulator shares the host network. Physical devices need the LAN IP. Verify the device is on the same Wi-Fi.
- **Changes not reflecting**: Verify the dev server is running and the URL in `capacitor.config.ts` is correct. Check the WebView's network requests in the browser developer tools.


---

## Dosya: `references/platforms.md`

# Capacitor Platforms

Capacitor supports multiple target platforms. Each platform has its own native project and build tooling.

## Android

- **Native project**: `android/` directory, opened with Android Studio.
- **Language**: Kotlin (default for Capacitor 7+) or Java.
- **Build system**: Gradle.
- **WebView**: Android System WebView (Chromium-based), updated via Google Play.
- **Minimum SDK**: Varies by Capacitor version (API 23 for Cap 7, API 24 for Cap 8).

Add the Android platform:

```bash
npx cap add android
```

Build and run:

```bash
npx cap run android
```

Or open in Android Studio:

```bash
npx cap open android
```

## iOS

- **Native project**: `ios/` directory, opened with Xcode.
- **Language**: Swift.
- **Build system**: Xcode Build System.
- **Dependency manager**: Swift Package Manager (default for Capacitor 8+) or CocoaPods.
- **WebView**: WKWebView.
- **Minimum deployment target**: Varies by Capacitor version (iOS 14 for Cap 7, iOS 16 for Cap 8).

Add the iOS platform:

```bash
npx cap add ios
```

Build and run:

```bash
npx cap run ios
```

Or open in Xcode:

```bash
npx cap open ios
```

## Progressive Web App (PWA)

Capacitor apps can run as PWAs in the browser without any native wrapper. The web app is served directly and uses standard Web APIs.

- No native project directory is created.
- Plugins with web implementations work automatically. Plugins without web implementations throw "not implemented" errors at runtime.
- Use `@capacitor/pwa-elements` for UI fallbacks (e.g., camera, toast) on the web:

```bash
npm install @capacitor/pwa-elements
```

Then register the elements in the app's entry file:

```typescript
import { defineCustomElements } from '@capacitor/pwa-elements/loader';
defineCustomElements(window);
```

To build for PWA, configure a service worker and web manifest using the framework's PWA tooling (e.g., `@angular/pwa`, `vite-plugin-pwa`, `next-pwa`).

## Desktop (Electron & Tauri)

Capacitor apps can target desktop platforms (macOS, Windows, Linux) via the Capawesome platforms [`@capawesome/capacitor-electron`](https://github.com/capawesome-team/capacitor-electron) and [`@capawesome/capacitor-tauri`](https://github.com/capawesome-team/capacitor-tauri).

- **Electron**: maximum plugin compatibility (Node-based plugin implementations plus automatic web fallback) and web-bundle update support, with larger binaries (bundled Chromium). Supports Capacitor 6+. Native project: `electron/`.
- **Tauri**: tiny system-webview binaries and a deny-by-default Rust core, with a scoped plugin story (built-in `@capacitor/app`, curated shims, web fallback). Requires the Rust toolchain. Native project: `src-tauri/`.

Add a desktop platform:

```bash
npm install @capawesome/capacitor-electron
npx cap add @capawesome/capacitor-electron
# or
npm install @capawesome/capacitor-tauri
npx cap add @capawesome/capacitor-tauri
```

Always use the full package name with Capacitor CLI commands (a bare `npx cap sync electron` silently does nothing). Native plugins from iOS/Android are **not** available on desktop — evaluate plugin availability before committing to a desktop target. For platform selection, setup, packaging, and plugin compatibility details, use the `capacitor-platforms` skill.

## Platform Detection at Runtime

Use `Capacitor.getPlatform()` to detect the current platform at runtime:

```typescript
import { Capacitor } from '@capacitor/core';

const platform = Capacitor.getPlatform();
// Returns 'android', 'ios', or 'web'

if (Capacitor.isNativePlatform()) {
  // Running on Android or iOS
}
```

Use platform detection to conditionally execute platform-specific code or to provide fallback behavior on the web.


---

## Dosya: `references/safe-area.md`

# Android Safe Area Handling

Handle safe area insets on Android to prevent content from being obscured by system bars, notches, and rounded corners.

## Overview

On iOS and modern web browsers, `env(safe-area-inset-*)` CSS variables work correctly out of the box. On Android, the WebView's Chromium engine may report incorrect inset values (especially in versions below 140). This reference covers Android-specific solutions.

## Prerequisites

Add `viewport-fit=cover` to the viewport meta tag in `index.html`:

```html
<meta name="viewport" content="viewport-fit=cover, width=device-width, initial-scale=1.0">
```

## Option A: `@capacitor-community/safe-area` Plugin

This plugin detects the Chromium WebView version and applies a workaround automatically for versions with the inset bug.

### Installation

For Capacitor 8:

```bash
npm install @capacitor-community/safe-area
npx cap sync
```

For Capacitor 7:

```bash
npm install @capacitor-community/safe-area@^7.0.0
npx cap sync
```

### Android Configuration

Enable edge-to-edge in `android/app/src/main/java/.../MainActivity.java` (or `.kt`):

```diff
+ import androidx.activity.EdgeToEdge;

  public class MainActivity extends BridgeActivity {
+     @Override
+     protected void onCreate(Bundle savedInstanceState) {
+         EdgeToEdge.enable(this);
+         super.onCreate(savedInstanceState);
+     }
  }
```

Disable Capacitor's built-in insets handling in `capacitor.config.ts`:

```typescript
const config: CapacitorConfig = {
  plugins: {
    SystemBars: {
      insetsHandling: 'disable',
    },
  },
};
```

### Plugin Configuration

```typescript
const config: CapacitorConfig = {
  plugins: {
    SafeArea: {
      detectViewportFitCoverChanges: true,
      initialViewportFitCover: true,
    },
  },
};
```

### Conflicts

When using `@capacitor-community/safe-area`:
- Remove `@capacitor/status-bar` if installed — the safe-area plugin manages system bar styling.
- Set `resizeOnFullScreen: false` for `@capacitor/keyboard` to avoid WebView resizing conflicts.
- Do not install `@capawesome/capacitor-android-edge-to-edge-support` alongside this plugin.

### API

```typescript
import { SafeArea } from '@capacitor-community/safe-area';

// Get current insets
const insets = await SafeArea.getInsets();
// { top: 24, bottom: 48, left: 0, right: 0 }

// Style system bars
await SafeArea.setSystemBarsStyle({ style: 'DARK' });

// Hide/show system bars
await SafeArea.hideSystemBars({ bars: 'BOTH' });
await SafeArea.showSystemBars({ bars: 'BOTH' });
```

For full plugin setup, use the `capacitor-plugins` skill.

## Option B: `@capawesome/capacitor-android-edge-to-edge-support`

See `references/edge-to-edge.md` for details on this plugin, which takes a different approach by applying insets to the WebView itself rather than exposing them via CSS.

## CSS Usage

After installing a safe area plugin, use standard CSS environment variables:

```css
:root {
  --safe-area-top: env(safe-area-inset-top);
  --safe-area-bottom: env(safe-area-inset-bottom);
  --safe-area-left: env(safe-area-inset-left);
  --safe-area-right: env(safe-area-inset-right);
}

header {
  padding-top: var(--safe-area-top);
}

footer {
  padding-bottom: var(--safe-area-bottom);
}

.tab-bar {
  padding-bottom: var(--safe-area-bottom);
}
```


---

## Dosya: `references/security.md`

# Security Best Practices

Security guidelines for Capacitor app development.

## Never Embed Secrets in App Code

Client-side code (JavaScript, HTML, CSS) bundled in the app can be extracted through basic analysis. Never embed:

- API keys with write or admin access
- Encryption keys
- Database credentials
- OAuth client secrets
- Service account keys

**Instead**: Move operations requiring secret keys to a server-side API or serverless function. The app should call the server API, and the server handles the secret.

Read-only API keys (e.g., Google Maps API key restricted by platform) are acceptable in client code but should still be restricted by platform and usage quotas.

## Secure Storage for Sensitive Client Data

Do not store authentication tokens, encryption keys, or credentials in `localStorage`, `IndexedDB`, or `@capacitor/preferences`. These are not encrypted.

**Use native secure storage**:

- **iOS**: Keychain Services (encrypted, hardware-backed).
- **Android**: Android Keystore (hardware-backed key management).

Plugins that wrap these APIs:

- `@capawesome-team/capacitor-secure-preferences` — Encrypted key-value storage.

For plugin installation and configuration, use the `capacitor-plugins` skill.

## HTTPS Only

Never make requests to unencrypted HTTP endpoints. All network requests should use `https://`.

In `capacitor.config.ts`, do not set `server.cleartext: true` in production builds. This setting allows HTTP traffic and should only be used during development (e.g., live reload).

## Content Security Policy (CSP)

Add a Content Security Policy meta tag to `index.html` to restrict which resources the WebView can load:

```html
<meta http-equiv="Content-Security-Policy"
      content="default-src 'self';
               script-src 'self';
               style-src 'self' 'unsafe-inline';
               img-src 'self' data: https:;
               connect-src 'self' https://api.example.com;">
```

Adjust the policy based on the app's requirements:

- `default-src 'self'` — Only allow resources from the app's origin by default.
- `script-src 'self'` — Only allow scripts from the app's origin.
- `connect-src` — Whitelist API endpoints the app communicates with.
- `img-src` — Allow image sources as needed.

## Deep Link Security

- Prefer **Universal Links** (iOS) and **App Links** (Android) over custom URL schemes. Universal Links and App Links are verified via HTTPS domain ownership and cannot be hijacked by other apps.
- Never send sensitive data (tokens, credentials) through URL scheme parameters.
- For OAuth2 flows, use **PKCE (Proof Key for Code Exchange)** to prevent token interception during the callback.

See `references/deep-links.md` for deep link setup.

## WebView Debugging

Disable WebView debugging in production builds:

```typescript
const config: CapacitorConfig = {
  android: {
    webContentsDebuggingEnabled: false,
  },
  ios: {
    webContentsDebuggingEnabled: false,
  },
};
```

When `webContentsDebuggingEnabled` is `true`, anyone with physical access to the device can inspect the WebView's content, network requests, and local storage using Chrome DevTools (Android) or Safari Web Inspector (iOS).

## Code Obfuscation

The web layer is inherently inspectable. To make reverse engineering harder:

- Minify and bundle JavaScript for production (standard build tooling handles this).
- Avoid including proprietary algorithms or business logic in the client code. Move sensitive logic to the server.
- Consider using JavaScript obfuscation tools for additional protection, though obfuscation is not a substitute for proper server-side security.

## Network Certificate Pinning

For apps that communicate with a specific API backend, consider certificate pinning to prevent man-in-the-middle attacks. Certificate pinning ensures the app only trusts a specific server certificate rather than any certificate signed by a trusted CA.

This requires native implementation on each platform and must be updated when server certificates rotate.

## Privacy Manifest (iOS)

Starting with iOS 17, Apple requires apps to declare the reasons for using specific APIs in a Privacy Manifest (`PrivacyInfo.xcprivacy`). This file is located at `ios/App/App/PrivacyInfo.xcprivacy`.

Capacitor plugins that access privacy-sensitive APIs should include their own privacy manifests. When adding plugins, verify they provide the required privacy declarations.


---

## Dosya: `references/splash-screens-and-icons.md`

# Splash Screens and App Icons

Generate and configure splash screens and app icons for Capacitor apps using `@capacitor/assets`.

## Installation

```bash
npm install @capacitor/assets --save-dev
```

## Source Asset Requirements

Create an `assets/` directory in the project root with the following files:

| File | Minimum Size | Purpose |
| ---- | ------------ | ------- |
| `icon-only.png` | 1024x1024 px | App icon without background (used for iOS) |
| `icon-foreground.png` | 1024x1024 px | Adaptive icon foreground layer (Android) |
| `icon-background.png` | 1024x1024 px | Adaptive icon background layer (Android) |
| `splash.png` | 2732x2732 px | Light mode splash screen |
| `splash-dark.png` | 2732x2732 px | Dark mode splash screen |

All files must be PNG or JPG format.

## Generate Assets

Run the generation command to create platform-specific assets:

```bash
npx capacitor-assets generate
```

This generates all required icon sizes and splash screen variants for each platform.

To generate for a specific platform only:

```bash
npx capacitor-assets generate --ios
npx capacitor-assets generate --android
npx capacitor-assets generate --pwa
```

## Android-Specific Notes

### Android 12+ Splash Screen

Android 12 and newer versions use a redesigned splash screen system that displays a smaller icon with a colored background, rather than a full-screen image. The splash screen is managed by the Android system and cannot be fully customized.

The `@capacitor/assets` tool automatically generates the correct adaptive icon and splash screen resources for Android 12+.

### Adaptive Icons

Android 8.0+ uses adaptive icons with separate foreground and background layers. The `icon-foreground.png` and `icon-background.png` files are used to generate these. Keep the main icon content within the center 66% of the `icon-foreground.png` to ensure it is not clipped by different device masks.

## iOS-Specific Notes

iOS uses a single icon at 1024x1024 and scales it for all required sizes. The `icon-only.png` is used as the source.

iOS splash screens use a Storyboard (`LaunchScreen.storyboard`) rather than static images. The `@capacitor/assets` tool updates this file automatically.

## Splash Screen Plugin

To control splash screen behavior at runtime (show duration, auto-hide, animations), use the `@capacitor/splash-screen` plugin. Configure it in `capacitor.config.ts`:

```typescript
const config: CapacitorConfig = {
  plugins: {
    SplashScreen: {
      launchShowDuration: 2000,
      launchAutoHide: true,
      launchFadeOutDuration: 500,
      backgroundColor: '#ffffff',
      showSpinner: false,
    },
  },
};
```

To manually control the splash screen:

```typescript
import { SplashScreen } from '@capacitor/splash-screen';

// Hide the splash screen
await SplashScreen.hide();

// Show the splash screen
await SplashScreen.show({ autoHide: false });
```

For full plugin API, use the `capacitor-plugins` skill.


---

## Dosya: `references/storage.md`

# Storage Solutions

Choose the right storage solution for a Capacitor app based on data size, complexity, and security requirements.

## Storage Options

### 1. Capacitor Preferences API (Small Key-Value Data)

**Best for**: User settings, feature flags, small tokens, simple app state.

The `@capacitor/preferences` plugin provides a native key-value store that persists across app restarts and is not subject to OS eviction (unlike `localStorage`).

```bash
npm install @capacitor/preferences
npx cap sync
```

```typescript
import { Preferences } from '@capacitor/preferences';

// Store
await Preferences.set({ key: 'user_id', value: '12345' });

// Retrieve
const { value } = await Preferences.get({ key: 'user_id' });

// Remove
await Preferences.remove({ key: 'user_id' });

// Clear all
await Preferences.clear();
```

**Limitations**: Values must be strings. Not suitable for large datasets or complex queries.

For full plugin setup, use the `capacitor-plugins` skill.

### 2. SQLite (Large Data, Complex Queries)

**Best for**: Relational data, offline-first apps, large datasets, apps requiring complex queries.

Options:
- `@capawesome-team/capacitor-sqlite` — Capawesome SQLite plugin.
- `@capacitor-community/sqlite` — Community-maintained SQLite plugin.

Both provide full SQLite database access on Android and iOS.

For plugin installation and configuration, use the `capacitor-plugins` skill.

### 3. Secure Storage (Sensitive Data)

**Best for**: Authentication tokens, encryption keys, credentials, biometric-protected data.

Options:
- `@capawesome-team/capacitor-secure-preferences` — Encrypted key-value storage using platform Keychain (iOS) and Keystore (Android).

For plugin installation and configuration, use the `capacitor-plugins` skill.

### 4. Filesystem (Files, Binary Data)

**Best for**: Documents, images, downloads, cached files.

The `@capacitor/filesystem` plugin provides file read/write access.

For plugin installation and configuration, use the `capacitor-plugins` skill. See also `references/file-handling.md` for file handling best practices.

## What NOT to Use

### `localStorage`

- **Problem**: The OS can evict `localStorage` data when device storage runs low. This is especially aggressive on iOS.
- **Use instead**: `@capacitor/preferences` for the same key-value pattern with native persistence.

### `IndexedDB`

- **Problem**: Also subject to OS eviction, particularly on iOS. Data may be lost unexpectedly.
- **Use instead**: SQLite for structured data that must persist reliably.

### Cookies

- **Problem**: Cookies in a WebView have limited storage, expiration constraints, and inconsistent behavior across platforms.
- **Use instead**: `@capacitor/preferences` or a secure storage plugin.

## Decision Guide

| Requirement | Recommended Solution |
| ----------- | -------------------- |
| App settings, user preferences | `@capacitor/preferences` |
| Authentication tokens, sensitive keys | `@capawesome-team/capacitor-secure-preferences` |
| Relational data, offline-first | SQLite (`@capawesome-team/capacitor-sqlite` or `@capacitor-community/sqlite`) |
| Files, images, documents | `@capacitor/filesystem` |
| Large binary blobs | `@capacitor/filesystem` (write to disk, reference by path) |


---

## Dosya: `references/testing.md`

# Testing Capacitor Apps

Strategies and tools for unit testing and end-to-end (E2E) testing Capacitor apps.

## Unit Testing

Unit tests for Capacitor apps test the web layer (JavaScript/TypeScript). The native bridge is mocked since unit tests run in Node.js, not in a WebView.

### Mocking Capacitor Plugins

Capacitor plugins can be mocked in unit tests using the testing framework's mocking capabilities.

**Jest example** (React, Vue, Angular):

```typescript
// __mocks__/@capacitor/camera.ts
export const Camera = {
  getPhoto: jest.fn().mockResolvedValue({
    webPath: 'https://example.com/photo.jpg',
    format: 'jpeg',
  }),
  checkPermissions: jest.fn().mockResolvedValue({ camera: 'granted', photos: 'granted' }),
  requestPermissions: jest.fn().mockResolvedValue({ camera: 'granted', photos: 'granted' }),
};
```

Place mocks in a `__mocks__/@capacitor/` directory at the project root (or configure via `moduleNameMapper` in Jest config).

**Vitest example**:

```typescript
import { vi } from 'vitest';

vi.mock('@capacitor/camera', () => ({
  Camera: {
    getPhoto: vi.fn().mockResolvedValue({
      webPath: 'https://example.com/photo.jpg',
      format: 'jpeg',
    }),
  },
}));
```

### Testing Platform-Specific Code

Mock `Capacitor.getPlatform()` and `Capacitor.isNativePlatform()` for platform-conditional logic:

```typescript
vi.mock('@capacitor/core', () => ({
  Capacitor: {
    getPlatform: vi.fn().mockReturnValue('android'),
    isNativePlatform: vi.fn().mockReturnValue(true),
    convertFileSrc: vi.fn((src) => src),
  },
}));
```

### Framework-Specific Test Runners

- **Angular**: `ng test` (Karma/Jasmine) or Jest via `@angular-builders/jest`.
- **React**: `vitest` or `jest` (included with Create React App).
- **Vue**: `vitest` (recommended by Vue CLI and Vite).

## End-to-End (E2E) Testing

E2E tests run the app in a real browser or on a device/emulator and simulate user interactions.

### Web E2E (Cypress, Playwright)

Test the web layer in a browser. Capacitor plugins must be mocked or stubbed since they are not available in a standard browser.

**Cypress** setup:

```bash
npm install cypress --save-dev
npx cypress open
```

**Playwright** setup:

```bash
npm install @playwright/test --save-dev
npx playwright install
npx playwright test
```

These tools test the web app as a PWA. They cannot test native functionality (camera, filesystem, push notifications, etc.).

### Native E2E (Appium, Detox)

For testing native functionality on real devices or emulators:

**Appium**:
- Cross-platform (Android + iOS).
- Tests interact with the native app via the WebDriver protocol.
- Install: `npm install appium --save-dev`

**Detox** (iOS-focused, some Android support):
- Developed by Wix for React Native, but works with any native app.
- Faster than Appium for iOS testing.

### Manual Testing on Devices

For native features, manual testing on physical devices is often the most reliable approach:

```bash
# Build and deploy to a connected device
npx cap run android --target <device-id>
npx cap run ios --target <device-id>

# List available devices
npx cap run android --list
npx cap run ios --list
```

Use `npx cap run --live-reload` to iterate quickly (see `references/live-reload.md`).

## Debugging

### Android WebView Debugging

1. Enable WebView debugging in `capacitor.config.ts`:
   ```typescript
   android: {
     webContentsDebuggingEnabled: true,
   }
   ```
2. Run the app on a device or emulator.
3. Open `chrome://inspect` in Chrome on the development machine.
4. The WebView appears under **Remote Target**. Click **inspect** to open DevTools.

### iOS WebView Debugging

1. Enable WebView debugging in `capacitor.config.ts`:
   ```typescript
   ios: {
     webContentsDebuggingEnabled: true,
   }
   ```
2. Run the app on a simulator or device.
3. Open Safari on macOS > **Develop** menu > select the device > select the WebView.
4. Safari Web Inspector opens with full debugging capabilities.

### Native Logging

- **Android**: View native logs with `adb logcat` or in Android Studio's Logcat panel. Filter by `Capacitor` tag.
- **iOS**: View native logs in Xcode's Console panel. Filter by `Capacitor`.


---

## Dosya: `references/troubleshooting-android.md`

# Android Troubleshooting

Common Android issues and their solutions.

## Build Issues

### Gradle Sync Failed

**Symptom**: Android Studio shows "Gradle sync failed" or `npx cap sync android` fails.

**Solutions**:
1. Ensure the correct JDK is installed and configured:
   - Capacitor 7: JDK 17.
   - Capacitor 8: JDK 21.
   Check: `java -version`. In Android Studio: File > Settings > Build, Execution, Deployment > Build Tools > Gradle > Gradle JDK.
2. Invalidate caches: File > Invalidate Caches in Android Studio.
3. Delete `.gradle` cache: `rm -rf ~/.gradle/caches && rm -rf android/.gradle`.
4. Check that `android/variables.gradle` has the correct SDK and tool versions.

### `compileSdkVersion` or `targetSdkVersion` Errors

**Symptom**: Build fails with messages about SDK version incompatibility.

**Solution**: Update `android/variables.gradle`:

```groovy
ext {
    minSdkVersion = 23          // Capacitor 7; 24 for Capacitor 8
    compileSdkVersion = 35
    targetSdkVersion = 35
    androidxActivityVersion = '1.9.0'
    androidxAppCompatVersion = '1.7.0'
    androidxCoordinatorLayoutVersion = '1.2.0'
    androidxCoreVersion = '1.15.0'
    androidxFragmentVersion = '1.8.1'
    junitVersion = '4.13.2'
    androidxJunitVersion = '1.2.1'
    androidxEspressoCoreVersion = '3.6.1'
    coreSplashScreenVersion = '1.0.1'
}
```

Exact values depend on the Capacitor version. Check the upgrade guide for the target version.

### Gradle Version Incompatibility Error

**Symptom**: `Minimum supported Gradle version is X.X. Current version is Y.Y.`

This occurs when the Android Gradle Plugin (AGP) version is incompatible with the installed Gradle version.

**Solution**: Update AGP in `android/build.gradle` to match the Capacitor version:

```groovy
// Capacitor 6
classpath 'com.android.tools.build:gradle:8.2.1'

// Capacitor 7/8
classpath 'com.android.tools.build:gradle:8.7.3'
```

And update the Gradle wrapper in `android/gradle/wrapper/gradle-wrapper.properties`:

```properties
distributionUrl=https\://services.gradle.org/distributions/gradle-8.11.1-all.zip
```

Use Android Studio's **Tools > AGP Upgrade Assistant** for automated AGP upgrades.

### Gradle Property Syntax Warnings (Capacitor 8+)

**Symptom**: Warnings like "Setting a Gradle property without `=` is deprecated."

**Solution**: Search all `.gradle` files in `android/` for property assignments without `=` and add the `=` sign:

```diff
- ext.androidxCoreVersion '1.15.0'
+ ext.androidxCoreVersion = '1.15.0'
```

### `JAVA_HOME` Not Set

**Symptom**: Build fails with `JAVA_HOME is not set` or `could not find tools.jar`.

**Solution**: Set `JAVA_HOME` to the JDK installation path:

```bash
# macOS (Zulu JDK 21 example)
export JAVA_HOME=/Library/Java/JavaVirtualMachines/zulu-21.jdk/Contents/Home

# Or use Android Studio's bundled JDK
export JAVA_HOME="/Applications/Android Studio.app/Contents/jbr/Contents/Home"
```

Add to `~/.zshrc` or `~/.bashrc` for persistence.

## Runtime Issues

### Blank Screen

A blank screen can have many causes.

#### With Live Reload

1. The development server must bind to all network interfaces, not just `localhost`. Use the `--external` flag:
   ```bash
   ionic cap run android -l --external
   ```
2. Verify the device can access the development server by opening the URL in the device's browser. The device must be on the same network and not blocked by a firewall.
3. Check that Content Security Policy (CSP) or other security mechanisms are not blocking content — open Chrome DevTools via `chrome://inspect` and check the Console.

#### Without Live Reload

1. **Web assets not copied**: Run `npx cap sync android`.
2. **Wrong `webDir`**: Verify `webDir` in `capacitor.config.ts` matches the web build output directory.
3. **Outdated WebView**: Capacitor requires Android System WebView version 60+. Check via device Settings > Developer options > WebView implementation.
4. **Angular browserslist**: If using Angular, ensure `.browserslistrc` or `browserslist` includes the required browser versions. The Angular CLI uses this for code optimization.
5. **JavaScript error**: Connect Chrome DevTools via `chrome://inspect` and check the Console for errors.

### Plugin Not Found at Runtime

**Symptom**: `"PluginName" plugin is not implemented` or `Capacitor plugin "PluginName" not found` in logcat.

**Solutions**:
1. Verify the plugin is installed and listed in `package.json`.
2. Run `npx cap sync android`.
3. In Android Studio: **File > Sync Project with Gradle Files**.
4. Make sure no conflicting plugin is installed (e.g., two different push notification plugins).
5. Check that the plugin's Android implementation exists in `node_modules/<plugin>/android/`.
6. Make sure to use Node.js 22 or higher. Run `node -v` to check.
7. Run `npx cap doctor` to verify Capacitor CLI versions.

### `net::ERR_CLEARTEXT_NOT_PERMITTED`

**Symptom**: Network requests to HTTP URLs fail.

**Solution**: Android 9+ blocks cleartext (HTTP) traffic by default. Options:
1. Use HTTPS for all API endpoints (recommended).
2. If HTTP is required for development, set `server.cleartext: true` in `capacitor.config.ts`.
3. For specific domains, add a network security config in `android/app/src/main/res/xml/network_security_config.xml`:

```xml
<?xml version="1.0" encoding="utf-8"?>
<network-security-config>
    <domain-config cleartextTrafficPermitted="true">
        <domain includeSubdomains="true">10.0.2.2</domain>
    </domain-config>
</network-security-config>
```

And reference it in `AndroidManifest.xml`:

```diff
 <application
+    android:networkSecurityConfig="@xml/network_security_config"
     ...>
```

### Camera/Permission Issues

**Symptom**: Camera, geolocation, or other permission-protected features do not work.

**Solutions**:
1. Verify permissions are declared in `android/app/src/main/AndroidManifest.xml`.
2. On Android 13+ (API 33), runtime permissions must be requested explicitly. Call `requestPermissions()` before using the feature.
3. Check if the user denied the permission permanently. If so, guide them to Settings > Apps > [App] > Permissions.

### ProGuard / R8 Stripping Plugin Code

**Symptom**: Plugin works in debug but crashes in release builds.

**Solution**: Add ProGuard keep rules in `android/app/proguard-rules.pro`:

```
-keep class com.getcapacitor.** { *; }
-keep class your.plugin.package.** { *; }
```

## Debugging

### View Logs

```bash
adb logcat | grep -i capacitor
```

Or filter by tag in Android Studio's Logcat panel: `Capacitor`, `Capacitor/Plugin`, or the specific plugin tag.

### Remote WebView Debugging

1. Set `android.webContentsDebuggingEnabled: true` in `capacitor.config.ts`.
2. Run the app on a device or emulator.
3. Open `chrome://inspect` in Chrome.
4. Click **inspect** on the listed WebView.


---

## Dosya: `references/troubleshooting-ios.md`

# iOS Troubleshooting

Common iOS issues and their solutions.

## Build Issues

### `pod install` Fails / CocoaPods Incompatible Versions

**Symptom**: `cd ios/App && pod install` fails or `CocoaPods could not find compatible versions for pod "..."`.

**Solutions**:
1. Delete `Podfile.lock` and `Pods` directory, then reinstall with repo update:
   ```bash
   cd ios/App && rm -rf Pods Podfile.lock && pod install --repo-update
   ```
2. Update the CocoaPods spec repo: `pod repo update`.
3. Ensure the correct Ruby and CocoaPods versions are installed: `pod --version`.
4. If using an M1/M2/M3 Mac, run via Rosetta if needed: `arch -x86_64 pod install`.
5. If the problem persists, check that all dependencies in the `Podfile` use compatible versions of the same pod (e.g., all Firebase plugins should use the same Firebase SDK version).

### Signing Errors

**Symptom**: Build fails with "Signing for App requires a development team" or "No signing certificate found."

**Solutions**:
1. Open `ios/App/App.xcodeproj` in Xcode.
2. Select the **App** target > **Signing & Capabilities** tab.
3. Enable **Automatically manage signing**.
4. Select a development team.
5. Verify the Bundle Identifier matches the one registered in the Apple Developer portal.

### Deployment Target Mismatch

**Symptom**: Build fails with "The iOS deployment target is set to X.X, but the range of supported deployment target versions is Y.Y to Z.Z."

**Solution**: Update the deployment target in `ios/App/App.xcodeproj/project.pbxproj`. Find all occurrences of `IPHONEOS_DEPLOYMENT_TARGET` and set to the required minimum:

- Capacitor 7: `15.0`
- Capacitor 8: `16.0`

```diff
- IPHONEOS_DEPLOYMENT_TARGET = 14.0;
+ IPHONEOS_DEPLOYMENT_TARGET = 16.0;
```

Also update in `ios/App/Podfile` if using CocoaPods:

```diff
- platform :ios, '14.0'
+ platform :ios, '16.0'
```

Then run: `cd ios/App && pod install`.

### SPM Package Resolution Fails

**Symptom**: Xcode shows "Package resolution failed" or "Cannot resolve package dependencies."

**Solutions**:
1. In Xcode: File > Packages > Reset Package Caches.
2. In Xcode: File > Packages > Resolve Package Versions.
3. Delete the SPM cache: `rm -rf ~/Library/Caches/org.swift.swiftpm` and `rm -rf ios/App/App.xcodeproj/project.xcworkspace/xcshareddata/swiftpm/`.
4. Close Xcode, run `npx cap sync ios`, then reopen.

### `could not find module 'Capacitor' for target 'x86_64-apple-ios-simulator'`

**Symptom**: Build fails because the `Capacitor` module is not available for the `x86_64` simulator architecture.

**Solution**: Add a `post_install` hook to `ios/App/Podfile`:

```ruby
post_install do |installer|
    installer.pods_project.targets.each do |target|
        target.build_configurations.each do |config|
            config.build_settings['ONLY_ACTIVE_ARCH'] = 'NO'
            config.build_settings['EXCLUDED_ARCHS[sdk=iphonesimulator*]'] = 'arm64'
        end
    end
end
```

Then run: `cd ios/App && pod install`.

### `value of type 'WKWebView' has no member 'isInspectable'`

**Symptom**: Build fails with this error when using an outdated Xcode version.

**Solution**: Capacitor 6+ requires Xcode 15.0 or later. Update Xcode to the latest version.

If this occurs in GitHub Actions, update the runner:

```diff
- runs-on: macos-latest
+ runs-on: macos-14
```

Note: `macos-latest` is not always the actual latest macOS version.

### Module Not Found

**Symptom**: `No such module 'Capacitor'` or `No such module 'PluginName'`.

**Solutions**:
1. Run `npx cap sync ios`.
2. If using CocoaPods: `cd ios/App && pod install`.
3. In Xcode: Product > Clean Build Folder (Shift+Cmd+K).
4. Close and reopen Xcode.
5. Verify the plugin's iOS implementation exists in `node_modules/<plugin>/ios/`.

## Runtime Issues

### Blank Screen

A blank screen can have many causes.

#### With Live Reload

1. The development server must bind to all network interfaces, not just `localhost`. Use the `--external` flag:
   ```bash
   ionic cap run ios -l --external
   ```
2. Verify the device can access the development server by opening the URL in the device's browser. The device must be on the same network and not blocked by a firewall.
3. Check that Content Security Policy (CSP) or other security mechanisms are not blocking content — open Safari Web Inspector and check the Console.

#### Without Live Reload

1. **Web assets not copied**: Run `npx cap sync ios`.
2. **Wrong `webDir`**: Verify `webDir` in `capacitor.config.ts` matches the web build output directory.
3. **Angular browserslist**: If using Angular, ensure `.browserslistrc` or `browserslist` includes the required browser versions. The Angular CLI uses this for code optimization.
4. **JavaScript error**: Open Safari Web Inspector (Develop > [Device] > [WebView]) and check the Console.

### Plugin Not Found at Runtime

**Symptom**: `"PluginName" plugin is not implemented` or `Capacitor plugin "PluginName" not found`.

**Solutions**:
1. Verify the plugin is installed and listed in `package.json`.
2. Run `npx cap sync ios`.
3. Make sure no conflicting plugin is installed (e.g., two different push notification plugins).
4. Make sure `WKAppBoundDomains` is **not** in `ios/App/App/Info.plist` — this key restricts domain access and breaks plugin injection into the WebView.
5. If using CocoaPods: Verify the plugin pod is in `ios/App/Podfile` and run `cd ios/App && pod install`. Ensure no warnings appear during sync.
6. If using SPM: Verify the package appears in Xcode under **Package Dependencies**.
7. Make sure to use the latest Node.js and npm version. Run `node -v` and `npm -v`.
8. Run `npx cap doctor` to verify Capacitor CLI versions.
9. Make sure only one version of Xcode is installed. Check with `xcode-select -p`.

### App Transport Security (ATS) Blocking HTTP

**Symptom**: Network requests to HTTP URLs fail silently or with ATS errors.

**Solution**: iOS blocks cleartext (HTTP) traffic by default. Options:
1. Use HTTPS for all API endpoints (recommended).
2. For development only, add an ATS exception in `ios/App/App/Info.plist`:

```diff
 <dict>
+    <key>NSAppTransportSecurity</key>
+    <dict>
+        <key>NSAllowsArbitraryLoads</key>
+        <true/>
+    </dict>
 </dict>
```

**Do not ship this in production.** For specific domains, use `NSExceptionDomains` instead.

### Keyboard Pushes Content Up

**Symptom**: The keyboard pushes the WebView content up, causing layout issues.

**Solution**: Configure the `@capacitor/keyboard` plugin in `capacitor.config.ts`:

```typescript
const config: CapacitorConfig = {
  plugins: {
    Keyboard: {
      resize: 'none',           // 'body', 'ionic', 'native', 'none'
      resizeOnFullScreen: false, // Required when using edge-to-edge plugins
    },
  },
};
```

### Camera/Permission Issues

**Symptom**: Camera, photo library, or other permission-protected features do not work.

**Solutions**:
1. Verify usage descriptions are in `ios/App/App/Info.plist`:
   ```xml
   <key>NSCameraUsageDescription</key>
   <string>This app uses the camera to take photos.</string>
   <key>NSPhotoLibraryUsageDescription</key>
   <string>This app accesses the photo library to select photos.</string>
   ```
2. Each permission requires a human-readable usage description. Without it, the app crashes when requesting the permission.
3. If the user denied the permission, it cannot be re-requested. Guide them to Settings > [App] > Permissions.

### Push Notifications Not Received on Simulator

iOS simulators do not support push notifications. Test on a physical device. For push notification setup, use the `capacitor-push-notifications` skill.

## Debugging

### Safari Web Inspector

1. Set `ios.webContentsDebuggingEnabled: true` in `capacitor.config.ts`.
2. On the iOS device/simulator: Settings > Safari > Advanced > Web Inspector (enable).
3. On macOS: Safari > Settings > Advanced > Show features for web developers.
4. Run the app, then in Safari: Develop > [Device Name] > [WebView].

### Xcode Console

Native logs appear in Xcode's Debug area (View > Debug Area > Activate Console). Filter by `Capacitor` to see bridge-related messages.

### Common Log Messages

- `Loading app at capacitor://localhost` — Normal startup message.
- `Unable to determine the main bundle path` — Web assets not found. Run `npx cap sync`.
- `Plugin "X" is not implemented` — Plugin has no iOS implementation or is not installed.

## Other Issues

### Version 70 Error

**Symptom**: `Unable to find compatibility version string for object version '70'.`

This is caused by Xcode when adding an extension file to the project.

**Solution**: Open `ios/App/App.xcodeproj/project.pbxproj` and change `objectVersion` from `70` to `60`:

```diff
- objectVersion = 70;
+ objectVersion = 60;
```
