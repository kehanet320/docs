# excel-makro-vba

---
name: excel-makro-vba
description: Excel'in ileri formülleri ve VBA makro programlama için ustalık skill'i. Kullanıcı "VBA", "makro", "Visual Basic", "otomatik tablo", "Sub", "Function", "döngü", "ActiveCell", "Range", "Worksheets", "UserForm", "dizi formülü", "LAMBDA", "LET", "Power Query", "dinamik dizi", "TEXTJOIN", "FILTER", "SORT", "UNIQUE", "SEQUENCE" gibi ifadeler kullandığında devreye girer. Excel'in en üst düzey otomasyon araçlarını ustalıkla kullanır; tekrarlanan iş süreçlerini otomatikleştirir.
---

# Excel Makro ve VBA Ustası

## Genel İlke

Bir işi **bir kerelik** yapacaksan formülle yap. **Tekrar tekrar** yapacaksan **makro** ile otomatikleştir. Bu skill, Excel'in profesyonel programlama katmanını öğretir.

**Önkoşul:** `excel-temel` skill'inde anlatılan temellere hâkim olun. Bu skill onun üzerine inşa edilir.

---

## BÖLÜM 1: İleri Formüller (Önce Bunlar)

VBA'ya geçmeden önce yeni nesil formüller pek çok şeyi makro yazmadan halleder.

### Dinamik Dizi Formülleri (Excel 365/2021+)

Tek bir formül **birden fazla hücreye dökülür**. "Spill" özelliği.

#### FILTER — Filtreleme

```excel
=FILTER(A2:C100; B2:B100="Ankara")
```

A2:C100 aralığında, B sütunu "Ankara" olan satırları getirir. Sonuç **birden fazla satır** olarak otomatik döker.

#### SORT — Sıralama

```excel
=SORT(A2:C100; 3; -1)
```

3. sütuna göre **azalan** (-1) sıralama. Yeni veri eklenince otomatik güncellenir.

#### UNIQUE — Tekrarsız liste

```excel
=UNIQUE(A2:A100)
```

A sütunundaki **benzersiz** değerleri liste olarak verir. Pivot ihtiyacını sıklıkla ortadan kaldırır.

#### SEQUENCE — Sayı dizisi

```excel
=SEQUENCE(10)         → 1,2,3...10
=SEQUENCE(5; 1; 100; 10)  → 100, 110, 120, 130, 140
```

#### Hep Birlikte: Süper Formül

```excel
=SORT(UNIQUE(FILTER(A2:A100; B2:B100>1000)))
```

B sütunu 1000'den büyük olanların A sütunundaki **tekrarsız** değerlerini **sıralı** ver.

### LET — Değişkenli Formül

Karmaşık formülde **ara değişken** kullan:

```excel
=LET(
  vergi_orani; 0.18;
  net; A1;
  brut; net*(1+vergi_orani);
  brut
)
```

Aynı hesabı yedi kez yazmak yerine bir kez tanımla, kullan.

### LAMBDA — Kendi Formülünü Tanımla

Excel'de kendi fonksiyonunu yazabilirsin:

```excel
=LAMBDA(net; net*1,18)
```

Bu LAMBDA'yı **Ad Yöneticisi → Yeni** ile "KDV_LI" olarak adlandırırsan:

```excel
=KDV_LI(1000)   → 1180
```

Artık kendi formülün var.

### TEXTJOIN — Metinleri Birleştir

```excel
=TEXTJOIN("; "; TRUE; A1:A10)
```

A1-A10'daki dolu hücreleri "; " ile ayırarak birleştir.

### TEXTSPLIT (Excel 365 yeni)

```excel
=TEXTSPLIT("Ankara,İzmir,Bursa"; ",")
→ üç ayrı hücreye Ankara | İzmir | Bursa
```

---

## BÖLÜM 2: Power Query (Veri Dönüşüm Aracı)

### Ne İşe Yarar?

**Verilere bir kez kural koyarsın, her seferinde otomatik uygulanır.** Örnek:
- Web sayfasından tablo çekmek
- 10 farklı Excel dosyasını birleştirmek
- Karışık veriyi temiz tabloya dönüştürmek
- Sütunları parçalama, birleştirme

### Açma

**Veri → Veri Al ve Dönüştür → Veri Al**

Kaynak: Excel, CSV, Web, Klasör, Veritabanı, vb.

### Tipik İş Akışı

1. Veri al
2. Power Query Editor açılır
3. Adımları gerçekleştir (sütun sil, filtrele, böl, birleştir, vb.)
4. **Her adım kaydedilir** (sağda "Uygulanan Adımlar")
5. **Yükle**: Sonuç Excel'e gelir
6. **Yenile**: Kaynak veri değiştiğinde Yenile basarsın → Tüm adımlar otomatik tekrar uygulanır

### Sık Kullanılan Dönüşümler

- **Sütun böl:** "Ad Soyad" sütununu "Ad" ve "Soyad"a ayır
- **Boş satırları kaldır**
- **Veri tipini değiştir:** Metin → Sayı, Metin → Tarih
- **Pivot/Unpivot:** Geniş tabloyu uzun, uzun tabloyu geniş yap
- **İlişki kur:** İki tabloyu birleştir (VLOOKUP'a benzer ama gerçek ilişki)

---

## BÖLÜM 3: VBA Temelleri

### VBA Nedir?

**Visual Basic for Applications** — Excel'in (ve Word, PowerPoint'in) içine gömülü programlama dili. Excel'i programlamak için.

### Geliştirici Sekmesini Açma

1. **Dosya → Seçenekler → Şeridi Özelleştir**
2. **Geliştirici** kutusunu işaretle
3. Şeritte "Geliştirici" sekmesi çıkar

### VBA Editörünü Açma

- **Alt + F11** → VBA editörü açılır
- Veya **Geliştirici → Visual Basic**

### İlk Makro — "Merhaba Dünya"

VBA editöründe **Insert → Module** ile yeni modül aç:

```vba
Sub MerhabaDunya()
    MsgBox "Merhaba Dünya!"
End Sub
```

Çalıştırma: **F5** veya **Geliştirici → Makrolar → Çalıştır**

### Makro Kaydetme (Kayıt ile Öğren)

1. **Geliştirici → Makro Kaydet**
2. İsim ver
3. Yapacağın işlemleri **manuel olarak** yap (hücre seç, biçim ver, formül gir...)
4. **Geliştirici → Kaydı Durdur**
5. **Alt+F11** ile VBA editörü aç → Modüllerde kaydedilen kodu gör

**Önemli:** Kaydedilen kod **çoğu zaman gereksiz uzundur** (her tıklamayı kaydeder). Anlayıp **temizlemek** gerekir.

---

## BÖLÜM 4: VBA Sözdizimi

### Değişkenler

```vba
Dim sayi As Integer       ' Tam sayı
Dim metin As String       ' Metin
Dim ondalik As Double     ' Ondalıklı sayı
Dim tarih As Date         ' Tarih
Dim mantik As Boolean     ' True/False
Dim aralik As Range       ' Hücre aralığı

sayi = 10
metin = "Ahmet"
tarih = #5/8/2026#
```

### Atama Operatörü

VBA'da `=` hem **karşılaştırma** hem **atama**.

```vba
sayi = 10              ' Atama
If sayi = 10 Then      ' Karşılaştırma
```

### Hücreye Erişim

```vba
Range("A1").Value = "Merhaba"          ' A1'e değer yaz
Cells(1, 1).Value = "Merhaba"          ' Aynı şey (satır 1, sütun 1)
Range("A1:B10").ClearContents          ' İçerikleri temizle
Range("A1").Font.Bold = True           ' Kalın yap
Range("A1").Interior.Color = vbYellow  ' Sarı arka plan
```

### Sayfaya Erişim

```vba
Worksheets("Sayfa1").Range("A1").Value = 100
ActiveSheet.Range("A1").Value = 100        ' Aktif sayfa
ThisWorkbook.Worksheets(1).Range("A1")     ' İlk sayfa
```

### Çalışma Kitabına Erişim

```vba
Workbooks("Veri.xlsx").Worksheets("Sayfa1").Range("A1")
ActiveWorkbook.Save                ' Aktif kitabı kaydet
ThisWorkbook.Path                  ' Kodun olduğu kitabın yolu
```

---

## BÖLÜM 5: Akış Kontrolü

### If — Eğer

```vba
If A1.Value > 100 Then
    A1.Interior.Color = vbGreen
ElseIf A1.Value > 50 Then
    A1.Interior.Color = vbYellow
Else
    A1.Interior.Color = vbRed
End If
```

### Select Case — Çoklu Seçim

```vba
Select Case Range("B1").Value
    Case "Ankara"
        MsgBox "Başkent"
    Case "İstanbul", "İzmir"
        MsgBox "Büyük şehir"
    Case Is > 1000000
        MsgBox "Sayı, 1 milyondan büyük"
    Case Else
        MsgBox "Diğer"
End Select
```

### For — Döngü

```vba
' 1'den 10'a kadar
For i = 1 To 10
    Cells(i, 1).Value = i
Next i

' 2 atlayarak
For i = 1 To 100 Step 2
    Cells(i, 1).Value = i
Next i

' Bir aralıktaki tüm hücreler
For Each hucre In Range("A1:A10")
    hucre.Value = hucre.Value * 2
Next hucre
```

### Do While / Do Until

```vba
i = 1
Do While Cells(i, 1).Value <> ""
    Cells(i, 2).Value = Cells(i, 1).Value * 2
    i = i + 1
Loop
```

---

## BÖLÜM 6: Pratik VBA Örnekleri

### Örnek 1: Tüm Sayfaları Listele

```vba
Sub SayfalariListele()
    Dim s As Worksheet
    Dim i As Integer
    i = 1
    For Each s In Worksheets
        Cells(i, 1).Value = s.Name
        i = i + 1
    Next s
End Sub
```

### Örnek 2: A Sütunundaki Boşları Sil

```vba
Sub BoslariSil()
    Dim sonSatir As Long
    sonSatir = Cells(Rows.Count, 1).End(xlUp).Row
    
    Dim i As Long
    For i = sonSatir To 1 Step -1   ' Sondan başa! (Yoksa indeks bozulur)
        If Cells(i, 1).Value = "" Then
            Rows(i).Delete
        End If
    Next i
End Sub
```

**Önemli:** Satır silerken **sondan başa** doğru git, yoksa indeks kayar.

### Örnek 3: Birden Fazla Excel Dosyasını Birleştir

```vba
Sub DosyalariBirlestir()
    Dim klasor As String
    Dim dosya As String
    Dim wb As Workbook
    Dim hedef As Workbook
    
    klasor = "C:\Veriler\"
    dosya = Dir(klasor & "*.xlsx")
    
    Set hedef = ThisWorkbook
    Dim sira As Long
    sira = 2
    
    Do While dosya <> ""
        Set wb = Workbooks.Open(klasor & dosya)
        wb.Worksheets(1).UsedRange.Copy hedef.Worksheets(1).Cells(sira, 1)
        sira = sira + wb.Worksheets(1).UsedRange.Rows.Count
        wb.Close False
        dosya = Dir
    Loop
End Sub
```

### Örnek 4: Değer Bulunca Renklendir

```vba
Sub KosulluRenkle()
    Dim hucre As Range
    For Each hucre In Range("A1:A100")
        If IsNumeric(hucre.Value) And hucre.Value > 1000 Then
            hucre.Interior.Color = RGB(255, 200, 200)
            hucre.Font.Bold = True
        End If
    Next hucre
End Sub
```

### Örnek 5: Buton ile Makro Çalıştır

1. **Geliştirici → Ekle → Form Denetimi → Düğme**
2. Düğmeyi sayfaya yerleştir
3. "Makro Ata" diyaloğu açılır → Yazdığın makroyu seç
4. Düğmeye tıklayınca makro çalışır

---

## BÖLÜM 7: Hata Yönetimi

### On Error

```vba
Sub GuvenliMakro()
    On Error GoTo Hata
    
    ' Riskli kod
    Cells(1, 1).Value = 10 / 0   ' 0'a bölme hatası
    
    Exit Sub
    
Hata:
    MsgBox "Hata oluştu: " & Err.Description
End Sub
```

### Hata Tiplerini Yakala

```vba
On Error Resume Next      ' Hatayı yok say, devam et
deger = Range("A1").Value
On Error GoTo 0           ' Hata yakalamayı kapat

If Err.Number <> 0 Then
    MsgBox "Bir sorun oldu"
End If
```

---

## BÖLÜM 8: UserForm (Dialog Tasarlama)

### Basit Form

1. **VBA Editör → Insert → UserForm**
2. Forma TextBox ve CommandButton ekle
3. Düğmeye çift tıklayıp kod yaz:

```vba
Private Sub CommandButton1_Click()
    Range("A1").Value = TextBox1.Value
    Unload Me
End Sub
```

4. Formu çağıran makro:

```vba
Sub FormuAc()
    UserForm1.Show
End Sub
```

---

## BÖLÜM 9: Performans (Hız)

Büyük dosyalarda makro yavaş çalışırsa:

```vba
Sub HizliMakro()
    ' Açılışta:
    Application.ScreenUpdating = False    ' Ekran güncellemesini kapat
    Application.Calculation = xlCalculationManual  ' Otomatik hesaplamayı durdur
    Application.EnableEvents = False      ' Olayları kapat
    
    ' Asıl iş burada...
    
    ' Kapanışta:
    Application.ScreenUpdating = True
    Application.Calculation = xlCalculationAutomatic
    Application.EnableEvents = True
End Sub
```

Bu üçü, makroyu **10-100 kat** hızlandırabilir.

---

## BÖLÜM 10: Makroyu Kaydetme ve Paylaşma

### Dosya Uzantısı

| Uzantı | Açıklama |
|--------|----------|
| `.xlsx` | **Makro içeremez** — kaydederken makrolar silinir |
| `.xlsm` | Makro destekli — makro yazarken bunu kullan |
| `.xlsb` | Binary, daha hızlı, makro destekli |
| `.xlam` | Eklenti — birden fazla dosyada makro paylaş |

### Güvenlik Uyarısı

Makrolu dosyayı açan kişi **"Makroları Etkinleştir"** demeli. Aksi takdirde makrolar çalışmaz.

### Dijital İmza

Şirket ortamında makroları **dijital olarak imzalamak** güvenlik uyarısını azaltır. SelfCert.exe (Office ile gelir) ile kişisel sertifika oluşturulabilir.

---

## BÖLÜM 11: Tehlikeli Şeyler (Bunlardan Kaçın)

### ❌ Sonsuz Döngü

```vba
Do While True
    ' Çıkış koşulu yok!
Loop
```
Excel donar. **Esc + Esc** ile durdur.

### ❌ İndeks Hatası

```vba
For i = 1 To 100
    Worksheets(i).Activate    ' 100 sayfa yoksa hata
Next i
```

### ❌ Save Komutuyla Veri Kaybı

```vba
ActiveWorkbook.Save     ' Geri alınamaz!
```

Önce yedekle, sonra kaydet.

### ❌ Unprotected Brute Force

Makro, korumalı sayfayı/kitabı parolasız açabilir. **Kendi dosyanız** dışında **kullanmayın** (yasal sorun olur).

---

## BÖLÜM 12: Hangi Aracı Ne Zaman Kullan?

| Durum | Tavsiye |
|-------|---------|
| Tek seferlik analiz | Formül + Pivot |
| Her hafta tekrarlanan rapor | Power Query |
| Karmaşık veri dönüşümü | Power Query |
| Karmaşık hesaplama, dinamik | LET / LAMBDA |
| Excel'i programatik kontrol | VBA Makro |
| Buton ile otomasyon | VBA Makro |
| Dialog/form ihtiyacı | VBA UserForm |
| Veri tabanı sorgusu | Power Query (SQL) |
| Web'den veri | Power Query (Web) |

---

## Kontrol Listesi

VBA makro yazarken:

- [ ] Değişkenleri **Dim ile tanımladım** mı?
- [ ] **Hata yönetimi** ekledim mi?
- [ ] Büyük döngülerde **ScreenUpdating** kapattım mı?
- [ ] **Sondan başa** silme döngüsü kullandım mı?
- [ ] **Yorum satırları** ekledim mi (kod açıklayıcı mı)?
- [ ] **.xlsm** olarak kaydettim mi?
- [ ] **Yedek aldım** mı?
- [ ] **Test verisinde** denedim mi (gerçek veriden önce)?

---

## Son Söz

VBA güçlü ama **sorumlu kullanılması gereken** bir araçtır. Yazdığın makro kötüyse veriyi mahveder, iyiyse **yıllarca tasarruf** ettirir.

Önce ileri formüller ve Power Query ile dene. **Makroya gerçekten ihtiyaç var mı?** Bu soruyu mutlaka sor.
