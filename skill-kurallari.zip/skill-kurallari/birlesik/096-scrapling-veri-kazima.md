# scrapling-veri-kazima

---
name: "scrapling-veri-kazima"
description: "Web sitelerinden veri çekme, kazıma (scraping), site düzeni değişince bozulmayan seçiciler ve bot engelli sayfalar istendiğinde Scrapling kütüphanesini kurup kullanmak için."
---

# Scrapling ile Veri Kazıma

Scrapling (D4Vinci/Scrapling), tek bir istekten tam ölçekli taramaya kadar her şeyi yöneten, uyarlanabilir bir Python veri kazıma çerçevesidir. Site düzeni değiştiğinde öğeleri yeniden bulabilir.

## Ne zaman kullanılır
- Kullanıcı bir web sayfasından ya da birçok sayfadan düzenli veri çekmek istiyorsa.
- Sayfa dinamik (JavaScript ile yükleniyor) ya da bot engeli olan bir yapıdaysa.
- Seçicilerin site değişince bozulmaması isteniyorsa.

## Başlamadan önce
1. Yalnızca erişim izni olan sitelerde çalış. robots.txt ve site kullanım koşullarına uy. Ücretli içeriği ya da yetkisiz erişim gerektiren sayfaları gizlilik (stealth) kipiyle aşmaya çalışma.
2. Kuruluma geçmeden önce yaklaşık 200 MB bağımlılık ve tarayıcı indirileceğini kullanıcıya bildir.
3. Çalışma alanının ağ erişimi izin listesiyle sınırlıdır. Hedef siteye erişim reddedilirse başka bir komutla dolanmaya çalışma. Bunu açıkça söyle, gerekirse kullanıcıdan sayfayı dosya olarak göndermesini iste ya da betiği kendi bilgisayarında çalıştırması için hazırla.

## Kurulum
- Python 3.10 ya da üstü gerekir.
- Yalnızca ayrıştırıcı için: `pip install scrapling`
- Getirici sınıfları (fetchers) ve tarayıcı bileşenleri için:
  `pip install "scrapling[fetchers]"` ardından `scrapling install`
- Tüm özellikler için: `pip install "scrapling[all]"` ardından `scrapling install`
- Çalışma alanında pip komutuna `--break-system-packages` eklemek gerekebilir.
- Yalnızca `pip install scrapling` kurulduysa `scrapling.fetchers` içe aktarımı hata verir. Getirici gerekiyorsa köşeli parantezli kurulumu yap.

## Kullanım notları
- Başlıca getirici sınıfları: `Fetcher`, `AsyncFetcher`, `StealthyFetcher`, `DynamicFetcher`. Güncel sınıf adlarını ve imzaları kullanmadan önce resmî belgeden doğrula (https://scrapling.readthedocs.io), çünkü sürümler arasında adlar değişmiştir.
- Uyarlanabilir seçici örneği: `page.css('.product', adaptive=True)`
- Depoda coding ajanlarına kütüphaneyi öğreten resmî bir ajan skill'i bulunur (agent-skill klasörü). Mevcut API'ye uygun kod için önce onu incele.

## Teslim
Çektiği veriyi kullanıcıya CSV ya da Excel dosyası olarak ver. Hangi sayfalardan, hangi tarihte çekildiğini dosyada belirt.
