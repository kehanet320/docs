# excel-temel

---
name: excel-temel
description: Excel'in günlük profesyonel kullanımı için temel ve orta düzey tekniklerin ustası. Kullanıcı "Excel tablosu", "formül", "hücre formatı", "filtre", "sıralama", "VLOOKUP", "INDEX MATCH", "SUMIF", "COUNTIF", "pivot tablo", "grafik", "koşullu biçimlendirme", "veri doğrulama", "açılır liste" gibi ifadeler kullandığında devreye girer. Excel'in temellerini doğru ve etkili kullanmayı öğretir; veri analizinin %80'ini kapsayan teknikleri uygular. İleri formüller ve VBA makro için "excel-makro-vba" skill'i kullanılır.
---

# Excel Temel ve Orta Düzey Ustası

## Genel İlke

Excel'in **gerçek gücünün %80'i** doğru formüllerde, akıllı tablo yapısında ve pivot tablolarındadır. Bu skill, "günlük iş hayatında profesyonelin Excel'i" demektir.

Bu skill `xlsx` resmi skill'iyle birlikte çalışır: O dosyayı **üretir**, bu skill **doğru tablo mantığını** kurar.

---

## BÖLÜM 1: Tablo Tasarımı (Önce Bu)

### Doğru Tablo Yapısı

Excel **liste mantığıyla** çalışır. Doğru tablo:

```
| Tarih      | Ürün     | Adet | Birim Fiyat | Toplam |
|------------|----------|------|-------------|--------|
| 01/03/2026 | Kalem    | 100  | 5,50        | 550,00 |
| 02/03/2026 | Defter   | 50   | 12,00       | 600,00 |
```

**Kural:** 
- 1. satır **başlık**
- Sonraki her satır **tek bir kayıt**
- Her sütun **tek bir veri tipi** (tarih sütunu sadece tarih, sayı sütunu sadece sayı)
- **Birleştirilmiş hücre yok**
- **Boş satır/sütun yok**

### Yanlış Tablo Yapıları

❌ **Birden fazla başlık satırı**
❌ **Boşluklarla hizalama** ("01/03/2026     Kalem      100")
❌ **Sayıların metin olarak yazılması** ("100 adet" yerine sadece 100)
❌ **Birleştirilmiş hücreler**
❌ **Tablo içinde grafik veya başka tablolar**

### "Tabloya Dönüştür" Özelliği

**Ekle → Tablo (Ctrl+T)**

Verilerin bulunduğu alanı seçip "Tablo" yapın. Faydaları:
- Otomatik filtre
- Otomatik biçimlendirme
- Tablo büyüdükçe **formüller otomatik genişler**
- "Toplam satırı" otomatik eklenebilir
- Sütun referansları **adıyla** kullanılır: `=[@[Birim Fiyat]]*[@Adet]`

---

## BÖLÜM 2: Hücre Biçimlendirme (Sık Hatalar)

### Sayı Biçimi vs. Görünüm

Bir hücrede gördüğün **görünüm**, içindeki **gerçek değerden farklı** olabilir:

- Hücrede `1.234,56` görünür → İçinde aslında `1234.56` var
- Bu fark çok önemli, çünkü formül **gerçek değeri** kullanır

### Türkçe Formatı

| Format | Örnek |
|--------|-------|
| Sayı (binlik ayraçlı) | 1.234,56 |
| Para birimi (₺) | 1.234,56 ₺ |
| Yüzde | %12,5 |
| Tarih (kısa) | 08.05.2026 |
| Tarih (uzun) | 8 Mayıs 2026 Perşembe |
| Saat | 14:30:00 |

**Not:** Türkçe Excel'de **ondalık ayracı virgül** (,), **binlik ayracı nokta** (.). İngilizce Excel ile veri alışverişinde sorun olur.

### Özel Format Kodları

Sağ tık → Hücreleri Biçimlendir → Özel:

| Kod | Sonuç |
|-----|-------|
| `0` | 5 → 5 |
| `00` | 5 → 05 |
| `0,00` | 5 → 5,00 |
| `#.##0` | 1234 → 1.234 |
| `#.##0,00 ₺` | 1234.5 → 1.234,50 ₺ |
| `0%` | 0,5 → %50 |
| `[Kırmızı]-0;[Mavi]+0` | -5 kırmızı, +5 mavi |
| `dd.mm.yyyy` | 08.05.2026 |

---

## BÖLÜM 3: Temel Formüller (Mutlaka Bilinmeli)

### Matematik

| Formül | Ne yapar |
|--------|----------|
| `=SUM(A1:A10)` | A1-A10 toplamı |
| `=AVERAGE(A1:A10)` | A1-A10 ortalaması |
| `=MAX(A1:A10)` / `=MIN(A1:A10)` | En büyük / en küçük |
| `=COUNT(A1:A10)` | Sayı içeren hücre adeti |
| `=COUNTA(A1:A10)` | Boş olmayan hücre adeti |
| `=ROUND(A1; 2)` | A1'i 2 basamağa yuvarla |
| `=INT(A1)` | Tam sayıya çevir (aşağı yuvarla) |

**Türkçe Excel'de:** SUM yerine **TOPLA**, AVERAGE yerine **ORTALAMA**, COUNT yerine **BAĞ_DEĞ_SAY**, IF yerine **EĞER** kullanılır. Aynı formüller, sadece dil farklı.

### Mantıksal

```excel
=IF(şart; doğruysa; yanlışsa)
=EĞER(A1>100; "Yüksek"; "Düşük")

=AND(şart1; şart2)    → İkisi de doğruysa TRUE
=OR(şart1; şart2)     → Biri doğruysa TRUE
=NOT(şart)            → Tersini al

=IF(AND(A1>100; B1<50); "Tamam"; "Hata")
```

### Metin

```excel
=LEFT(A1; 5)          → Soldan 5 karakter
=RIGHT(A1; 3)         → Sağdan 3 karakter
=MID(A1; 2; 4)        → 2. karakterden 4 karakter al
=LEN(A1)              → Karakter sayısı
=UPPER(A1)            → BÜYÜK HARF
=LOWER(A1)            → küçük harf
=PROPER(A1)           → İlk Harfler Büyük
=TRIM(A1)             → Baş/son boşluğu sil
=CONCAT(A1; " "; B1)  → Birleştir
=SUBSTITUTE(A1;"a";"b")  → "a"yı "b" ile değiştir
```

**Türkçede önemli:** Türkçe karakterli metinde `UPPER` İngilizce kuralı kullanır. "i" harfini "I" yapar (doğrusu "İ"). Türkçe sürümde **BÜYÜKHARF** Türkçe doğru çalışır.

### Tarih

```excel
=TODAY()              → Bugünün tarihi
=NOW()                → Şu anki tarih+saat
=YEAR(A1)             → Tarihten yıl
=MONTH(A1)            → Tarihten ay
=DAY(A1)              → Tarihten gün
=WEEKDAY(A1; 2)       → Haftanın günü (Pzt=1)
=DATEDIF(A1; B1; "d") → İki tarih arası gün
```

**Tarih Aritmetiği:** Excel tarihi sayı olarak tutar (1 = 01/01/1900). Yani:
- Tarih + 30 = 30 gün sonrası
- Tarih2 - Tarih1 = aradaki gün sayısı

---

## BÖLÜM 4: Arama Formülleri (En Kritik)

### VLOOKUP (Düşeyara)

Bir tabloda **dikey** arama yapar.

```excel
=VLOOKUP(aranan; tablo; sütun_no; tam_eşleşme)
=DÜŞEYARA(A2; B:D; 3; YANLIŞ)
```

**Örnek:** Personel listesinden TC numarasıyla maaş bul.

```
| TC Kimlik       | Ad     | Maaş   |
|-----------------|--------|--------|
| 12345678901     | Ahmet  | 25.000 |
| 23456789012     | Mehmet | 28.000 |

=VLOOKUP("12345678901"; A:C; 3; FALSE)
→ 25.000
```

**Sınırlamalar:**
- Aranan sütun **tablonun en solunda** olmalı
- **Sağa doğru** sayar (sütun_no=1 ilk sütun)

### INDEX + MATCH (Daha Güçlü)

VLOOKUP'ın sınırlamalarını aşar:

```excel
=INDEX(getirilecek_sütun; MATCH(aranan; aranılacak_sütun; 0))
=İNDİS(C:C; KAÇINCI("ahmet"; B:B; 0))
```

**Avantajları:**
- Aranan sütun **herhangi bir yerde** olabilir
- **Sola, sağa, yukarı, aşağı** her yöne çalışır
- VLOOKUP'tan **hızlı**

### XLOOKUP (Yeni — Excel 365/2021+)

VLOOKUP'ın modern, basit ve güçlü versiyonu:

```excel
=XLOOKUP(aranan; aranılacak; getirilecek; bulunmazsa)
=ARA.X("Ahmet"; B:B; C:C; "Bulunamadı")
```

Eğer Excel 365 veya 2021+ kullanıyorsanız, **VLOOKUP yerine XLOOKUP kullanın**. Daha basit, daha güçlü.

---

## BÖLÜM 5: Koşullu Formüller (SUMIF, COUNTIF)

### COUNTIF / COUNTIFS

```excel
=COUNTIF(aralık; kriter)
=EĞERSAY(B:B; "Ankara")     → "Ankara" yazan kaç hücre var?

=COUNTIFS(aralık1; kriter1; aralık2; kriter2)
=ÇOKEĞERSAY(B:B; "Ankara"; C:C; ">10000")
```

### SUMIF / SUMIFS

```excel
=SUMIF(aralık; kriter; toplanacak)
=ETOPLA(B:B; "Ankara"; D:D)   → Ankara'dakilerin toplamı

=SUMIFS(toplanacak; aralık1; kriter1; aralık2; kriter2)
```

### AVERAGEIF / AVERAGEIFS

Aynı mantık, ortalama için.

### Kriter Yazımı

| Kriter | Anlamı |
|--------|--------|
| `"Ankara"` | Tam eşleşme |
| `">100"` | 100'den büyük |
| `"<>0"` | Sıfırdan farklı |
| `"*kale*"` | "kale" geçen |
| `">="&A1` | A1'den büyük eşit |

---

## BÖLÜM 6: Pivot Tablolar (En Güçlü Araç)

### Ne İşe Yarar?

Bin satırlık ham veriden **anlamlı özet** çıkarır. Manuel formül yazmadan:

- "Ay bazında toplam satış"
- "Şehir bazında ortalama maaş"
- "Ürün kategorisinde en çok satan"

### Adımlar

1. **Tablonuzu seç** (Ctrl+T ile tabloya dönüştürmek tavsiye edilir)
2. **Ekle → Özet Tablo (PivotTable)**
3. Yeni sayfada açılır
4. Sağdaki **alanlar bölmesi**:
   - **Satırlar**: Hangi kategorilere göre gruplanacak (örn. "Şehir")
   - **Sütunlar**: İkinci kategori (örn. "Ay")
   - **Değerler**: Hangi sayı toplanacak/sayılacak/ortalama alınacak
   - **Filtreler**: Üstte filtreleme

### Örnek

Ham veri:
```
Tarih       | Şehir   | Ürün    | Tutar
01/03/2026  | Ankara  | Kalem   | 500
02/03/2026  | İzmir   | Defter  | 800
03/03/2026  | Ankara  | Defter  | 600
```

Pivot tablo (Satırlar=Şehir, Sütunlar=Ürün, Değerler=Tutar):
```
              | Defter | Kalem | Genel Toplam
Ankara        | 600    | 500   | 1.100
İzmir         | 800    | -     | 800
Genel Toplam  | 1.400  | 500   | 1.900
```

### Profesyonel İpuçları

- **Kaynak veriyi tablo (Ctrl+T) yapın** → Pivot otomatik genişler
- **Yenile**: Veriler değişti mi? Pivot tabloya sağ tık → Yenile (Alt+F5)
- **Slicer (Dilimleyici)** ekleyin: Tıklamayla filtre. Çok güzel görünür, çok pratik.
- **Pivot grafiği**: Aynı veriden grafik

---

## BÖLÜM 7: Koşullu Biçimlendirme

### Ne İşe Yarar?

Belirli koşulu sağlayan hücreleri **görsel** olarak vurgular.

### Klasik Kullanımlar

**Giriş → Koşullu Biçimlendirme**

| Kural | Sonuç |
|-------|-------|
| Hücre değeri > 100 | Yeşil dolgu |
| Hücre değeri < 0 | Kırmızı yazı |
| Yinelenen değerler | Sarı vurgu |
| Renk skalaları | Min-max arası degrade |
| Veri çubukları | Hücrede mini bar grafik |
| Simge kümeleri | Trafik ışığı (yeşil/sarı/kırmızı) |

### Formülle Koşullu Biçim

Standart kurallar yetmezse formül yazılır:

`=AND($C2>100; $D2="Onaylı")` → Hem C sütunu 100'den büyük hem D "Onaylı" olan **satırın tamamını** boya.

**Önemli:** `$C2` (sütun sabit, satır değişken) yazımı **satırın tamamını** boyamak için.

---

## BÖLÜM 8: Veri Doğrulama (Açılır Liste)

### Açılır Liste Oluşturma

1. Hücreyi seç
2. **Veri → Veri Doğrulama**
3. **İzin Verilen: Liste**
4. **Kaynak:** `Ankara, İzmir, Bursa, İstanbul`

Artık o hücrede sadece bu seçenekler seçilebilir.

### Dinamik Liste

Kaynak `=$F$1:$F$10` gibi bir aralık verirseniz, o aralık değiştikçe liste güncellenir.

### Sayı/Tarih Doğrulama

| Tip | Kural |
|-----|-------|
| Tam sayı | 1-100 arası |
| Ondalık | 0-1 arası |
| Tarih | 01/01/2026'dan büyük |
| Metin uzunluğu | En fazla 50 karakter |

---

## BÖLÜM 9: Grafik Hazırlama

### Hangi Grafik Ne Zaman?

| Grafik | Uygun olduğu durum |
|--------|-------------------|
| **Sütun** | Kategorileri karşılaştır (şehir bazında satış) |
| **Çubuk** | Uzun kategori adları olduğunda |
| **Çizgi** | Zaman içinde değişim (aylık trend) |
| **Pasta** | Bütünün parçaları (Toplamın yüzde 100 olduğu) |
| **Dağılım (Scatter)** | İki değişken arası ilişki |
| **Alan** | Çizgi + altı dolu (kümülatif) |

### Profesyonel İlkeler

❌ **3D pasta grafik** (algıyı bozar, profesyonel değil)
❌ **Çok renkli abartı** (8 renk değil, 2-3 renk)
❌ **Gereksiz dekorasyon** (şablon stillerinin abartısı)
❌ **Pasta dilimi sayısı 6'dan fazla** (oku az olanları "Diğer"de topla)

✅ **Tek bir mesaj** her grafikte
✅ **Net başlık** ("Aylık Satış" değil, "2026 Q1 Satışlarda %15 Artış")
✅ **Açıklayıcı eksenler**
✅ **Veri etiketleri** (sayılar görünsün)

---

## BÖLÜM 10: Klavye Kısayolları

| Kısayol | Ne yapar |
|---------|----------|
| Ctrl + T | Tabloya dönüştür |
| Ctrl + Shift + L | Filtre aç/kapat |
| Ctrl + Yön tuşu | Doluluğun sonuna git |
| Ctrl + Shift + Yön | Doluluğu seçerek git |
| Ctrl + Home | A1'e git |
| Ctrl + End | Verinin son köşesine git |
| Ctrl + ; | Bugünün tarihini gir |
| Ctrl + Shift + ; | Şu anki saati gir |
| F4 | Formülde $ ekle/çıkar |
| Alt + = | Otomatik toplam |
| Ctrl + 1 | Hücre formatı diyaloğu |

---

## Bitirmeden Önce Kontrol

- [ ] **Başlık satırı** tek satır mı?
- [ ] **Sayılar gerçekten sayı** mı (metin değil)?
- [ ] **Tarihler tarih formatında** mı?
- [ ] **Birleştirilmiş hücre** var mı (varsa kaldır)?
- [ ] **Tablo (Ctrl+T)** olarak ayarlandı mı?
- [ ] Formüller **göreceli/mutlak** referans doğru mu ($ işaretleri)?
- [ ] **#REF, #N/A, #DIV/0** hataları var mı?
- [ ] Grafik **net mesaj** veriyor mu?
- [ ] Açılış sayfası **kaydetme öncesinde** yeniden A1'e ayarlandı mı?

---

## İleri Konular

İleri Excel formülleri (dizi formülleri, dinamik dizi formülleri, LET, LAMBDA, Power Query) ve **VBA makro** için **excel-makro-vba** skill'i kullanılır.
