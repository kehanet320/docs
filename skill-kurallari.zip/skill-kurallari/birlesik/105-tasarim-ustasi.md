# tasarim-ustasi

---
name: tasarim-ustasi
description: Görsel tasarım çalışmaları için kullanılır. Kullanıcı "tasarla", "afiş", "broşür", "antet", "logo", "kapak", "şablon", "sunum tasarımı", "infografik", "poster", "kartvizit", "renk paleti", "tipografi", "görsel düzen" gibi ifadeler kullandığında devreye girer. Kurumsal/resmi tasarım ile yaratıcı tasarımı birbirinden ayırarak, bağlama uygun, "AI hissi" vermeyen, özgün ve profesyonel görsel çıktılar üretir.
---

# Tasarım Ustası

## Genel İlke

**İyi tasarım kararlardır, kazara ortaya çıkmaz.** Tasarımın temeli; renk, tipografi, hiyerarşi, boşluk ve niyet etrafında bilinçli seçimler yapmaktır. "AI'ın varsayılanlarına" düşmeden, bağlama uygun özgün çözümler üretilir.

---

## Önce Soruyu Sor: Hangi Tasarım Türü?

Tasarıma başlamadan önce mutlaka netleşmesi gereken sorular:

1. **Bağlam nedir?**
   - **Kurumsal/resmi** mi? (kurum içi belge, antet, devlet kurumu sunumu)
   - **Yarı kurumsal** mı? (etkinlik afişi, broşür, davetiye)
   - **Yaratıcı/serbest** mi? (kişisel proje, sanatsal çalışma)
   
2. **Hedef kitle kim?** (Yaş, eğitim, kurum tipi)

3. **Çıktı nerede kullanılacak?** (Yazıcı çıktısı? Ekran? Sosyal medya? PowerPoint?)

4. **Marka/kurum kuralları var mı?** (Kurumsal kimlik kılavuzu, logo dosyası)

5. **Format ve ölçü?** (A4, A3, 1080x1080, 16:9, vs.)

---

## Kurumsal/Resmi Tasarım Kuralları

Devlet kurumu, üniversite, kamu kuruluşu için tasarımda **abartı yasaktır**. İlkeler:

### Renk
- **Maksimum 3 renk** (genelde 2 yeter): kurum rengi + nötr (siyah/beyaz/gri) + ihtiyaç olursa vurgu
- Türk Bayrağı kırmızısı: `#E30A17` (resmi kullanım için)
- Kurumsal mavi tonları: `#003F87`, `#1F4E79`
- Devlet kurumlarında pastel/florasan renkler **kullanılmaz**

### Tipografi
- **Türkçe karakterleri tam destekleyen** font seçilir
- **Resmi belgeler için**: Times New Roman, Calibri, Arial *(yönetmelik gereği genelde Times New Roman 12 punto)*
- **Modern kurumsal için**: Open Sans, Source Sans Pro, Roboto
- **Asla**: Comic Sans, Papyrus, Curlz MT, Brush Script
- En fazla **2 font** karıştırılır (1 başlık fontu + 1 metin fontu)

### Düzen
- **Boşluk korunur** (whitespace) — alanı doldurmak için zorlamayın
- **Hizalama net** (sola/ortaya/sağa) — karışık hizalama amatör görünür
- **Hiyerarşi belirgin**: Başlık > alt başlık > metin > dipnot, her seviye boyut/kalınlık farkıyla ayrılır
- **3-12 grid sistemi** kullanılır

### Yapılmaması Gerekenler
- Gradient (degrade) kullanmayın
- 3D efekt, gölge yığını yapmayın
- Stok fotoğraf klişeleri ("kurumsal el sıkışma" vb.) kullanmayın
- Logo'yu eğmeyin/germeyin/renk değiştirmeyin

---

## Yaratıcı Tasarım Kuralları

Kurumsal kısıtlar yoksa **AI'ın varsayılanlarından çıkmak** gerekir. Bunlar AI'ın otomatik gittiği klişeler:

### ❌ Yasaklı Klişeler (AI Slop)
- **Inter, Roboto fontları** (her yerde aynı)
- **Beyaz arka planda mor degrade**
- **Yuvarlatılmış köşeli kartlar** (her şey card)
- **Pastel pembe/mavi/mor pasteller**
- **Gereksiz ikonlar** (Lucide-react ikonu her yerde)
- **Yarısı saydam sticker görünümü** (glassmorphism abartısı)

### ✅ Hangi Yöne Gidilebilir?

Tasarıma başlamadan **estetik yön** seçin:

| Stil | Ne zaman uygun | Belirgin özellikleri |
|------|----------------|----------------------|
| **Brutalist** | Sanat, müzik, manifesto | Kalın çerçeveler, yüksek kontrast, sade font |
| **Editoryal** | Dergi, yazı odaklı | Serif font, geniş boşluk, asimetrik düzen |
| **Maksimalist** | Etkinlik, festival | Yoğun renk, çoklu eleman, oyunbaz |
| **Minimalist** | Lüks marka | Çok az eleman, geniş beyaz alan, tek vurgu |
| **Retro-fütüristik** | Tech, oyun, müzik | Neon, CRT efekti, vintage gelecek |
| **Türk-İslam motifli** | Geleneksel, dini | Hat sanatı, geometrik desen, sıcak renk |
| **Editoryal Türk** | Kültürel | Ebru, Türk halı motifi, sıcak ton |

---

## Tipografi Kuralları (Detaylı)

### Hiyerarşi

Bir sayfada **en az 3 boyut farkı** olmalı:

```
ANA BAŞLIK    → 32-72 punto, kalın
Alt başlık    → 18-24 punto, yarı kalın
Metin         → 11-14 punto, normal
Dipnot/etiket → 8-10 punto, açık gri
```

### Türkçe için Font Eşleştirme Önerileri

**Klasik/Resmi:**
- Başlık: Playfair Display / Cormorant
- Metin: Merriweather / Lora

**Modern/Profesyonel:**
- Başlık: Montserrat / Poppins (kalın)
- Metin: Open Sans / Source Sans Pro

**Sanatsal/Editoryal:**
- Başlık: Bodoni / Didot
- Metin: Cormorant Garamond

**Türkçe Karakter Uyarısı:** ç, ğ, ı, ö, ş, ü karakterlerinin **tüm fontlarda** doğru göründüğünü kontrol edin. Bazı dekoratif fontlar bu karakterleri desteklemez.

---

## Renk Paleti Oluşturma

### 60-30-10 Kuralı

Bir tasarımda **3 ana renk** kullanılırsa:
- **%60** — Baskın renk (genelde nötr: beyaz, krem, koyu gri)
- **%30** — İkincil renk (kurum rengi)
- **%10** — Vurgu rengi (canlı, dikkat çekici)

### Renk Psikolojisi (Türk Kültürü Bağlamında)

| Renk | Çağrışım |
|------|----------|
| Kırmızı | Bayrak, ulusal, güç, dikkat |
| Lacivert | Devlet, ciddiyet, güven |
| Yeşil | İslami motif, doğa, sağlık |
| Beyaz | Saflık, resmiyet, boşluk |
| Altın/Sarı | Geleneksel, lüks, Osmanlı |
| Bordo | Akademik, edebî, klasik |

### Sık Yapılan Hata
**"Daha çok renk daha güzel" değil.** İki rengi mükemmel kullanmak, beş rengi orta kullanmaktan iyidir.

---

## Resmi Tasarım Şablonları (Hızlı Referans)

### Kurumsal Antet
```
[Logo - sol üst]              [Kurum tam adı - merkez]
                              [Birim adı - daha küçük]

[İçerik bölgesi]

[Adres bilgileri - alt, küçük punto, gri]
```

### Etkinlik Afişi (Kurumsal)
```
[Üst kısım: Logo + kurum adı]
[Orta: ANA BAŞLIK - büyük, etkili]
[Alt orta: Tarih, saat, yer]
[Alt: Konuşmacılar / detaylar]
[Dipnot: Web/iletişim]
```

### Sertifika/Belge
```
[Üst süsleme - sade]
"BELGE / SERTİFİKA"
[Kişi adı - kaligrafik]
[Açıklama metni]
[İmza alanları - alt]
[QR kod / belge no - en alt]
```

---

## Görsel Hiyerarşi: F Deseni ve Z Deseni

İnsanlar bir tasarımı **belirli bir sırayla** tarar:

- **Z Deseni** (basit tasarım): Sol üst → sağ üst → sol alt → sağ alt
- **F Deseni** (yoğun metin): Üstten sola yatay, sonra dikey aşağı

Tasarımda **en önemli bilgi** F veya Z deseninin **ilk durağına** yerleştirilir.

---

## Tasarım Süreci

### Adım 1: Brief
Yukarıdaki "Önce Soruyu Sor" bölümündeki 5 sorunun cevabı netleşmeden tasarıma başlamayın.

### Adım 2: Yön Belirleme
Kurumsal mı, yaratıcı mı? Hangi stil? 2-3 cümlelik bir **estetik yön özeti** yazın.

**Örnek:** "Modern kurumsal, lacivert ve beyaz baskın, Open Sans tipografi, sade düzen, sağ üstte logo."

### Adım 3: Düzen Taslağı (Wireframe)
Hangi eleman nereye? Önce kabaca yerleştirin (renksiz, fontsız).

### Adım 4: Tipografi
Başlık ve metin fontunu seçin. **Font eşleştirme test edin** (Türkçe karakterleri kontrol).

### Adım 5: Renk
Paleti uygulayın. 60-30-10 oranını tutturun.

### Adım 6: Detaylar
İkonlar, çizgiler, ikincil görseller. **Az ekleyin**, kalabalık etmeyin.

### Adım 7: Geri Adım
Tasarımdan **bir gün** uzaklaşın (mümkünse). Sonra fresh gözle bakın. Hâlâ iyi mi?

---

## Çıktı Formatları

| Format | Ne için | DPI | Profil |
|--------|---------|-----|--------|
| PDF (yazıcı) | Antet, broşür, dokuman | 300 | CMYK |
| PNG (ekran) | Web, e-posta, sunum | 72-150 | RGB |
| JPG (foto) | Fotoğraf ağırlıklı | 72-300 | RGB |
| SVG | Logo, ikon, vektör | - | - |

---

## Değerlendirme Listesi

Tasarımı tamamlamadan önce sor:

- [ ] **Hiyerarşi net mi?** — Hangi bilgi en önemli, ilk göze çarpıyor mu?
- [ ] **Boşluklar yeterli mi?** — Yoksa her yer dolu mu?
- [ ] **Maksimum 2 font** kullandım mı?
- [ ] **Renkler birbiriyle uyumlu** mu? Kontrast yeterli mi?
- [ ] **Türkçe karakterler** her yerde doğru görünüyor mu?
- [ ] **Mobil/küçük ekranda** okunaklı mı?
- [ ] **Bir AI'ın varsayılan çıktısına** benziyor mu? (Benziyorsa, değiştir.)
- [ ] **Hedef kitle bunu görse** ciddiye alır mı?

---

## Son İlke

**Az ama doğru, çoktan iyidir.**

Süslemek için süslemeyin. Her elemanın bir gerekçesi olmalı. "Güzel görünsün diye" eklenen şey, çoğu zaman tasarımı bozar.
