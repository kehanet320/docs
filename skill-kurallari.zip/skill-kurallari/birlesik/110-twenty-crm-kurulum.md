# twenty-crm-kurulum

---
name: "twenty-crm-kurulum"
description: "Açık kaynaklı CRM uygulaması Twenty'yi kendi sunucuda Docker Compose ile kurma, yapılandırma, yedekleme ve sorun giderme istendiğinde kullanmak için."
---

# Twenty CRM Kurulum Rehberi

Twenty (twentyhq/twenty), Salesforce'a açık kaynaklı bir alternatif olarak geliştirilen, kendi sunucuda barındırılabilen bir CRM'dir.

## Ne zaman kullanılır
- Kullanıcı kendi sunucusunda ya da bilgisayarında bir CRM kurmak istediğinde.
- Kurulum, ortam değişkenleri, dışarıdan erişim, yedekleme ya da güncelleme konusunda yardım istendiğinde.

## Çalışma ilkeleri
1. Twenty sürekli açık duran bir sunucu uygulamasıdır, geçici çalışma alanında kalıcı olarak barındırılamaz. Kurulum kullanıcının kendi bilgisayarında ya da sunucusunda yapılır, komutları ve yapılandırma dosyalarını hazırla.
2. Adımları vermeden önce resmî belgeyi kontrol et (https://docs.twenty.com/developers/self-host/capabilities/docker-compose), sürümler arasında komutlar değişebilir.
3. Kullanıcının kurulumuna dair olmayan bir bilgiyi tahmin etme. Sunucu işletim sistemi, Docker kurulu mu gibi durumları sor ya da kurulum adımı olarak kontrol ettir.

## Ön koşullar
- Docker ve Docker Compose kurulu ve güncel olmalıdır.
- Bir kurulum rehberinde en az 2 GB RAM belirtiliyor. Kesin gereksinimi resmî belgeden doğrula.

## Hızlı kurulum
Docker Compose rehberindeki tek komutluk kurulum betiği:
`bash <(curl -sL https://raw.githubusercontent.com/twentyhq/twenty/main/packages/twenty-docker/scripts/install.sh)`
Özel bir sürüm için `VERSION=vx.y.z BRANCH=dal-adı bash <(curl -sL ...)` biçimi kullanılır. Betiği çalıştırmadan önce kaynak kodunu okumayı kullanıcıya öner.

## El ile kurulum
1. Örnek ortam dosyasını indir: `curl -o .env https://raw.githubusercontent.com/twentyhq/twenty/refs/heads/main/packages/twenty-docker/.env.example`
2. Compose dosyasını indir: `curl -o docker-compose.yml https://raw.githubusercontent.com/twentyhq/twenty/refs/heads/main/packages/twenty-docker/docker-compose.yml`
3. `.env` dosyasında gizli anahtarı ve veritabanı parolasını güçlü, benzersiz değerlerle ayarla.
4. Başlat: `docker compose up -d`
5. Kendi bilgisayarında `http://localhost:3000` adresini aç. Sunucudaysa sunucunun çalıştığını kontrol et.

## Dışarıdan erişim ve yapılandırma
- Varsayılan olarak Twenty yerel makinede 3000 numaralı kapıda çalışır. Dışarıdan erişim için resmî belgedeki ilgili bölümü izle, değişiklikten sonra `docker compose down` ve `docker compose up -d` ile yeniden başlat.
- Ortam değişkenleri, sunucu ve işçi (worker) düzeyinde ilgili olana göre `docker-compose.yml` içinde tanımlanmalıdır.
- Ters vekil (reverse proxy) arkasında bağlantı sorunu yaşanırsa belgedeki sorun giderme sayfasına bak.

## Yedekleme
- Veritabanı yedeği: `docker exec twenty-postgres pg_dump -U postgres twenty > yedek_$(date +%Y%m%d).sql`
- Geri yükleme öncesinde `docker compose stop twenty-server twenty-front`, geri yükleme sonrasında `docker compose up -d` kullanılır. Tam geri yükleme komutunu resmî belgeden doğrula.
- Verilerin kalıcı olması için Docker Compose birimleri (volumes) kullanılır. Bu birimleri silme.
