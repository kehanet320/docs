# webview-apk-indirme

---
name: "webview-apk-indirme"
description: "Android WebView/Capacitor APK içinde görsel, PDF veya dosya indirme çöküyor ya da çalışmıyorsa (data: URI, blob: URI, a download) kullan; çökmeyen indirme zincirini ve hazır Java/JS kodunu verir."
---

# WebView APK İndirme Sorunu ve Çözümü

`webview-apk-kurallari` ile birlikte kullanılır. İlk gerçek vaka: **Söz Atölyesi** (tek dosyalık HTML kart uygulaması); PNG/JPEG dışa aktarımında uygulama çöküyordu.

## 1. Neden çöküyor?

- Masaüstü tarayıcıda çalışan `<a href="data:image/png;base64,..." download>` WebView'da indirme yöneticisine gider; Android `DownloadManager` `data:` şemasını desteklemez → `IllegalArgumentException` ve uygulama kapanır.
- `blob:` URL'leri WebView dışındaki süreçlerden okunamaz; indirme ya sessizce başarısız olur ya da aynı hatayı verir.
- Büyük görsellerde uzun base64 string'ini URL olarak taşımak bellek sınırına takılır.

**Kural:** APK'da asla `a[download]` + `data:`/`blob:` URL ile indirme yapılmaz.

## 2. Çökmeyen indirme zinciri (sırayla dene)

1. **Yerel köprü** (`window.AndroidDownload` varsa): base64 veriyi Java'ya ver, Java MediaStore ile kaydetsin. APK'da birincil yol.
2. **Web Share API** (`navigator.canShare({files})` true ise): dosyayı paylaşım menüsüne gönder; kullanıcı Galeri/Dosyalar'ı seçer.
3. **Masaüstü tarayıcı** (WebView değilse): `blob:` URL + `a[download]`, iş bitince `URL.revokeObjectURL`.
4. **Son çare:** görseli tam ekran aç, "Uzun basıp kaydedin" uyarısı göster.

Her adım `try/catch` içinde; bir adım hata verirse sonrakine geçilir, kullanıcıya kaydedilip kaydedilmediği kesin bildirilir.

## 3. JavaScript tarafı

```js
async function dosyaKaydet(canvas, ad = 'kart.png', tur = 'image/png', kalite = 0.95) {
  const blob = await new Promise(r => canvas.toBlob(r, tur, kalite));
  if (!blob) throw new Error('Görsel oluşturulamadı');

  // 1) Yerel köprü
  if (window.AndroidDownload && window.AndroidDownload.saveBase64) {
    const b64 = await new Promise((ok, hata) => {
      const fr = new FileReader();
      fr.onload = () => ok(String(fr.result).split(',')[1]);
      fr.onerror = hata;
      fr.readAsDataURL(blob);
    });
    const sonuc = window.AndroidDownload.saveBase64(b64, tur, ad);
    if (sonuc === 'OK') return bildir('Görsel Galeri\'ye kaydedildi.');
  }

  // 2) Paylaşım
  const dosya = new File([blob], ad, { type: tur });
  if (navigator.canShare && navigator.canShare({ files: [dosya] })) {
    try { await navigator.share({ files: [dosya] }); return; } catch (e) { /* iptal edildiyse devam */ }
  }

  // 3) Masaüstü tarayıcı
  if (!/; wv\)/.test(navigator.userAgent)) {
    const url = URL.createObjectURL(blob);
    const a = Object.assign(document.createElement('a'), { href: url, download: ad });
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 4000);
    return;
  }

  // 4) Son çare
  tamEkranGoster(URL.createObjectURL(blob));
  bildir('Görsele uzun basıp kaydedebilirsiniz.');
}
```

## 4. Java tarafı (Capacitor `MainActivity`)

```java
package com.ornek.uygulama;

import android.content.ContentValues;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import com.getcapacitor.BridgeActivity;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;

public class MainActivity extends BridgeActivity {
  @Override
  public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    WebView wv = getBridge().getWebView();
    wv.addJavascriptInterface(new IndirmeKoprusu(), "AndroidDownload");
    // data:/blob: linkleri DownloadManager'a gidip uygulamayı çökertmesin
    wv.setDownloadListener((url, ua, cd, mime, len) -> {
      if (url.startsWith("data:")) {
        int virgul = url.indexOf(',');
        if (virgul > 0) new IndirmeKoprusu().saveBase64(url.substring(virgul + 1), mime, "indirme");
      }
      // blob: burada yok sayılır; JS tarafı köprüyü kullanır
    });
  }

  class IndirmeKoprusu {
    @JavascriptInterface
    public String saveBase64(String b64, String mime, String ad) {
      try {
        byte[] veri = Base64.decode(b64, Base64.DEFAULT);
        boolean gorsel = mime != null && mime.startsWith("image/");
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
          ContentValues cv = new ContentValues();
          cv.put(MediaStore.MediaColumns.DISPLAY_NAME, ad);
          cv.put(MediaStore.MediaColumns.MIME_TYPE, mime);
          cv.put(MediaStore.MediaColumns.RELATIVE_PATH,
              (gorsel ? Environment.DIRECTORY_PICTURES : Environment.DIRECTORY_DOWNLOADS) + "/SozAtolyesi");
          Uri hedef = gorsel ? MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                             : MediaStore.Downloads.EXTERNAL_CONTENT_URI;
          Uri uri = getContentResolver().insert(hedef, cv);
          if (uri == null) return "HATA: kayıt oluşturulamadı";
          try (OutputStream os = getContentResolver().openOutputStream(uri)) { os.write(veri); }
        } else {
          File klasor = getExternalFilesDir(gorsel ? Environment.DIRECTORY_PICTURES : Environment.DIRECTORY_DOWNLOADS);
          try (FileOutputStream fos = new FileOutputStream(new File(klasor, ad))) { fos.write(veri); }
        }
        return "OK";
      } catch (Exception e) {
        return "HATA: " + e.getMessage();
      }
    }
  }
}
```

Notlar:
- Paket adı (`com.ornek.uygulama`) ve klasör adı (`SozAtolyesi`) projeye göre değiştirilir.
- Android 10 ve üstü için ek izin gerekmez. Android 9 ve altında dosyalar uygulama klasörüne yazılır; Galeri'de görünmesi isteniyorsa `WRITE_EXTERNAL_STORAGE` (maxSdkVersion=28) eklenir.
- Çok büyük dosyalarda (10 MB üstü) base64 tek parça yerine parçalı gönderilir.

## 5. Test listesi

- [ ] APK'da PNG, JPEG ve 3× boyutta kayıt çökmeden gerçekleşiyor
- [ ] Kaydedilen dosya Galeri'de görünüyor
- [ ] Köprü yokken (tarayıcıda) paylaşım veya normal indirme çalışıyor
- [ ] Paylaşım iptal edildiğinde uygulama donmuyor
- [ ] Kodda hiçbir yerde `a[download]` + `data:` kalmadı
