# google-workspace


---

## Dosya: `SKILL.md`

---
name: google-workspace
description: "Read this before the first Google Drive, Docs, Sheets or Slides connector call whenever the task creates or changes a Google file. Use this skill whenever the user wants to create or change a Google Doc, Sheet or Slides file in their Google Drive. Triggers include: a request that names Google Docs, Sheets, Slides or Drive and asks to make, edit, format, copy or rename a file; a docs.google.com link with a request to change that file, even a one-line fix or suggested edits; and any follow-up change to a Google file from earlier in the chat, even \"change it\" or \"add a tab\". Includes helper scripts for document positions, cell ranges and slide layout. However, if the user asks for a doc, deck or spreadsheet without naming Google, or gives a Google file only as source material for something new, use Claude's own output type instead. Do NOT use for read-only questions about a Google file, or for Word, Excel, PowerPoint or PDF files."
---

# Google Docs, Sheets, and Slides

The Google connectors are thin wrappers over Google's raw APIs, with almost no guidance of their own. This skill supplies that guidance: which connector does what, the rules that keep edits in the user's file, and, in one reference file per app, how each API really behaves. Most of the app-specific rules in the references were tested against Google's Docs, Sheets and Slides APIs; the rest were seen through the connectors, and a few have not been checked yet.

## Read the reference before you touch the file

| Working on | Read first | Why it matters |
|---|---|---|
| A Google Doc | `references/docs.md` | Docs edits address UTF-16 positions that shift after every insert and go stale after every write. Tabs and pending suggestions change the positions too. |
| A Google Sheet | `references/sheets.md` | Both write tools parse input like the Sheets UI, so text can silently become numbers or dates. Formatting needs numeric sheet IDs, 0-based ranges, and field masks without parentheses. |
| A Google Slides deck | `references/slides.md` | Positions are in EMU, an element's real size is its size times its scale, and an unmasked read can exceed 150 KB for three slides. Slides never shrinks text to fit. |

Read the reference for every app the task touches before the first edit. Embedding a Sheets chart in a deck means reading both. The references are short, and skipping one is how edits land in the wrong place.

## 1. Check the connectors before you start

| Connector | What it can do |
|---|---|
| Google Drive | Create files, upload and convert content, rename, read a file as text, export (PDF and other formats), search, trash |
| Google Docs | Read a doc's full structure and edit it in place, directly or as suggestions |
| Google Sheets | Read values and structure, write values and formulas, format, add tabs and charts |
| Google Slides | Read a deck, add and edit slides, shapes, text, tables, and linked charts |

Drive can create all three file types. It can't edit a file after that. Without the matching editor connector, every change means a new file and a new link, and the user loses the link they already have.

1. Check which Google tools are available in this conversation. On surfaces where tools are deferred, search for and load the tools you need first, such as "google sheets update". Tool names differ by surface, so use the names your surface lists. If a search returns nothing, list all available tools before deciding the connector is missing, because the tool may exist under a different name.
2. If the editor tools are missing, tell the user. When you can list the conversation's connectors, say which case it is: a connector that is set up but turned off in this chat (ask them to turn it on in the chat's connector settings, then continue), or one that isn't connected at all (tell them which connector to add and what it enables).
3. With an editor connector missing, a request to create a new file continues with Drive. A change to an existing file stops and asks. See the missing-connector rule in section 2.
4. If the user asks only for a new file, create it with Drive. If the editor connector is off, add one line saying edits will need it.

Example: "I can create the sheet now. If you want changes later, turn on the Google Sheets connector in this chat first. Then I can edit this file, and the link will stay the same."

## 2. Rules for every file

- **A change goes in the same file.** "Change", "update", "fix", "add", and "switch it to" all mean the user wants the same file and link. Do not recreate the file to skip an edit.
- **A missing editor connector is a choice for the user, not a workaround for you.** When the user asks for a change to an existing file and the editor connector is missing, your whole reply is a short question, not a deliverable. Building the next-best thing feels helpful, but the user's file is still untouched and now there are two artifacts, which is the exact failure this skill exists to prevent. Lead with the fix: name the connector and say that with it on, the edit lands in their existing file and the link stays the same. You may offer an alternative, such as drafted text to paste or a file to import by hand, but only as a named option, and build it only after the user picks it. Example reply, in full: "To add the slide to your deck directly, turn on the Google Slides connector in this chat and I'll do it. Same deck, same link. Or I can draft the slide as a file you'd import by hand. Which do you prefer?"
- **Never trash a file the user didn't ask you to delete.** Drive can trash a file, but it can't restore one. The Docs, Sheets, and Slides connectors can't open a trashed file.
- **Read before you edit, and guard the write.** Send every Docs and Slides batch with `writeControl.requiredRevisionId` set to the `revisionId` from a read taken after your last write, including batches built on IDs or positions from your own earlier writes. The only exception is a batch made entirely of `replaceAllText` requests, even one limited to some tabs or slides. If the file changed since that read, whether from your own write or someone else's, Google rejects the whole batch instead of applying it at stale positions or IDs. Read again before each guarded batch, and don't reuse a revision ID from a write reply. On a rejection, read again and rebuild; never drop the guard. `read_doc` and `read_presentation` (the mask in `references/slides.md` includes it) return the ID. `read_slide_page` returns it only if its mask includes `revisionId`; `read_slide_page_thumbnail` and Drive `read_file_content` never do. For a saved read, the first line of `docs_index.py outline` or `slides_helper.py outline` shows it; if that line says `None`, read again with `read_doc` or `read_presentation`. `get_spreadsheet` doesn't return a `revisionId`, even when `fields` names it: send Sheets writes without `writeControl`, and read again right before a write that depends on positions.
- **Put everything for one step in one batch.** Batch requests run in order and atomically: if one is invalid, none apply. One call per logical step is faster and leaves no half-finished state.
- **Sheets field masks.** Write each path in full, with no parentheses: one path per item in `get_spreadsheet`'s `fields` list (`["spreadsheetId", "sheets.properties"]`), and comma-separated in a batch update request's `fields` string (`"userEnteredFormat.numberFormat,userEnteredFormat.textFormat.bold"`).
- **Verify the result.** Read the file again after each edit and check the result before you report it. A tool accepting the call does not mean the content is correct. Each reference has a Verify section.
- **Rename with Drive `update_file`.** A rename keeps the same link.
- **Link every file you name.** When you name a Google file you created, copied, found, or edited, make its title a link, inside the sentence that says what you did: "I added the row to [Team roster](its link)." Don't set the file apart after a colon or on a line of its own ("I've created a file for you: Team roster"). If a Drive result says the user can already see or open a file from the chat, leave that file's link out unless they ask. Always give the link when the user asks for it, wants to send it to someone, or says they can't see or open the file, even if a result said they could. Don't tell the user to use a card or preview unless a result said one is shown. After an edit, say that the link stays the same.

## 3. Drive, for all three apps

- **Find a file:** use Drive search when the user names a file without a link. Confirm the match with the user if more than one file fits. A page can be short even when more files match (5 files at page size 20) and can repeat the previous page's last file, so follow the next-page token until none comes back, and drop repeated ids.
- **Create:** `create_file` with `contentMimeType` set to `application/vnd.google-apps.document`, `.spreadsheet`, or `.presentation` creates an empty file. Uploading content with a source type (HTML, CSV, .xlsx, .pptx) converts it into the matching Google type. Each reference says which route fits that app.
- **Read as text:** `read_file_content` returns a compact text rendering: Markdown for a Doc. It is a few KB where the editor connector's full read can be over 100 KB, so use it to understand content, then use the editor read when you need positions. For a Doc, pass `includeComments: true`; without it, emoji come out garbled and the end of the text is cut off. For a Sheet, read the data with `get_values`: Drive returns only a sample (the first rows, long values cut).
- **Export:** `download_file_content` with `exportMimeType: "application/pdf"` returns the rendered file as base64. It is large (about 65 KB of text for a four-slide deck), so export only for a visual check, and only where you can run code.

## 4. Helper scripts

The `scripts/` folder next to this file holds tested helpers. They turn the APIs' raw JSON into short readable summaries, and turn simple specs into correct request batches, so the error-prone arithmetic never happens by hand. Use them wherever you can run Python. Run them by their full path inside this skill's folder; the references write that folder as `<skill>`.

| Script | Commands | Used for |
|---|---|---|
| `docs_index.py` | `outline`, `find`, `new-table`, `fill-table` | Docs positions, text search with bold and suggestion state, adding a filled table in one call, filling an existing table |
| `sheets_helper.py` | `range`, `format`, `cells` | A1 ranges to grid ranges, formatting batches from a short spec, reading formulas and error cells |
| `slides_helper.py` | `outline`, `build` | Real slide geometry with overflow and overlap warnings, building slides from an inch-based spec |
| `render_export.py` | one command | Decoding a PDF export into page images to look at |

**Getting JSON to a script.** Large tool results are often saved to a file by the app, and the result tells you the path. Point the script at that path; the scripts read the file as the app saved it. When a result comes back in context and is small (a few KB, such as a masked read or sheet metadata), write it to a file and run the script on it. Don't re-type a large result into a file: that doubles the cost and invites copying errors. If a large result was cut off and not saved, read a smaller slice instead (a field mask, a range, or one tab) rather than guessing.

Every script prints `--help` with its full usage. Each reference shows the commands in context.

## 5. Common failures across apps

| Symptom | Cause | Fix |
|---|---|---|
| "No such tool available" | The tool is deferred, or the name is different on this surface | Search for and load the tool. Use the exact name your surface lists. |
| Permission denied on a file you created | The file is in the trash | Ask the user to restore it from Drive's trash. You can't restore it with the connectors. |
| 400: required revision ID does not match | The file changed after your read: your own previous write, or someone else editing | Read again, rebuild the requests from the new read, and send them with the new revision. For Sheets, send them without `writeControl`. |
| A whole batch failed on one bad request | Batches are atomic | Fix the named request and resend the full batch. Nothing from the failed call was applied. |
| A read is too large or cut off | Unmasked editor reads include everything | Use Drive `read_file_content` (not for a Sheet), a field mask, a range, or a single tab. Run the helper on a saved result. |
| Two files where the user expected one | An edit was done by creating a new file | Make changes in place with the editor connector. Tell the user about the extra file; don't trash it without asking. |

Each reference ends with the failures specific to that app.

## 6. What the connectors can't do

When a request runs into one of these, say so plainly and do the alternative. *Reported*: seen through the connectors or in their tool schemas. *Untested*: not yet checked.

- **Claude can't see the user's screen.** No connector shows what the user has selected, or which file, tab or slide they have open. If "this" or "here" isn't clear from the chat, ask which file, heading, slide number or cell range they mean. *Reported.*
- **Comments:** `read_doc` with `commentsIncluded: true` has returned each comment with its place in the text. If the result shows `COMMENTS_VIEW_MODE_OMITTED` instead, use Drive `read_file_content` with `includeComments: true`, or ask the user to paste them. `update_doc` has accepted `insertComment` in one report, although its description is cut before listing it; if that request fails, say you can't add comments and offer to list your notes in the reply. *Reported.*
- **Suggestion mode can be refused** with "Unsupported WriteControl mode". Never make direct edits in its place: offer to list the proposed changes or to edit directly (see `references/docs.md`). *Reported.*
- **Request lists are cut short.** The `update_doc`, `update_spreadsheet` and `update_presentation` descriptions stop partway through their request lists. Requests missing from the description, such as `addDocumentTab` and `addChart`, have still worked, so try one before deciding it isn't supported. *Reported.*
- **Uploads travel inside the call.** `create_file` takes the whole file as text or base64, so an .xlsx or .pptx upload is slow and often fails. Build in the file with the editor connectors where you can, and keep uploads small. *Reported.*
- **Images need a public URL.** Slides `createImage` and Docs `insertInlineImage` fetch the image from a URL Google can reach; a file from the chat can't be inserted this way. For a deck, offer the .pptx route; otherwise ask the user to insert the image. *Untested.*
- **A Slides chart must already exist in a Sheet.** Create it there with `addChart`, then embed it with `createSheetsChart`. *Reported.*
- **Drive search uses `title`, not `name`.** `name contains '…'` fails with "Unsupported query field: name"; write `title contains '…'`, and put the file type in a `mimeType` clause. *Reported.*
- **Slides edits may not show in an open deck right away.** If the user doesn't see a change, ask them to reload the deck before you change anything again. *Reported; may be fixed.*


---

## Dosya: `references/charts.md`

# Charts

Read the slide design rules in `references/slides.md` first; this file covers charts on slides. Assume each chart will be projected, printed or forwarded without you there to explain it, so everything the reader needs is on the chart.

## Choose the display

| The reader needs to... | Use |
| :---- | :---- |
| See one or two numbers | No chart: plain words in a bullet, or a big number, the figure set large ("15%") with a line of smaller text under it saying what it is ("revenue growth last quarter"). Clearer than a one-bar chart or a two-slice pie |
| Compare magnitudes across categories | Bar chart: vertical columns by default, horizontal bars when the category names are long |
| See a trend, or anything else where the points are connected | Line: for time series and other connected data, never for categories; add error bars or a shaded range when the spread matters alongside an average |
| See how a few items moved between two points | Slope graph with no gridlines or value axis (say, education rate by region, 2015 against 2025), not a multi-series bar chart. Few lines, the one that moved most in the accent color; the start value alone on the left, the end value and the name once on the right |
| See one series against context | That series in the accent color, everything else gray |
| See parts of a whole | Stacked column: absolute to compare totals and their components, 100% to compare mix. Stacks get overwhelming fast; they show the gist, not precise comparisons of middle segments |
| Compare an ordered scale across categories (Likert responses) | 100% stacked horizontal bar: consistent baselines at the far left and far right |
| Follow a starting point, the changes, and the result | Waterfall: breaks a complicated calculation into pieces |
| See share on two dimensions at once (segment size and the mix within it) | Mekko |
| See a schedule | Gantt |
| See the relationship between two quantities | Scatterplot: mostly for samples and studies; fine in business when there is a real relationship to show |
| See data that normal charts don't accommodate | Shapes as illustration: a funnel, a grid of squares, an illustrative bar, when the data doesn't fit a chart and exact units don't matter, as long as it is obviously not to scale |

- Avoid unless the user explicitly asks: pie and donut charts (people judge angles badly; use a sorted bar chart instead); area charts (hard to read; the one exception is the square-area graph, where each square's area is a quantity, useful for very different magnitudes such as TAM, SAM and SOM); 3D; and secondary axes (the alignment of two scales is arbitrary and invents a correlation; label the units on each line, stack two charts on the same horizontal axis, or index both series to a common base).
- One to three colored series read clearly; at four or more, label each series directly even if the deck's charts use a legend; five or six is the most one chart can hold. Past that, combine the smallest into "Other", or use small multiples (a grid of small identical charts on shared scales). Never fix "too many series" by adding colors.

Combinations are sometimes right, such as a stacked bar with one segment broken out beside it (in a chart, a small table or a text box) when the audience will want that detail.

## Which standard the chart follows

If the deck already contains charts and they share a consistent style (axis treatment, gridlines, legend or direct labels, label placement, whether the title sits inside the chart or above it, fonts, colors), that is the standard, and every new chart follows it, even where it differs from the master's theme. Charts that disagree with each other are not a standard. Otherwise follow the house standard below.

Under a deck standard, the deck's charts decide everything the house standard decides, including where the title sits and how it is worded. Where you cannot reproduce their style directly, copy one of the deck's charts and replace its data and labels, which is the surest way to get an identical look.

## The house standard

- **No legend**, except where Series names (Finishing touches) allows one.
- **Bar and column charts:** no gridlines and no value axis; every bar carries its value, and the category axis names the bars. Keep a thin gray category axis line (about #BFBFBF), so the bars don't float.
- **Line charts:** faint horizontal gridlines at four or five round values, so the reader can read values across (faint means close to the background: light gray on a white slide, a dark gray just off black on a dark one); value-axis labels in a muted color that carry the unit ("$0B", "$25B"), with no axis line; no vertical gridlines. A small marker on each labeled point and none on the others, since markers on every point clutter a long line. Lines run straight from point to point, never smoothed.
- **Scatter charts:** no gridlines; both value axes, four or five ticks at round numbers, bare numbers in a muted color.
- **One accent color** for the point that is the message, gray for everything else. Use the deck's accent: the theme's first accent color, the accent the deck's finished slides use, or the accent you chose when setting up a new deck. Use this fallback palette only when the deck has no accent of its own (default theme, and no finished slide uses one), so decks for different companies don't share a look: accent #1A6BB8, bars #BFBFBF, lines #A6A6A6, text #1A1A1A, secondary text #595959.
- **Transparent background.** The chart area and the plot area have no fill and no border, so the chart sits on the slide background.
- **Units in the number format.** Every data label on a bar or column carries its unit ("$42M", "38%", "12K"); only a plain count such as 355 goes bare. On stacked columns only the column total carries the unit ("$40.5M"); the segments are bare numbers (18.2, 12.5, 9.8), and the total sits above each stack.
- **Bar proportions.** The gap between bars is 50% of a bar's width, so bars are twice as wide as the gaps. On stacked bars, set the series overlap to 100% so the segments stack on one bar.
- **Headroom.** Set the value axis maximum about 15% above the tallest bar, so labels above the bars fit; about 25% when totals or growth arrows sit above the bars.
- **Sorting.** Horizontal bars are sorted with the largest at the top.
- **Likert and other ordered scales** are tints of the one accent, darkest at the top of the scale (such as "Strongly agree") and lightest at the bottom, never a red-to-green ramp. This overrides the two-hue rule for values above and below a baseline in Finishing touches.
- **Waterfalls.** The start and end totals are dark gray, increases are the accent, and decreases are one contrasting warm color, such as orange #E07B39. Each step is labeled with its signed change, and the totals carry the unit.
- **Text.** Axis and data labels are 14pt in the deck's body font; the year row and callouts are smaller (Finishing touches). Text set in a series color (line names, callouts) uses the secondary text color when that series is a light gray.

## The chart label

The story is in the slide title (or in the slide's commentary when the deck uses label titles), never in the chart. A story title states the takeaway as a full sentence with the number ("Sales grew every quarter for two years and finished 2025 at $12.4M"). The chart carries a descriptive label only, with these parts in this order, separated by commas: what is plotted, the scope if there is one, the unit, the timeframe.

- The unit is a short token, never spelled out. Currency scale letters follow the deck's own convention when it has one, otherwise the deck's language: $K, $M and $B for US English (also the default when the language is unclear), £k, £m and £bn for UK English, and so on. Do not mix conventions in one deck.
- Parentheses hold only a second unit or a data basis, never the primary unit.
- What is plotted always stays.
- Drop the timeframe when the axis shows the year, in the tick labels ("FY22") or on a year row. Keep it when the axis shows only bare periods ("Q1", "Jan"), as on a single-year chart, so the year appears somewhere on the slide.
- The unit is on every data label of a bar or column chart and on the value-axis labels of a line chart, so it drops out of the chart label for both. On stacked columns the totals carry it. On scatter charts the axes show bare numbers, so the unit stays in the label.
- Decide at the first chart which parts this deck's labels carry (scope, unit, timeframe), and apply that and the drop rules the same way on every chart, checking the earlier labels before each new one. Half the charts labeled "$M, FY25" and half not looks careless.
- Never in the label: the takeaway, a figure (a growth rate, total or change goes in the slide title, a data label, a growth arrow or a callout), a colon or a dash between parts, a spelled-out unit.

Examples:

- Column chart, bars labeled "$42M", x-axis "Q1 … Q4 | Q1 … Q4" with "2024" and "2025" on a year row → **"Quarterly revenue"**, not "Quarterly revenue, $M, Q1 2024–Q4 2025".
- Column chart, bars labeled "$42M", x-axis "Q1 … Q4" (one year, no year row) → **"Quarterly revenue, FY25"**: the timeframe stays because the axis has none.
- Line chart, axis labels "0K … 250K", x-axis "Jan … Dec | Jan … Jun" with "2025" and "2026" on a year row → **"Monthly active users"**: the axis carries the unit and the year row the timeframe.
- Column chart with growth arrows, bars labeled "$42M", growth labels "+21%" → **"Quarterly revenue, FY25 (% growth QoQ)"**: a second unit goes in parentheses at the end.
- Bar chart of segment shares, bars labeled "58%" → **"Regional share of revenue, FY25 (based on reported segments)"**: a data basis goes in parentheses.

The label is a text box in the slide's caption style directly above the chart, so its typography matches the slide; the chart's own built-in title stays off. Line the label's first character up with the slide title's: the same left position and the same left text inset (internal padding). A title placeholder usually has a nonzero inset from the master and a new text box has an inset of 0.1 in (7.2pt), so copy the title's inset rather than setting zero. Keep the label to one line when the subject is short. When the subject runs to about six words or more ("Quarterly sales by department, Product X"), put the unit and timeframe on a second line about two points smaller and muted ("FY25", or "$M, FY25" where the label keeps the unit) rather than letting the label wrap or run into the chart. A slide with two or more charts gives each its own descriptive label, and the slide title carries the message they make together.

## Placing the chart

- A chart on its own takes the whole content area: the full content width (the title's left edge to its right edge), from just under the title to just above the footnotes. The common mistake is a chart that stops halfway down the slide, not one that is too big.
- Small multiples: no panel shorter than about 120pt, or the labels have nowhere to go. Share one scale across the panels only when the comparison is about magnitude; when a shared scale flattens the smaller panels into a line, give each panel its own scale and say so in the caption.

## Finishing touches

Once the chart exists, adjust it so the message is visible:

- **Color does one job per chart.** A second accent is a second message; if two things matter, make two charts. Use distinct hues only when telling the series apart is the point, and then the same hue for the same entity on every chart in the deck. Use a single hue from light to dark for magnitude, and two opposed hues around gray for above and below a baseline. Never a rainbow, and never color as the only carrier of a distinction (red and green least of all): a label or position always backs it up.
- **Source line** below the chart, at footnote size (10–12pt, muted), following "Footnotes and sources" in `references/slides.md`, including citing only sources you have.
- **Period axes.** Tick labels show only the short period (Q1 … Q4, Jan … Dec). The year sits on a second row under each year's first period, at 11pt in the secondary text color, and is not repeated on the other ticks; "Q1 FY25, Q2 FY25, …" on every tick is the defect to avoid. A linked Sheets chart has no tested way to draw it, so put small text boxes under the axis. A single-year chart has no year row and carries the year in its label.
- **Series names.** Give each line a short name, one or two words ("Data center"), in its series color, right of its last point on the same line as the end value ("$89.0B Data center"), with room left on the right of the plot. On a chart of three lines or fewer other than a slope graph, there are two exceptions: when the deck standard uses a legend, use the deck's legend; otherwise a name longer than about 14 characters gets a small legend instead of a wrapped end label. With four or more lines, or on a slope graph, shorten long names instead. A chart with two or more lines is not done until every line is named on the chart, by an end label or a legend.
- **Point labels on a line:** the start, the end, and the peak, trough or break the title or bullets refer to. Three labels on a ten-point line is right; more than four is crowding, and the first and last alone are too few for a long line. Each label except the end label sits above or below its point, off the line.
- **Annotate the conclusion:** a shaded band over the downturn, or a callout when Callouts below calls for one. Where actuals turn into a projection, mark the boundary so nobody reads the forecast as history: on a line, the forecast portion is dashed; on columns, forecast bars are hatched or a visibly lighter fill, and their category labels carry an E suffix ("2026E", "Q3E"). A short label at the boundary ("Actual" | "Forecast") helps when the deck will be read on its own.
- **Growth arrows** show growth or decline where it is significant, not between every pair of bars. The default is an elbow: up from one bar, across at a height that clears the bars between and their labels, and down onto the other. A straight line from one bar top to the next works only between adjacent bars with room above them. The third shape is a difference marker (a short horizontal mark at each bar top and a vertical line between the two levels with the change on it). Whichever shape, the change number sits centered on the arrow (on an elbow, on its horizontal part), in front of it, on a fill matching the slide background. Growth arrows and CAGR brackets are shapes drawn over the chart, never chart elements; position them from the chart's geometry.
- **Callouts:** when the slide title or commentary claims a change in trajectory (an acceleration, a break, a launch, a one-off), put a callout naming the cause at the point where it happens, on the chart rather than only suggested in your reply. If nothing you were given names the cause, ask, or leave the callout out; never guess one. Otherwise most charts need none. At most one, occasionally two; more than that is clutter, and the explanation belongs in a text block beside the chart instead. The callout is a short phrase ("Supply chain outage", "Product X launch"), never a full sentence, at 11–12pt in the color of the series it annotates, with no box, border or fill, and a thin leader line in the same color from the text to the point. Place the text in the nearest open area of the plot, never over a bar, the line, or a data label.


---

## Dosya: `references/docs.md`

# Google Docs reference

As a first step, before you create a Google Doc or change one, you must read the design rules below in full: how a document should look and read, and how to edit one. After them, "Applying the design rules" says how to carry out the rules with these tools, and the rest of the file covers the Docs connector's `read_doc` and `update_doc` and the Drive tools that help with Docs.

# Document design

When the user asks for something specific, such as a font, a color, a length or a structure, do that; these rules decide what the user left open. The rules for the text itself are under Writing, and the rules for changing a document that already exists are under Editing an existing document.

## Structure

- **Plan the sections before you write, and merge any two that answer the same question in different words.** If the user asked for a set number of sections, replace the merged one with a section that covers something new.
- **Each section appears once.** Before you finish, read the headings in order and check that none is repeated.
- **An executive summary opens with the conclusion.** Its first paragraph states what the reader should believe or do. Numbers belong in the body sections, where they support the conclusion; they are not the conclusion. "$1.2B total debt across 7 instruments, weighted-average coupon 4.8%" is data. "Refinancing risk is concentrated in 2027. We recommend an opportunistic tender for the 2027 notes given the current cash position" is a conclusion. A summary that is only a list of numbers has not stated a conclusion.
- **A length the user gave is a limit.** "Three pages", "one page" or "500 words" is a hard constraint: check it before you finish and cut if you are over. Five pages for a three-page request is a defect, not thoroughness. Count the pages in the rendered document; without a render, estimate about 3,000 characters per page.
- **Limits still apply after the first request.** A length or a set of sources the user gave at the start still holds when a later request doesn't repeat it.
- **Numbers and quotes taken from a source match the source.** Take every figure, quote and page reference from a part of the source you have actually read, not from memory. If you can't find a value, say so instead of estimating it.

## Styles

The look of a document comes from its styles: the Normal text style for body text and the built-in heading styles for headings. Formatting set directly on individual paragraphs carries over into the text added after them and spreads across a long document.

- **Set the body font once, for the whole body**, not on each paragraph or run. A font set paragraph by paragraph misses the paragraphs added later, and the document ends up in two fonts.
- **Headings use the heading styles.** Never make a heading out of bold, larger body text: it is missing from the table of contents and the outline, and its formatting carries over into the next paragraph.
- **Don't resize a single heading.** Each heading level already has its own size, and an override on one paragraph can make a subsection look like a section. If a heading is at the wrong level, change its level. If every heading at one level should be smaller, change that heading style. Don't move a correctly placed heading to a lower level only to make it smaller.
- **New content of the same kind takes the style around it; new content of a different kind does not.** A clause added next to other clauses gets their style. A table or a body paragraph added right after a list item or a heading gets the Normal text style, without the heading's bold. Otherwise the table cells get list markers and the body text comes out bold or as a heading.
- **Color goes on a phrase, not on a section.** One sentence in red is emphasis. Three paragraphs in red is too much, and the reader stops reading the color as a signal. If you want to color more than one paragraph, you need a heading or a callout box instead. Color the words themselves, not the whole paragraph, so the color doesn't carry over into the next paragraph.

## Fonts

- **New legal documents use Times New Roman.** When you draft a contract, brief, motion, legal memo or legal letter from scratch, with no template, set the body in Times New Roman. It is the professional default in legal practice, and other fonts read as informal. This doesn't apply when the document already has content (use its body font), when a template sets the font, or when the user names a font.

## Lists and numbering

- **Never type list markers or section numbers** in a new document, or in a list or heading the document numbers automatically. In those, don't write "•", "-", "*", "1.", "3.2" or "(a)" as text; use the document's list and heading numbering. Typed markers look right until someone inserts an item or a section above them, and then the numbers are wrong.
- **List items directly next to each other with the same list style join one list.** Numbering can also continue across a paragraph between two lists, so when a second numbered list should start again at 1, check that it does.

## Tables

- **Match the existing tables.** When the document already has tables, give a new one the same borders, fills and header row. One table with a colored header among three plain ones looks like a mistake.

## Page layout

- **Leave the page setup as it is unless the user asks**, and in a pageless document skip the rules below about pages and columns. "Applying the design rules" says how to recognize one.
- **Keep each heading on the same page as the paragraph after it.** A heading alone at the bottom of a page reads as broken even when the content is right. In a document you create, set "keep with next" on the heading styles, so it applies to every heading; in an existing document, do it when you find a heading separated from its paragraph.
- **To keep a section on one page, such as a financial statement, start it on a new page with one page break before its heading.** Check for an existing break first: a second one only adds a blank page. If the section still splits with a break in front of it, it is longer than a page; say so instead of adding another break.
- **When a table is longer than a page, stop its rows from breaking across pages**, so that each row is whole on one page.
- **Page numbers are fields, not typed text.** "Page 1" typed into a footer reads 1 on every page.
- **Headers and footers can have variants.** If the document has a different first-page header, or different headers on odd and even pages, each one is separate: change every one that applies.
- **Columns belong to a section, not to a paragraph style.** To set part of a document in two columns, give that part its own section.
- **Use real footnotes, not [1] markers typed into the text.**

## Check the result

Look at the rendered pages, not only the text. Assume there are formatting problems and look for them:

- **Fonts:** a paragraph in a different font from the rest, or a size change in the middle of a section.
- **Styles:** added text that looks like plain body text where the paragraphs around it are headings or styled body text.
- **Numbering:** a list item that lost its marker, or (a) (b) that restarted as (1) (2).
- **Tables:** columns that changed width, or cells that wrap where they didn't before.
- **Formatting that runs on:** bold or italic that continues past where it should stop.
- **Spacing:** double blank lines, a paragraph pressed against the one above it, uneven indents. In a doc that started blank, blocks added with Docs edit requests touch unless you set the space between them; the "Add space between blocks" recipe says how.
- **Suggestions:** insertions and deletions that render garbled or overlap the normal text.
- **Page breaks:** a heading alone at the bottom of a page, a blank page, a section that used to fit on one page and now splits.

After you fix one problem, check the paragraphs and pages around it. A fix to one paragraph often changes the next one, and a change in length moves the page breaks.

## Writing

Text you write in a document should read as though a person wrote it. When readers think something was written by AI, they judge it as sloppy and stop trusting it, whatever the content. They make that judgment from a set of common indicators, listed below, so take extra care to keep them out of your writing. These rules are for text you write, and a style the user or their style guide asks for takes priority. Do not rewrite the user's existing text to follow them unless the user asks you to.

- Say what is true without first denying something else. "Revenue grew 12%, three times the US rate," not "This isn't a growth story, it's a market-share story." Do not open a paragraph or bullet with "Here's the thing" or "The real story is".
- Match the number of bullets, examples, and adjectives to the content, not to a default of three. Two drivers get two bullets; five get five. A list of exactly three ("fast, reliable, and scalable") usually means the third item was added for rhythm, not because there were three things to say, and readers read it as filler.
- Do not use a metaphor where a literal word will do. If a plain description exists ("the same construction," "the same pattern," "slowed," "fell"), use it. Metaphors are for when the literal version would be longer or less precise, which is rare in analytical writing. Test: if the metaphor can be replaced by a plain word without losing meaning, replace it. A metaphor makes the reader translate it back into the plain claim and carries meaning you did not choose. The ones that appear most are "north star", "move the needle", "double-click" (meaning look closer), "unpack", "journey", and "landscape" (meaning a market). Common ones in business writing: "moat", "headwind", "drag" (meaning a cost on results), "safety net", "clears the bar", and "land" meaning finish or total ("lands $4.4k under budget"). Examples:
  - Bad: "The ones it has are the same species." Good: "The ones it has follow the same pattern."
  - Bad: "A coordinated digestion pause would be visible immediately." Good: "If several large customers cut capex in the same quarter, it would show up in the next guide."
  - Bad: "Architecture transitions compressed margin on the way in and expanded it on the way out." Good: "Gross margin fell during the Hopper-to-Blackwell ramp and recovered once Blackwell shipped at volume."
  - Bad: "The lever that unlocks growth." Good: "The pricing change is what makes the target reachable."
- Cut words that claim importance without giving evidence: "genuinely", "truly", "actually", "clearly", "significantly", "robust", "leverage", "delve", "actionable insights", "learnings". Where one of them stood in for a fact, put the fact there ("margins fell 4 points", not "margins fell significantly"); otherwise delete it. When "leverage" or "significant" carries its financial or statistical meaning ("net leverage", "statistically significant"), it is a literal term; keep it.
- Use full stops and commas, and a colon before a list. No emoji in the document.
- Use em dashes sparingly: at most one in a paragraph, and none in a heading, a title, or between a bold label and the text after it. Several em dashes in one paragraph is one of the first things readers use to spot machine writing. In place of one, use a comma, a colon, parentheses, or a new sentence, not an en dash or a spaced hyphen.
- Headings in the document are about the content, not about your process: "Europe missed plan by $1.9M" or "Pricing", not "What I changed" or "The hard part". Standard labels such as "Executive Summary" or "Next steps" are fine. When the document already has headings, phrase new ones the same way, for example as short labels or as full sentences.
- Keep the conversation out of the document. When the user asks for a shorter or more formal version, make it shorter or more formal; do not title it "Executive Summary (Condensed)" or open it with "Updated per your feedback". The document's readers did not see the request, so those lines mean nothing to them. Say what changed in your reply, not in the document. This covers the document's text, not replies in comment threads.

## Editing an existing document

These rules apply whenever you change a document that already exists. Everything you add also follows the rules above.

### Change only what was asked

- **Match the scope of the edit to the request.** "Fill in this section" means add text. It doesn't mean also changing the alignment, adding underlining, reformatting tables or restyling nearby paragraphs. If a check shows a formatting change you didn't intend, undo it.
- **Change the smallest range that covers the change.** Replace the words that change, not the paragraph or section around them. Never delete and rebuild a paragraph, a section or the document to change part of it: that loses comments, bookmarks, images, charts and other embedded objects.
- **Keep the original wording wherever you aren't deliberately changing it.** Rewording the user didn't ask for is one more change they have to find and review. In a contract it is a substantive change: "aggregate" becoming "total", or "shall not" becoming "will not", changes what the text says.
- **Reformat by role.** "Make the body text 11pt" means the body text, not the headings; "indent the section headers" means the headings. Pick out the paragraphs by their style before you change them.
- **Take target values from the document, not from a guess.** If one table's header row is wrong and three others are right, copy the values from a correct one. When the user points at a reference ("make it look like section 3"), read that section's exact style, font, size, color, alignment and line spacing, and apply those. A guessed 18pt in a document built at 11pt is worse than the original problem.
- **Keep similar tables consistent, but only when the user asked you to reformat tables.** When the user asks you to reformat one of several similar tables, make the same change to the others or tell the user you changed only the one.
- **A table that changed as a side effect of another edit is a mistake to undo**, not a change to copy to the other tables.
- **Never replace a bare number across the whole document.** Closing a gap in section numbers by replacing every "7" with "6" also changes a "7.1x" interest coverage, a "7.5%" coupon and "FY2027". Renumber the headings one at a time.

### Match what is there

- **Text you add uses the document's body font and style**, not the editor's default. After you insert text, check its font and size against the paragraph before it.
- **Use the document's spelling variety**, for example British or American English. Keep new text in the variety the document already uses, never mix varieties in one document, and don't change existing text to another variety unless the user asks. If the document has no text yet, follow the variety of the user's messages.
- **Set explicit colors from the document.** If you must set a text color, copy it from an existing body paragraph instead of assuming black: many document styles use a dark gray or a theme color.
- **New numbered headings get their number from the document.** When the document numbers its headings automatically, write the heading text without a number and give the heading the same style or list level as the headings next to it, so it takes the next number. If the document numbers its headings by hand, follow that convention instead.
- **New list items continue the list.** Add an item as part of the list it belongs to, and check that it took the next marker: (b) after (a), not a second (a) or a skipped letter.
- **Making headings consistent.** When the user asks for all the headings to match, first give any hand-formatted heading (bold, larger body text) the right heading style. Then set each level to the font of its own heading style, one level at a time; applying the first level's font to every level removes the difference between levels. Applying a heading style doesn't remove a size or color set directly on the text, so clear those as well.

### Things inside the text

Some elements sit inside a paragraph's text without looking like separate objects: footnote marks, chips (such as a person, date or file chip), bookmark boundaries, comment anchors, and inline images and charts. Replacing or deleting a range that contains one removes it: the footnote is gone, the chip is deleted, the bookmark moves, the chart disappears.

- **Before you edit a sentence, check what is inside it**, and change the text on either side of such an element rather than through it.
- **A paragraph with no visible text can still hold an image or a chart**, and a floating shape is anchored to a paragraph. Deleting the paragraph deletes them, so check before you delete an empty-looking paragraph.
- **In a section set in columns, edit the text inside the section.** Don't remove the section break that holds the column setting.

### Templates

- **Fill the placeholders and keep the structure.** Never delete an image placeholder or a signature line while filling a template; removing one breaks the template for the next person who uses it.
- **Find every placeholder before you fill any.** Templates often use typed markers such as [CLIENT NAME]. If a template has none, find each section by its heading and write after it.

### Comments

- **Reply in the thread.** When you respond to a comment, reply to it; don't start a new comment. If your tool can't reply to comments, give the user the reply text to paste into each thread.
- **One thread per topic.** Before you add a comment, look for an existing thread on the same text or topic, including one you left earlier, and reply there. Several comments stacked on one paragraph make it unclear which note is current.
- **Leave comments where they are.** Don't delete or resolve a comment unless the user asks. Reply once per comment; don't add a second reply that says nothing new.
- **When you edit commented text, change words inside the commented range, not all of it.** A comment is attached to its text, and replacing all of that text deletes the comment and its replies. Make the edit first and reply after it, so that no reply describes an edit that didn't happen.
- **"Address the comments" means every comment.** Handle each one: make the edit it asks for, if any, reply with a one-line note, and leave the thread open unless the user asks you to resolve it.

### Suggestions

- **Use real suggestions**, never strikethrough and colored text made to look like them. The reviewer needs to accept or reject each change.
- **Don't accept or reject changes, or delete comments, to clean up.** In a review, the suggestions and comment threads are the work product: accepting them erases the record of what changed, and deleting comments erases the reviewers' notes. "Clean up the document" means fix the formatting. Accept, reject or delete only the ones the user names.
- **Mark only the words that change.** A paragraph replaced as a whole shows as the whole paragraph deleted and inserted again, and the reviewer can't see what changed. Replace only the words that change, and make several small changes in one paragraph as separate edits. To change a cap from twelve months to six, the change is "twelve (12)" to "six (6)", not the sentence it sits in.

### After structural changes

- **Keep the table of contents current.** After you add, remove or rename a heading in a document that has a table of contents, update it in the same step: a table of contents that lists "Section 4: Risk Factors" when section 4 is now "Liquidity" is a visible defect. Update an existing one; don't add one the document doesn't have unless the user asks for it. If your tool can't update it, tell the user it needs updating.
- **Remove everything in a section you delete.** Deleting a section's paragraphs can leave its table or images behind. Count the tables before and after, and check the count dropped by the number you removed.
- **Before removing a duplicate section, read both copies.** Keep the one whose formatting matches the rest of the document, and tell the user which one you kept and why.
- **Clear what deletions leave behind:** empty tables, two or more blank paragraphs in a row (collapse them to one), list items cut off from their list, and blank paragraphs at the end that push an empty last page.

### Check your edits

After each edit, read back what you changed: the text, its style, its font and any list marker. After an edit that can move the layout, such as added or removed content, a table or formatting change, or a fix to something that looked wrong, also check the rendered pages, including the pages around the change, against the list under Check the result above.

# Docs and Drive tools

## Applying the design rules

Some of the design rules above act on a named style (Normal text, Heading 1 to 6) or on a page-number field, and the Docs API can apply a named style but not change one, and can't insert a page number. Others depend on the page setup. Do this instead:

- **Body font, such as Times New Roman for a new legal draft:** set it once over the whole body with `updateTextStyle` (`weightedFontFamily`, `fields: "weightedFontFamily"`) after the text is in, and give text you add later the same font.
- **Keep each heading with the next paragraph:** set `keepWithNext: true` on each heading paragraph with `updateParagraphStyle` (`fields: "keepWithNext"`).
- **Make every heading at one level smaller or larger:** tell the user they can resize one heading at that level and then choose Format > Paragraph styles > Heading N > Update 'Heading N' to match, which changes the style itself. If they want you to do it instead, set the same size on every heading at that level in one batch.
- **Page numbers:** tell the user to add them with Insert > Page numbers.
- **Whether a tab is pageless:** in the `read_doc` result, check the tab you are editing. It is pageless when `documentFormat.documentMode` is `PAGELESS` in its `documentTab.documentStyle`, or in the top-level `documentStyle` when there is no `tabs` key. In a pageless tab, don't add page numbers, headers, footers or columns; tell the user to switch it to pages first, with Format > Switch to Pages format.
- **Page setup, when the user asks for a change:** send `updateDocumentStyle` with `tabId` on the request itself (it has no location or range), the new values in `documentStyle`, and only those field names in `fields`, without the `documentStyle.` prefix: `{"updateDocumentStyle": {"tabId": "t.0", "documentStyle": {"marginTop": {"magnitude": 54, "unit": "PT"}}, "fields": "marginTop"}}`. A field named in `fields` but missing from `documentStyle` is cleared, so never use `*`, which names every field.

These are based on the Docs API reference and have not been tested through the connector.

## Create

Call Drive `create_file` with `contentMimeType: "text/html"` and the document as `textContent`. Drive converts `<h1>`, `<h2>`, `<p>`, `<ul>`, `<ol>`, `<b>`, `<i>`, and `<a>` into native Docs formatting. This is much faster and less error-prone than building a new doc with Docs edit requests. Use the Docs connector for changes after that. For a Word file the user will download rather than edit in Google Docs, use the `docx` skill instead.

## How a doc is addressed

Every Docs edit points at a position, so the model of positions matters more than anything else in this section.

- **Indexes are UTF-16 code units** counted from the start of a tab's body, which starts at index 1. A character outside the Basic Multilingual Plane, such as 🙂, counts as 2, and an emoji built from several characters counts as more: 👍🏽 (👍 plus a skin tone) is 4. Docs refuses an insert inside an emoji with "The insertion index cannot be within a grapheme cluster", and a delete through the middle of 🙂 with "Invalid deletion range". Every paragraph ends with a newline that occupies one index.
- **Every insert or delete shifts everything after it.** Requests in one `update_doc` call run in order, so an index computed from the read is only valid for the first request that touches that region. Order the requests from the highest index to the lowest, and no request moves a position a later request relies on.
- **Indexes go stale after any write.** Never reuse indexes from a read taken before your last write. Read again, then compute.
- **Guard every batch with the revision, unless it is only `replaceAllText`.** Pass the `revisionId` from a read taken after your last write as `writeControl.requiredRevisionId`. If someone edited the doc in between, the whole batch is rejected with a 400 instead of landing in the wrong place. On that error, read again and recompute. Do not retry without the guard.
- **Tabs are separate index spaces.** A doc can have several tabs, and child tabs under them. Every `location` and `range` takes a `tabId`; without it, the request applies to the first tab, which is a silent failure when the user meant another one. A pasted URL like `.../edit?tab=t.abc123` names the tab: `t.abc123` is the `tabId`. `replaceAllText` is the opposite: without `tabsCriteria` it changes every tab, child tabs included, and naming a parent tab in `tabsCriteria` does not include its child tabs.
- **Pending suggestions are in the index space.** `read_doc` returns suggested insertions and deletions inline, as text runs that carry `suggestedInsertionIds` or `suggestedDeletionIds`, and they occupy real indexes. Don't treat a suggested deletion as live text, and don't insert inside one.
- **The body's final newline can't be deleted.** To append, insert at the last element's `endIndex - 1`.

## Read

There are two reads, and they serve different purposes.

- **Drive `read_file_content`** returns the doc as Markdown: headings, tables, and bold, typically a few KB. Use it first to understand what the doc says and to find the text you'll anchor on. Pass `includeComments: true`; without it, emoji come out garbled and the end of the text is cut off. With it, commented text sits inside `<comment_start id=…>` and `<comment_end id=…>` tags whose id matches a listed comment; keep the tags out of find text. It is not the index space: it escapes Markdown characters, and it glues pending suggestions to the text around them. Never compute an index from it.
- **Docs `read_doc`** returns the full `documents.get` JSON: every element with its `startIndex` and `endIndex`, every style, the `revisionId`, and the tabs. Use it when an edit needs indexes. It is large: a two-page doc with one table can exceed 100 KB. Pass `commentsIncluded: true` only when you need comments; it has returned each comment with its place in the text. If the result shows `COMMENTS_VIEW_MODE_OMITTED` instead, read them with Drive `read_file_content` and `includeComments: true`, or ask the user to paste the ones they want handled.

Where the content lives in the `read_doc` JSON:

```
revisionId
tabs[].tabProperties.tabId
tabs[].documentTab.body.content[]          body elements, in order
  .paragraph.elements[].textRun.content    text, with startIndex / endIndex on the element
  .paragraph.paragraphStyle.namedStyleType HEADING_1, NORMAL_TEXT, ...
  .table.tableRows[].tableCells[].content[]  each cell holds its own paragraphs
tabs[].childTabs[]                          nested tabs, same shape
```

If the doc has no `tabs` key, the body is at the top level: `body.content[]`.

### Use the helper script for positions

`scripts/docs_index.py` (in this skill's folder) reads the `read_doc` JSON from a file and prints only what an edit needs. Where you can run code, use it rather than walking the JSON by eye. That walk is where index errors come from.

- A large `read_doc` result may be saved to a file, and the result then gives the path. Run the script on that path.
- If the JSON came back in context and the doc is small, read the positions from it directly.
- If the read was cut off and not saved anywhere, don't guess positions. Use `replaceAllText`, which needs none, when the find text matches only the text you mean to change (add neighboring words until it does), or tell the user the doc is too large to edit by position here.

Commands:

```
python <skill>/scripts/docs_index.py outline DOC.json
    one line per element: index range, style, table cell position, text.
    Pending suggestions show as [+inserted] / [-deleted].
    Ends with the body end index for appends.
python <skill>/scripts/docs_index.py find DOC.json "exact text"
    index range of every match within one paragraph, whether it is bold, and whether it sits
    in a pending suggestion. A match can't cross a non-text element, such as a chip, image or footnote mark.
python <skill>/scripts/docs_index.py fill-table DOC.json --table N --data rows.json [--bold-header]
    the full update_doc arguments (requests + writeControl) to fill empty table N, the
    TABLE #N that outline prints (every tab and nested table is counted), from a JSON list of rows.
python <skill>/scripts/docs_index.py new-table --at I --data rows.json --revision REV [--tab T] [--bold-header]
    the full update_doc arguments to insert a table at I, the endIndex - 1 of the paragraph
    it goes after, and fill it in the same call. Needs no DOC.json.
```

outline and find print the `revisionId` and the tab ID; fill-table puts the `revisionId` in its `writeControl`.

## Edit recipes

Each recipe is one `update_doc` call. Add `tabId` to every `location` and `range` when the doc has more than one tab, and add `writeControl: {"requiredRevisionId": ...}` to every call except one made only of `replaceAllText` requests. Put real newlines in inserted text, not an escaped `\n`.

**Change a word or phrase.** `replaceAllText` needs no read and no indexes:

```json
{"replaceAllText": {"containsText": {"text": "Q3 launch", "matchCase": true},
  "replaceText": "Q4 launch", "tabsCriteria": {"tabIds": ["t.0"]}}}
```

The reply reports `occurrencesChanged`. Zero means the text didn't match exactly: check it against `read_file_content`, but remember that file escapes characters like `&` and `*`. The replacement takes the style of the first character it replaces, so replacing a span that starts in bold makes the whole replacement bold. If that matters, start the find on an unstyled character, or check the result with `find` afterward. It changes every match in the tabs it covers (every tab unless `tabsCriteria` names some), so use it when every match should change, such as a date or a name the user wants changed throughout. When only one occurrence should change, or the find text is short enough to occur inside unrelated text (a bare number such as "7", a common word), delete and insert at the range `find` gives for that occurrence. Never put a paragraph's trailing newline in the find text: the replaced paragraph can take the next paragraph's style (a body paragraph becomes a heading), or the next paragraph can lose its heading style.

**Rewrite a paragraph.** Take its `startIndex` and `endIndex` from `outline`. Delete `[start, end - 1]`, which keeps the paragraph's newline and style, then insert at `start`:

```json
[{"deleteContentRange": {"range": {"startIndex": 120, "endIndex": 184}}},
 {"insertText": {"location": {"index": 120}, "text": "New paragraph text."}}]
```

For several paragraphs, do the highest one first. When only some words in the paragraph change, delete and insert only those words at the range `find` gives, not the whole paragraph. A footnote mark, chip or image elsewhere in the paragraph then stays, and in suggestion mode the suggestion shows only the words that changed. To delete a whole paragraph, delete `[start, end]`. In three cases that range is refused, with "Invalid deletion range" or "The range cannot include the newline character at the end of the segment"; use these ranges instead. For the doc's last paragraph, delete from the previous paragraph's `endIndex - 1` to the last paragraph's `endIndex - 1`. For the paragraph just before a table, and for a table cell's only paragraph, delete the text only, `[start, end - 1]`; an empty paragraph stays, because Google keeps one before every table and in every cell.

**Append to the end.** Insert at the body end index minus 1 that `outline` prints. Start the text with a newline to begin a new paragraph. The new paragraph takes the named style of the one it splits from, so after a heading, set it to `NORMAL_TEXT` with `updateParagraphStyle`.

**Insert new paragraphs with styles.** Insert the text, then style ranges you compute from the insert point and the text length (in UTF-16 units). Headings use `updateParagraphStyle` with `namedStyleType` `HEADING_1` to `HEADING_6`, `TITLE`, or `NORMAL_TEXT` and `fields: "namedStyleType"`. Lists use `createParagraphBullets` over the range with a `bulletPreset` such as `BULLET_DISC_CIRCLE_SQUARE` or `NUMBERED_DECIMAL_ALPHA_ROMAN`. Typing "- " or "1. " makes text, not a list, and `createParagraphBullets` over typed markers keeps them as text, so delete them first. For nesting, put one leading tab per nesting level at the start of each nested line, before the first `createParagraphBullets`. It turns the tabs into levels and removes them, which shifts every later index by the number of tabs. Bulleting a paragraph directly after a list, with the same preset, adds it to that list. Inserted text takes the style of the text before it, or at the start of a paragraph the style of that paragraph's first character, so reset bold and italic on new body text with `updateTextStyle` (`fields: "bold,italic"`, empty `textStyle`). Don't reset headings, because that removes their bold.

**Add space between blocks.** In a doc that had content before you started, set space only on the paragraphs you add, and match how its own paragraphs are spaced, unless the user asks otherwise. By default, a new blank doc's Normal text has no space above or below it, so the paragraphs, lists, tables and code blocks you add to one with `update_doc` run together. Set the space with `updateParagraphStyle`, last, after the text, named styles and bullets: `spaceBelow` of about 8pt on each body paragraph, on the last item of each list and on the last line of an unshaded code block, and the same `spaceAbove` on body text right after a table or a shaded block. Headings bring their own space. Name only what you set in `fields`, never `*`: a field named there but missing from `paragraphStyle` is reset.

```json
{"updateParagraphStyle": {"range": {"startIndex": 120, "endIndex": 184},
  "paragraphStyle": {"spaceBelow": {"magnitude": 8, "unit": "PT"}}, "fields": "spaceBelow"}}
```

Set space last because a `NORMAL_TEXT` request on a paragraph that is already Normal text can clear it, and a paragraph split from a spaced one copies it. The empty paragraph Google adds after a table is already a blank line: leave it with no extra space, or put the next text in it and set `spaceAbove` there. Keep the lines of a code block tight: `updateParagraphStyle` styles every paragraph its range overlaps, table cells included, so don't use one range over the whole doc. Docs draws the space above and below a shaded paragraph, such as a line of a shaded code block, in the shading's color, so space set there makes no white gap. In a new blank doc, don't add empty paragraphs as spacers: one added after a list item or a heading can come out as an empty list item or heading.

**Add a table with content.** One call, with no second read. Place the table after a paragraph, at that paragraph's `endIndex - 1`: for a table under a heading, that is the last paragraph of the section, or the heading itself if the section is empty. Never use the start of a heading: that leaves an empty heading above the table, the heading's font in its cells, and, with `new-table`, the heading itself turned into body text. Write the rows to a JSON file and run:

```
python <skill>/scripts/docs_index.py new-table --at <endIndex - 1> --data rows.json --revision <revisionId> [--tab <tabId>] [--bold-header]
```

Pass its output as the `requests` and `writeControl` of one `update_doc` call. It inserts the table, fills the cells, bolds the header row with `--bold-header`, and sets the empty paragraph Google adds after the table to `NORMAL_TEXT` (otherwise, after a heading, it becomes an empty heading). Pass `--tab` whenever the doc has more than one tab; without it every request goes to the first tab. The command needs only the index, the revisionId and the tabId, which you can read from `read_doc` even when the result came back in the chat rather than as a file.

Without the script, put the same requests in one batch: `insertTable` at index `i` makes a table that starts at `i + 1`; in an R x C table, cell (r, c)'s text goes at `i + 4 + r × (2C + 1) + 2c`, and the empty paragraph after the table is at `i + 3 + R × (2C + 1)` until you insert text, so put its `NORMAL_TEXT` reset right after `insertTable`. Fill from the last cell to the first, so each insert only shifts cells already filled.

To fill a table that already exists, a cell's text goes at its first paragraph's `startIndex`, which is the cell's own `startIndex + 1`; Google rejects an insert at the cell's `startIndex` ("The insertion index must be inside the bounds of an existing paragraph"). With a saved read, `fill-table` builds these requests; it assumes the cells are empty.

**Change table structure.** `insertTableRow`, `deleteTableRow`, `insertTableColumn`, and `deleteTableColumn` take `tableCellLocation: {"tableStartLocation": {"index": <table startIndex>}, "rowIndex": r, "columnIndex": c}`. `updateTableCellStyle` sets cell backgrounds over a `tableRange` built from the same location plus `rowSpan` and `columnSpan`. Colors use `rgbColor` values from 0 to 1. A row inserted below a bold header row comes out bold, a new column copies its neighbor's width and background, and `unmergeTableCells` leaves all of the merged text in the first cell. To delete a whole table, delete exactly `[table startIndex, table endIndex]`.

**Suggest instead of edit.** Add `"writeMode": "SUGGEST"` to `writeControl`, and the same requests land as tracked suggestions that the doc's owner can accept or reject. Use it when the user asks for suggestions, redlines, tracked changes, or a review, or when the doc belongs to someone else and the user wants to propose rather than change. You can't accept or reject suggestions through the API, so tell the user they're waiting in the doc. Before you tell them, read the doc again with `read_doc` and run `outline`: inserted and deleted text should show as `[+...]` or `[-...]` (outline doesn't show suggested formatting changes). If new text shows as plain text, or deleted text is gone instead of showing as `[-...]`, the change was made directly; say so, and don't call it a suggestion. Suggested deletions stay in the index space until someone resolves them; see "How a doc is addressed". The connector has answered this mode with "Unsupported WriteControl mode". If it does, make no direct edits in its place: tell the user suggestions aren't available, and offer to list the proposed changes in your reply or to edit directly.

```json
{"documentId": "...", "requests": [...],
 "writeControl": {"writeMode": "SUGGEST", "requiredRevisionId": "..."}}
```

**Tabs.** `addDocumentTab` with `tabProperties.title` creates a tab, and the reply holds its `tabId`. `updateDocumentTabProperties` renames one (`fields: "title"`), and `deleteTab` removes one along with its child tabs, but not the only tab. Set `tabProperties.parentTabId` to create a child tab; tabs nest at most three levels deep. A new tab starts with one empty paragraph, so its first insert index is 1.

**Add a footnote.** `createFootnote` returns the footnote's ID; the new footnote holds a single space. In the next call, add your text with `insertText` and `endOfSegmentLocation: {"segmentId": "<footnote ID>"}`, then delete the space with `deleteContentRange` over `{"segmentId": "<footnote ID>", "startIndex": 0, "endIndex": 1}`. Drive's text read leaves footnote text out; check it with `read_doc`.

## Verify

- For content, read with Drive `read_file_content` and `includeComments: true`, and check the text you changed.
- For positions and styles, read with `read_doc` and run `outline` or `find` on the result. `find` shows whether replaced text picked up bold, and whether a match sits in a pending suggestion.
- For layout, where you can run code, export with Drive `download_file_content` and `exportMimeType: "application/pdf"`, then run `python <skill>/scripts/render_export.py <saved export> <out dir>` and check the page images against the list under "Check the result" above. If the export comes back in the chat instead of being saved to a file, skip the render rather than copying it into a file. If you can't run code, skipped the render, or it failed, rely on the two checks above and tell the user you couldn't check the layout visually.

## Docs failures

| Symptom | Cause | Fix |
|---|---|---|
| `read_doc` result too large or cut off | Full document JSON for a long or table-heavy doc | Orient with Drive `read_file_content`. Use `replaceAllText` where the find text matches only the text you mean to change (add neighboring words until it does). If the result was saved to a file, run `docs_index.py` on it. |
| An edit landed in the wrong tab | No `tabId` in the location or range | Add the `tabId` from the read or from the URL's `?tab=` value. |
| `replaceAllText` changed other tabs | No `tabsCriteria` | Scope it with `tabsCriteria.tabIds`. |
| `replaceAllText` reports 0 occurrences | Find text copied from `read_file_content`, which escapes `&`, `*`, and similar characters, tags commented text, or glues suggestions | Use the literal text, or check it with `docs_index.py find`. |
| Text shows as "RBRunning back" | A pending suggestion read as plain text | Read with `read_doc`. `outline` marks suggested text as `[+...]` and `[-...]`. |
| A heading loses its bold after an edit | A style reset was applied to the heading | Reset styles only on body text. |
| Replaced text turned bold | The replacement inherited the style of the first replaced character | Clear it with `updateTextStyle` over the new range. |
| Edits land in the wrong place | Requests ran from the lowest index to the highest, or used indexes from before an earlier write | Order requests from the highest index to the lowest, and read again after every write. |
| Typed "- " shows as text, not a bullet | Lists are paragraph properties | Delete the typed markers, then use `createParagraphBullets` over the range. Bulleting keeps typed markers as text. |


---

## Dosya: `references/sheets.md`

# Google Sheets reference

As a first step, before you create a sheet or change one, you must read the spreadsheet design rules below in full. After them, this file covers the Sheets connector (`get_spreadsheet`, `get_values`, `update_values`, `update_formulas`, `insert_dimension`, and `update_spreadsheet`) and how to carry out the design rules with it. Most of the connector behavior here was tested against Google's Sheets API; the rest was seen through the connector, and a few rules have not been checked yet.

# Spreadsheet design

When the user asks for something specific, such as tab names, column headers, a formula or a number format, do exactly that, and don't replace it with a design of your own; these rules decide what the user left open. When you edit an existing workbook, its conventions come first (see "Editing an existing workbook"). The rules for wording sheet names, headers, labels and notes are under "Writing in the workbook".

A reader judges a spreadsheet by whether its numbers are right and whether they can check them. Build it so that clicking any number shows either a formula they can trace or a labeled input they can change.

## Formulas, not typed results

- **Every derived number is a formula** that references the cells it comes from: totals, averages, ratios, growth rates, lookups. Write `=SUM(B2:B9)`, not a total you worked out yourself.
- **This holds when you work in code.** Use code to read, explore and reshape data, but the results you put in the sheet are formulas over the source cells. If the task is "summarize this 5,000-row tab", the summary cells hold `=AVERAGE(Data!B2:B5001)` and `=SUMIFS(...)`, not numbers computed in pandas.
- **Typed values are for data brought in from outside**, such as rows from a file, a query or a web page (sorting, filtering or removing duplicates first is fine), and for the inputs listed under "Inputs and hardcoded values". A sum, average or ratio computed in code and pasted in is a hardcoded result.
- **Put statistics and findings in labeled cells.** `=CORREL(B2:B100, C2:C100)` goes in a cell labeled "Correlation, price vs. volume". Any figure you report should be one the reader can find in the file.
- **Reference data that is already in the workbook.** Don't rebuild it elsewhere as a pasted "clean" copy; point formulas at the source.
- **Chart data is formulas or references** to the source, not a pasted block of numbers.
- **Formulas cover most analysis:** aggregation (`SUM`, `SUMPRODUCT`), conditions (`SUMIFS`, `COUNTIFS`), lookups (`INDEX`/`MATCH`) and statistics (`CORREL`, `STDEV`, `SLOPE`). Which newer functions Sheets supports is under "Function support" below.
- **Syntax basics:** start every formula with `=`. Put text in double quotes (`=IF(A1="Yes",1,0)`); a bare word gives `#NAME?`. Arithmetic on a cell that holds text gives `#VALUE!`.

Before you finish, check that a reader can click any number in the analysis and see how it was derived. Replace any bare value that should be a formula.

## Inputs and hardcoded values

- **Every business assumption lives in its own labeled cell**, and formulas reference it: `=B5*(1+$B$6)` where B6 is labeled "Revenue growth %", never `=B5*1.05`. This covers growth rates, margins, tax rates, multiples and thresholds. A comment explaining a number inside a formula does not fix it; the number still belongs in its own cell.
- **Don't:**
  - repeat a number that is already in the workbook: `=A1*1.05` when 5% is in an assumptions cell, or `=500000+B2` when 500,000 is in another cell
  - type a value you calculated, such as 1,050,000 after working out 1,000,000 × 1.05
  - copy a number from another sheet into a formula instead of referencing it (`=Inputs!A5`)
  - overwrite a formula with a typed value to force a result; fix the input or the logic that feeds it
- **These hardcoded values are fine:**
  1. Designated inputs: values in a labeled inputs or assumptions section that formulas reference.
  2. True constants in formulas: 12 months a year, 7 days a week, 100 to convert a percentage. No label needed.
  3. The first value of a calculated series when there is nothing earlier to reference, such as Year 1 revenue, placed in a labeled section.
  4. Structural values: row counts in `OFFSET`, sheet index numbers and other values that describe the spreadsheet rather than the business.
  5. Small lookup tables: static reference data in a labeled range, such as tax brackets, that formulas elsewhere reference.
- **Say where every hardcoded input came from,** in a cell note or an adjacent cell: `Source: [system or document], [date], [specific reference], [URL if there is one]`, leaving out any part you don't have, for example `Source: Company 10-K, FY2024, page 45, revenue note, [SEC EDGAR URL]`. When the number came from the user, say so: `Source: user-provided assumption`. "Sources and citations" covers data brought in from outside.
- **Mark the inputs.** In a model you build, or a workbook you create for someone to fill in, put a short legend near the top that says which cells are inputs and how they are marked. A workbook for someone to fill in also gets one example row of realistic values that shows the expected format. Never add an example row to a file you were asked to edit.

Before you write a value, ask: Is it a business assumption? Put it in a labeled cell. Is it derived? Write the formula. Is it an input with no source in the workbook? Label it and say where it came from.

## Formulas a reader can follow

- **Keep each formula short enough to read at a glance.** Split logic with several conditions or lookups into labeled helper cells or columns, so each step can be checked.
  - Good: the tax rate in a labeled helper cell B6, then `=B5*(1-B6)`.
  - Bad: `=B5*(1-IF(AND(B3>100000,B4="US"),0.21,IF(B4="UK",0.25,0.15)))`
  - Bad: `=SUMPRODUCT((A2:A100="East")*(B2:B100>50)*(C2:C100))/SUMPRODUCT((A2:A100="East")*(B2:B100>50))`
- **Write formulas that can be copied.** `$` locks what must not change when a formula is copied: `$A$1` locks both, `$A1` keeps column A when copied across, `A$1` keeps row 1 when copied down, and `A1` changes both.
- **Put dimension labels in a header, with one formula that references it.** When you summarize across months, quarters, regions or products, write the labels in a header row or column and one formula that refers to them.
  - Bad: E2 is `=SUMIFS($D:$D,$B:$B,"Jan")`, F2 is `=SUMIFS($D:$D,$B:$B,"Feb")`, and so on, one hand-edited formula per month.
  - Good: E1:P1 hold "Jan" to "Dec"; E2 is `=SUMIFS($D:$D,$B:$B,E$1)`, copied to F2:P2.
  - If the source has only dates, add a helper column first (`=TEXT(A2,"mmm")`) and reference it, rather than working out the period inside the `SUMIFS` criteria.
  - If you can't copy a formula along its row without editing it, the literal in it belongs in a header cell.
- **Use the same formula in every period of a row.** One edited cell in the middle of a row is the most common error that produces no error value.
- **Guard a division whose denominator can be zero:** `=IF(C5=0,0,B5/C5)`, which the zero format in "Financial models" shows as a dash. Use `IF` here rather than `IFERROR`, which also hides a broken reference.
- **Cross-sheet references use `!`:** `=Assumptions!B5`. Quote a sheet name that contains spaces or symbols, and double any apostrophe in it: `='Q3 Forecast'!B7`, `='Owner''s tab'!A1`. `=Assumptions.B5` (LibreOffice's notation), `=@Assumptions!B5` and `[Book2]Sheet1!A1` (Excel's reference to another file) are not valid in Sheets.

## Data that grows

- **Formulas over a log that users will add rows to must include the new rows.** This applies to transaction lists, timesheets and any append-only records. A fixed range that covers today's rows, such as `=SUM(B2:B128)`, or `J2:J1001` for a 1,000-row table, leaves out the next row added. Decide first whether the data is a growing log or a fixed snapshot; a snapshot can use fixed ranges.
- **Use open-ended ranges** such as `=SUM(B2:B)`. A Sheets table (Format > Convert to table) also accepts `=SUM(Sales[Amount])`, but `[@Amount]`, `[[#Totals],[Amount]]` and the `@` operator are syntax errors in Sheets. For a row-by-row calculation, anchor the columns and fill the formula down (`=$B2*$C2`). A named range does not grow, so don't use one for growing data. `ARRAYFORMULA` can calculate a whole growing column in one formula; guard it against blank rows, as in `=ARRAYFORMULA(IF(LEN(B2:B), B2:B*C2:C, ))`, where the empty last argument leaves unused rows blank (`""` would be counted by `COUNTA`). `ARRAYFORMULA` exists only in Sheets, so if the file may go to Excel, fill a plain formula down instead.
- **Band rows with something that extends to new rows:** alternating colors (Format > Alternating colors) over a range that runs past the last row, or a conditional format such as `=MOD(ROW(),2)=0` over the columns, reaching past the last row. Colors filled onto alternate rows by hand don't extend to new rows.

## Layout

- **Decide one style for a multi-sheet build** before you start: header fill, fonts, column widths and table style. Apply it the same way on every sheet, and check every sheet against it before you finish. Styling each sheet separately produces sheets that don't match each other.
- **Use one professional font throughout,** such as Arial or Times New Roman, unless the user asks for another.
- **Write cell text in the user's language and regional spelling:** headers, labels, notes and chart titles. If the workbook already follows a different variety, match the workbook. Never mix varieties in one workbook.
- **Column widths:** size the row-label columns so labels are not cut off. Merge and center a header that sits over a group of columns rather than widening a column to fit it. In financial models, keep the number columns one uniform width, and indent with an extra narrow column rather than by varying widths.
- **Group rows and columns instead of hiding them.** Don't hide rows or columns unless the user asks. A group shows a +/- control that tells the reader something is there; hidden rows are easy to miss and lead to mistakes. Before you collapse a group, check for charts placed over those rows or built from them: collapsing the rows hides the chart too. Keep a chart's data where collapsing detail rows won't affect it, such as a separate area or sheet.

## Writing in the workbook

Text you write in the workbook (sheet names, headers, labels, notes, comments, text cells, chart titles) should read as though a person wrote it. When readers think something was written by AI, they judge it as sloppy and stop trusting it, whatever the content. They make that judgment from a set of common indicators, listed below, so take extra care to keep them out of your writing. These rules are for text you write, and a style the user or their style guide asks for takes priority. Do not rewrite the user's existing text to follow them unless the user asks you to.

- Say what is true without first denying something else. "Revenue grew 12%, three times the US rate," not "This isn't a growth story, it's a market-share story." Do not open a note with "Here's the thing" or "The real story is".
- Match the number of bullets, examples, and adjectives to the content, not to a default of three. Two drivers get two bullets; five get five. A list of exactly three ("fast, reliable, and scalable") usually means the third item was added for rhythm, not because there were three things to say, and readers read it as filler.
- Do not use a metaphor where a literal word will do. If a plain description exists ("the same construction," "the same pattern," "slowed," "fell"), use it. Metaphors are for when the literal version would be longer or less precise, which is rare in analytical writing. Test: if the metaphor can be replaced by a plain word without losing meaning, replace it. A metaphor makes the reader translate it back into the plain claim and carries meaning you did not choose. The ones that appear most are "north star", "move the needle", "double-click" (meaning look closer), "unpack", "journey", and "landscape" (meaning a market). Common ones in business writing: "moat", "headwind", "drag" (meaning a cost on results), "safety net", "clears the bar", and "land" meaning finish or total ("lands $4.4k under budget"). Examples:
  - Bad: "The ones it has are the same species." Good: "The ones it has follow the same pattern."
  - Bad: "A coordinated digestion pause would be visible immediately." Good: "If several large customers cut capex in the same quarter, it would show up in the next guide."
  - Bad: "Architecture transitions compressed margin on the way in and expanded it on the way out." Good: "Gross margin fell during the Hopper-to-Blackwell ramp and recovered once Blackwell shipped at volume."
  - Bad: "The lever that unlocks growth." Good: "The pricing change is what makes the target reachable."
- Cut words that claim importance without giving evidence: "genuinely", "truly", "actually", "clearly", "significantly", "robust", "leverage", "delve", "actionable insights", "learnings". Where one of them stood in for a fact, put the fact there ("margins fell 4 points", not "margins fell significantly"); otherwise delete it. When "leverage" or "significant" carries its financial or statistical meaning ("net leverage", "statistically significant"), it is a literal term; keep it.
- Use full stops and commas, and a colon before a list. No emoji in the workbook.
- Use em dashes sparingly: at most one in a paragraph, and none in a heading, a title, or between a bold label and the text after it. Several em dashes in one paragraph is one of the first things readers use to spot machine writing. In place of one, use a comma, a colon, parentheses, or a new sentence, not an en dash or a spaced hyphen.
- Sheet names and headers name the contents ("Revenue ($mm)", "Assumptions"), not how you made them ("New calc", "Fixed"). A line of text that sums up an analysis, such as the headline on a summary sheet, states the finding ("Europe missed plan", not "Analysis results").
- Keep the conversation out of the workbook: do not name a tab "Summary (Revised)" or write "Updated per your feedback" in a cell. If two versions stay, name each for what it holds. Whoever opens the workbook next did not see the request, so those lines mean nothing to them. Say what changed in your reply, not in the workbook. Source notes and the Data Sources tab record where data came from; they are not conversation, so keep writing them where "Sources and citations" asks for them.

## Financial models

Use these unless the user or the existing file does something else.

**Text colors:**
- Blue (`#0000FF`): hardcoded inputs, and numbers users will change for scenarios.
- Black (`#000000`): all formulas and calculations.
- Green (`#008000`): links to other sheets in the same workbook.
- Red (`#FF0000`): links to other files.
- Yellow fill (`#FFFF00`): key assumptions that need attention, and cells the user should fill in or update.

**Number formats:**
- Years are text: "2024", not 2,024.
- Currency is `$#,##0;($#,##0);"-"`, with the unit in the header: "Revenue ($mm)".
- Negative numbers go in parentheses: (123), not -123.
- Zeros show as a dash, percentages included (`0.0%;(0.0%);"-"`).
- Percentages use one decimal place (`0.0%`) and are stored as fractions: 0.15 shows as 15.0%, while 15 would show as 1500.0%.
- Valuation multiples such as EV/EBITDA and P/E use `0.0"x"`, which shows 12.5x.

**Sensitivity tables:**
- Give the grid an odd number of rows and columns, such as 5×5 or 7×7, so the base case lands in the center cell, and highlight that cell (a yellow fill, for example). A WACC against terminal growth table should put the current WACC in the middle row and the current growth rate in the middle column.
- Build every cell of the grid as a formula that recalculates the output from its row's and its column's input values. For a DCF, each cell discounts the same cash flows at its row's rate and adds a terminal value at its column's growth rate.

## Charts

- **Lay chart data out as one block.** Headers in the first row become series names, and categories in the first column become the axis labels:

  |       | Q1  | Q2  | Q3  | Q4  |
  |-------|-----|-----|-----|-----|
  | North | 100 | 120 | 110 | 130 |
  | South | 90  | 95  | 100 | 105 |

- **Some chart types need a particular layout.** A pie or doughnut chart takes one column of values with labels. A scatter chart takes X values in the first column and Y values in the others. A candlestick chart takes Low, Open, Close, High.
- **Summarize before you chart.** To chart raw rows that need aggregating, build a summary first, either a pivot table or a table of `SUMIFS` formulas, and chart the summary range. A chart built on a pivot table follows the pivot table, so change the pivot table rather than the chart.
- **Group dates into periods with a helper column.** When the user wants totals by month, quarter or year and the data has daily dates, add a column that turns each date into its period, such as `=EOMONTH(A2,-1)+1` for the first day of the month (format the column as a date, or it shows a serial number such as 45413) or `=YEAR(A2)&"-Q"&ROUNDUP(MONTH(A2)/3,0)` for the quarter. Give it a header, fill it for every row, and group by it instead of by the raw dates.

## Sources and citations

Every value that comes into the workbook from outside it should be traceable without asking you: where it came from, how it reached you, and when it was pulled.

- **These need no source note:** data rows the user types or dictates with no system behind them, and the existing contents of a workbook the user gave you to edit. An assumption the user gave you still gets its note, as "Inputs and hardcoded values" says.
- **A figure you looked up on its own** (on a web page, or in a document or dashboard) and placed in your own layout gets a note on the value cell itself, not on its row label or header. If A8 is "Cash and cash equivalents" and B8 is $179,172, the note goes on B8. Use the source format from "Inputs and hardcoded values", with the URL of the page you actually read the figure from, not the index page you started at: `Source: Apple Investor Relations, https://investor.apple.com/sec-filings/annual-reports/2024`. This includes figures you found earlier in the conversation.
- **A table you bring in whole** gets exactly one note, on its top-left header cell (C4 for a table at C4:F20), and no notes on the value cells or the other headers. This covers the rows of an uploaded file, a query result, query results the user pasted, and a table you transcribe from a document, such as a financial statement from a PDF.
  - For an uploaded file or document: `Source: [file name], [page or table, if it applies], uploaded [date]`.
  - For a query result: `Source: [system] ([object]), [N] rows, run [date, time and time zone]. [How obtained]. Full query on the Data Sources tab.` N counts data rows, not the header. "How obtained" is "Run by Claude" when you ran the query, or "Pasted into chat by user; not run by Claude" when the user supplied the results. Never word a note as if you ran a query whose results were given to you.
- **Query results also get a row on a "Data Sources" tab,** one row per result set. Make it the last tab and keep it visible. Its columns, in order: Written to (Sheet!Range, including the header row) | Source | Object (database.schema.table, endpoint, URL or file name) | Obtained via | Query or request (the exact query, or the user's request in their own words if no query was shown; never invent one) | Parameters | Run at | Requested by (the person who asked, if you know their name) | Row count | Changes after retrieval (none, or what you did: sorted, filtered, pivoted, converted units) | Notes. If you run a query again, add a new row and write "superseded" in the old row's Notes instead of overwriting it. If you remove a table, write "removed" in its row's Notes.
- **Run at** is when the data was pulled, as the tool or the user reports it. Turn a relative day such as "yesterday" into a date, and type it as text; never use `NOW()` or `TODAY()`, which change every time the file opens.
- **Keep secrets and personal identifiers out of the audit record.** Credentials, API tokens, passwords and connection strings never go anywhere in the workbook. In the query text, the notes and the Data Sources tab, replace personal identifiers that appear as literal values with [REDACTED]: government ID numbers, full bank-account or payment-card numbers, the name or date of birth of a private individual, home addresses, and personal email addresses or phone numbers. Keep table and column names, company and product names, internal record keys and non-identifying filter values, so the query can still be read and run again. `WHERE ssn = '123-45-6789' AND region = 'EMEA'` becomes `WHERE ssn = '[REDACTED]' AND region = 'EMEA'`. The returned rows go into the sheet as the user asked; this rule is about not copying identifiers into the record a second time.

## Editing an existing workbook

- **Its conventions override these rules:** colors, number formats, fonts, layout and tab order. Find its input cells first (a distinct font color, fill or shading usually marks them), write only there unless the request needs more, and leave its existing formulas alone unless the user asks you to change them.
- **Keep its formatting.** Format a new row like the row above it, and a new column like the one beside it.
- **Match the number format of what you summarize.** A total under a currency column gets the same currency format. If the new cell is unformatted, set the format rather than leaving a bare number.
- **After inserting rows inside a summarized range,** check that the totals and averages include them. Rows inserted just below the last summed row or above the first are often left out.
- **Inserted rows and columns take their neighbors' formatting.** Rows inserted under a blue header row come out blue. Check the new cells and clear formatting that doesn't belong.

## Checking the result

- **Check what the reader will see.** Number formats and locale decide what a cell displays, so for formatting work check the displayed text, not only the stored value.
- **No error values:** no `#VALUE!`, `#REF!`, `#NAME?`, `#DIV/0!` or `#N/A`, no circular references, and no range that stops short of the data.
- **No error values does not mean correct.** Look for hardcoded numbers where a formula belongs, and for formulas that point at the wrong row but happen to give the right value today.
- **Check every sheet.** List the sheets the workbook actually has, rather than the ones you remember creating, and check that each has its content. Finish or delete any empty tab you added.
- **Check the sources.** Every figure from outside the workbook has the source note "Sources and citations" asks for.
- **Check the formatting** against the user's request and the conventions above.

# Sheets connector

## Applying the design rules

- **Colors:** a `sheets_helper.py format` rule takes the hex values from the design rules above in `fg` and `bg`, such as `{"range": "B2:B8", "fg": "#0000FF"}` for inputs.
- **Number formats:** the helper's `currency` is the `$#,##0;($#,##0);"-"` from the design rules above and its `multiple` is `0.0"x"`. Its `percent` is plain `0.0%`, which shows zero as 0.0%; in a financial model, pass the pattern `0.0%;(0.0%);"-"` instead. *Untested through the connector.*
- **Years as text:** write `'2024` with a leading apostrophe. Without it, both write tools store the number 2024.
- **Source notes:** an `updateCells` request sets a cell's note: `{"updateCells": {"rows": [{"values": [{"note": "Source: ..."}]}], "fields": "note", "start": {"sheetId": 0, "rowIndex": 3, "columnIndex": 2}}}` puts it on C4. *Untested through the connector.*
- **Grouping rows or columns:** `{"addDimensionGroup": {"range": {"sheetId": 0, "dimension": "ROWS", "startIndex": 4, "endIndex": 12}}}` groups rows 5 to 12; the indexes are 0-based with an exclusive end, like grid ranges. *Untested through the connector.*
- **Banding:** `addBanding` with a `bandedRange` whose `rowProperties` set `headerColor`, `firstBandColor` and `secondBandColor`. The banding extends to rows added inside the range, so make the range run past the last row of data. *Untested through the connector.*

## Create

- **Blank sheet, then fill it, in four calls.** Use this for models and anything with formulas.
  1. Drive `create_file` with `contentMimeType: "application/vnd.google-apps.spreadsheet"`. The first tab of a new sheet is `Sheet1` with `sheetId` `0`, so there is nothing to read yet.
  2. One `update_formulas` call writes the whole table from its top-left cell: title, headers, labels, numbers and formulas in one 2D array, with `null` for cells left empty. Both write tools parse input the same way, so don't send the numbers and the formulas in separate calls.
  3. One `update_spreadsheet` call does everything else: the tab rename (`updateSheetProperties` with `fields: "title"`), formatting, frozen rows, merges, conditional formats, and widths for text columns (the format spec's `col_widths` key, or an `autoResizeDimensions` request) so labels aren't cut off. `sheets_helper.py format spec.json --sheet-id 0` builds the formatting without a metadata read; append the other requests to its output.
  4. One `get_values` over the table to verify.
- **Upload:** upload a CSV or an .xlsx built with the `xlsx` skill, and Drive converts it. Then edit the result in place. The file's whole content goes inside the tool call, so an upload is slow and often fails: a 20 KB encoded file has taken about three minutes. Keep uploads small; for a large data set, create a blank sheet and write the data with `update_values`.

## How a sheet is addressed

There are two coordinate systems, and each tool uses one of them.

| Tools | Addresses cells by | Example |
|---|---|---|
| `get_values`, `update_values`, `update_formulas` | A1 notation with the tab name | `'P&L Model'!B4:D10` |
| `update_spreadsheet`, `insert_dimension` | Numeric `sheetId` plus 0-based indexes; end indexes are exclusive | B4:D10 on tab 1001 is `{"sheetId": 1001, "startRowIndex": 3, "endRowIndex": 10, "startColumnIndex": 1, "endColumnIndex": 4}` |

- **Quote tab names** that contain spaces or symbols, and double any apostrophe inside: `'P&L Model'!F5`, `'Owner''s tab'!A1`.
- **The `sheetId` is not the tab name or its position.** Get it from `get_spreadsheet` (see Read). To choose a new tab's ID yourself, set `sheetId` in `addSheet`; the reply confirms it.
- **Leave the math to the helper.** `sheets_helper.py range` converts A1 to a grid range, including open ranges like `C:C`, and resolves tab names:

```
python <skill>/scripts/sheets_helper.py range "'P&L Model'!B4:D10" --meta meta.json
{"sheetId": 1001, "startRowIndex": 3, "endRowIndex": 10, "startColumnIndex": 1, "endColumnIndex": 4}
```

`meta.json` is the (small) output of the metadata read below, written to a file.

## Read

- **Tabs and IDs:** `get_spreadsheet` with `fields: ["sheets.properties"]`. It returns each tab's `title`, `sheetId`, and grid size. Keep it small: never call `get_spreadsheet` without `fields`.
- **Field masks: one path per array item, no parentheses.** This connector rejects `sheets.properties(sheetId,title)` and `"spreadsheetId,properties.title"` as one item. Pass separate items instead: `["spreadsheetId", "properties.title", "sheets.properties"]`.
- **Displayed values:** `get_values` returns what the UI shows, as strings (`"$125"`, `"25.0%"`, `"#DIV/0!"`). It has no option for formulas or raw values. An empty row comes back as `[]`, trailing empty cells and rows are dropped, and a fully empty range comes back with no `values` key at all.
- **Read to the end of the data with an open range.** On a small tab, `'Log'!A:F` returns the header and every filled row, and nothing past the last one, so one read gives both the layout and where the data ends. Don't guess a fixed end such as `A1:Z1000`: a range past the tab's last row can fail with "exceeds grid limits", and deleting rows makes the tab shorter. To format a column down to the end, leave `endRowIndex` out of the grid range (`sheets_helper.py range "D2:D"` does this).
- **Formulas, raw values, and errors:** read the grid instead. Use exactly this call, which is small and has everything the helper needs:

```json
{"spreadsheetId": "...", "includeGridData": true, "ranges": ["'Model'!A1:H40"],
 "fields": ["sheets.properties.title", "sheets.data.startRow", "sheets.data.startColumn",
            "sheets.data.rowData.values.userEnteredValue",
            "sheets.data.rowData.values.formattedValue",
            "sheets.data.rowData.values.effectiveValue"]}
```

Then list the cells, with each formula next to its displayed result:

```
python <skill>/scripts/sheets_helper.py cells grid.json
Sheet1!D5   '=B5*(1+C5)'   -> '$125'
Sheet1!D7   '=D5/0'        -> '#DIV/0!'  <-- ERROR DIVIDE_BY_ZERO
errors: 1
```

Add `--errors-only` to list only the error cells. Add `sheets.data.rowData.values.userEnteredFormat` to the fields when you need to read formatting, and keep the range tight: grid reads grow fast. `get_values` shows only a link's label. For the URL, add `sheets.data.rowData.values.hyperlink` to the fields and read it from the JSON, since `cells` doesn't print it. A cell with several links has no `hyperlink`; read `textFormatRuns` for those.

## Write values and formulas

- **Both write tools parse input the way the Sheets UI does.** `update_values` and `update_formulas` both turn `"=A1+B1"` into a formula, `"0.25"` into a number, `"3/14/2026"` into a date, and `"00123"` into the number 123. `"1/2"` becomes a date that still displays as 1/2, and a `SUM` over it adds the date's serial number, a five-digit number such as 46024. Period labels such as `"Jan 2027"`, `"2027-01"` or `"Jan 1"` become dates too; a bare month abbreviation such as `"Jan"` stayed text. Because both parse the same way, one `update_formulas` call can write a block's labels, numbers and formulas together.
- **Keep text as text with a leading apostrophe.** `"'00123"` stores the text `00123`, and `"'=not a formula"` stores that literal text. Use it for IDs, ZIP codes, account numbers, and any text that looks like a number, date, or formula. Cells formatted as `TEXT` beforehand also keep input as text; other number formats, such as currency, don't.
- **Send numbers as numbers**, not strings. Store percentages as fractions, such as `0.25` for 25%, and format them as percent.
- **`null` skips a cell; `""` clears it.** Booleans become `TRUE` / `FALSE`.
- **Write formulas for every calculated cell.** Do not write results you computed yourself. Formulas keep the sheet live when the user changes an input.
- **The range should fit the data.** Give the full extent (`'Model'!A4:D6` for 3 rows of 4) or just the top-left cell. Writing a 2D array into a smaller range fails with "Requested writing within range …".
- **Clearing values leaves the cells' number formats.** A cell that held a date shows the next number you write as a date. Reset the format with `repeatCell` before reusing the cells.
- **Inserting rows or columns shifts formulas for you.** `insert_dimension` (or `insertDimension` in a batch) updates references in existing formulas, so re-read before writing to rows below an insert. Set `inheritFromBefore: true` to copy the formatting of the row above. Directly under a header row, pass `false`: `true` copies the header's formatting. A row inserted between the last summed row and its total row is not added to the `SUM`, and neither is a row inserted at or above the first summed row: the range shifts down past it. Insert inside the range, or rewrite the total as a formula over the new rows; never replace it with a typed number.

## Batch updates: structure, formatting, charts

`update_spreadsheet` sends raw `spreadsheets.batchUpdate` requests. `get_spreadsheet` doesn't return a `revisionId`, even when `fields` names it: send these requests without `writeControl`, and read again right before a write that depends on positions.

- **Field masks inside requests have the same rule:** comma-separated full paths, no parentheses. `"fields": "userEnteredFormat.numberFormat,userEnteredFormat.textFormat.foregroundColor"` works; `"userEnteredFormat(numberFormat,textFormat)"` is rejected.
- **Colors are `red`, `green`, `blue` from 0 to 1**, not hex.
- **Formatting: use the helper.** Describe the formatting in a short spec and `sheets_helper.py format` builds the requests, with correct ranges, colors, and field masks:

```json
{"sheet": "Model",
 "rules": [
   {"range": "A1:F1", "bold": true, "bg": "#1F3864", "fg": "#FFFFFF", "align": "center"},
   {"range": "B2:B8", "fg": "#0000FF"},
   {"range": "C2:F20", "number": "currency"},
   {"range": "G2:G20", "number": "percent"},
   {"range": "A1:G20", "borders": "#BFBFBF"}],
 "freeze": {"rows": 1, "columns": 1},
 "col_widths": {"A": 220, "B:G": 110},
 "row_heights": {"1": 30}}
```

```
python <skill>/scripts/sheets_helper.py format spec.json --meta meta.json
```

For one tab whose `sheetId` you already know, such as `0` on a new sheet, pass `--sheet-id 0` instead of `--meta` and leave `sheet` out of the spec. The output is the full `requests` for `update_spreadsheet`. Named number formats: `currency`, `currency2`, `percent`, `multiple`, `integer`, `decimal`, `date`, `text`; any other string is used as a Sheets pattern. Rule keys: `bold`, `italic`, `size`, `font`, `fg`, `bg`, `align`, `valign`, `wrap`, `number`, `borders`.

- **One conditional-format rule can cover several columns.** `addConditionalFormatRule` takes a list of `ranges`. Write a `CUSTOM_FORMULA` for the top-left cell of the first range; Sheets shifts its relative references for every other cell, including cells in the other ranges. With ranges D5:D15, F5:F15 and H5:H15, `=D5>C5` compares each actual with the plan in the column to its left. Add `$` to fix a column: `=$J5>$I5` on K5:L15 colors both cells of a row by one comparison.
- **Labels over a group of columns:** an unmerged label such as "July" above a Plan and an Actual column sits at the left edge of its first cell, away from the right-aligned numbers under it. Merge the group's label cells with `mergeCells` and center them, or drop the group row and name each column ("Jul plan", "Jul actual").
- **Other common requests:** `addSheet` (with `properties.sheetId` and `title`), `updateSheetProperties` (rename with `fields: "title"`; freeze rows with `gridProperties.frozenRowCount`), `deleteDimension`, `mergeCells`, `setDataValidation` (dropdowns, checkboxes), `addConditionalFormatRule`, `sortRange`, `findReplace`, `autoResizeDimensions`.
- **Charts work.** `addChart` creates a native chart; the reply returns its `chartId`, which Slides can embed. A minimal column chart:

```json
{"addChart": {"chart": {
  "spec": {"title": "Revenue", "basicChart": {"chartType": "COLUMN",
    "domains": [{"domain": {"sourceRange": {"sources": [
      {"sheetId": 0, "startRowIndex": 0, "endRowIndex": 6, "startColumnIndex": 0, "endColumnIndex": 1}]}}}],
    "series": [{"series": {"sourceRange": {"sources": [
      {"sheetId": 0, "startRowIndex": 0, "endRowIndex": 6, "startColumnIndex": 1, "endColumnIndex": 2}]}},
      "targetAxis": "LEFT_AXIS"}],
    "headerCount": 1}},
  "position": {"overlayPosition": {"anchorCell": {"sheetId": 0, "rowIndex": 8, "columnIndex": 0}}}}}}
```

Use `LINE` for trends over time, `BAR` or `COLUMN` for comparisons, and set `headerCount: 1` when the first row is a label.

- **A chart that will be embedded in a Slides deck** follows the deck's existing chart style. When the deck has none: no chart title, since the slide carries the label; no legend; and a value label on every bar. For those, leave `title` out of the `spec`, set `"legendPosition": "NO_LEGEND"` on `basicChart`, and add `"dataLabel": {"type": "DATA"}` to each bar or column series. Leave `dataLabel` off a line series: a line's few point labels and its name go on the slide as text boxes. To color a single bar, use the series' `styleOverrides` (`[{"index": 3, "colorStyle": {"rgbColor": {...}}}]`). *Untested through the connector.*

## Verify

1. Read the displayed values of everything you built with `get_values`. Scan for `#REF!`, `#DIV/0!`, `#NAME?`, `#VALUE!`, `#N/A`, and `#ERROR!`, and check that totals match the numbers you expect.
2. For models, run the grid read and `sheets_helper.py cells --errors-only`, then spot-check that calculated cells hold formulas (`'=...'`), not typed numbers.
3. After an upload, confirm the tab names and sizes with the metadata read before editing.

## Function support

Sheets supports `XLOOKUP`, `FILTER`, `UNIQUE`, and `SORT`, so the `xlsx` skill's LibreOffice limits do not apply here. If the user may export the file to Excel, avoid Sheets-only functions such as `QUERY`, `ARRAYFORMULA`, `IMPORTRANGE`, and `GOOGLEFINANCE`. Formulas that fetch an outside URL (`IMAGE`, `IMPORTDATA`, `IMPORTXML`, `IMPORTHTML`, `IMPORTFEED`) show `#REF!` until someone opens the sheet in a browser and clicks Allow access, so tell the user.

## Sheets failures

| Symptom | Cause | Fix |
|---|---|---|
| `Invalid field: sheets.properties(sheetId,title)` | The connector rejects parenthesized field masks | Pass one full path per array item: `["sheets.properties"]`. |
| `Invalid field: user_entered_format(number_format` | Parentheses in a request's `fields` | Use comma-separated full paths. `sheets_helper.py format` does this for you. |
| An ID lost its leading zeros, or text became a date | Both write tools parse input like the UI | Prefix the value with `'`. |
| A formula shows up as a value you typed | A computed result was written instead of a formula | Write the formula string starting with `=`. |
| `get_values` result has no `values` key | The range is empty | Treat it as empty; it is not an error. |
| Formatting landed on the wrong rows | 1-based rows used as 0-based indexes, or an inclusive end index | Build the range with `sheets_helper.py range`. |
| Formatting landed on the wrong tab | Tab position or name used as `sheetId` | Read `sheets.properties` and use the numeric `sheetId`. |
| Formulas point at the wrong rows after an insert | Rows were written using positions from before the insert | Re-read after `insertDimension`; Sheets already shifted existing formulas. |
| `Unable to parse range: <tab>!A1` | Usually a tab name that doesn't exist, not bad A1 syntax | Read `sheets.properties` and use the exact tab title. |


---

## Dosya: `references/slides.md`

# Google Slides reference

**As a first step, before you build, rewrite or restyle any slide, in a new deck or an existing one, you must read the design rules below in full. Before you add or change a chart, also read `references/charts.md`.** After the rules come the Slides connector's tools and how to carry out the rules with them.

# Slide design

When the user asks for something specific, such as a slide count, exact wording, a color or a layout, do that; these rules decide what the user left open. The rules for charts are in [charts.md](charts.md); the rules for the words on slides are under "Writing slide copy" below.

Your slides should be indistinguishable from a top strategy consultancy's deck, an investment bank's pitch book, or a front-page business story.

## Deck structure

- **One message per slide.** A deck goes theme by theme, message by message. Putting revenue next to retention on one slide, unless they are related, gives the reader two things to work out instead of one.
- **The titles tell the story.** Someone reading only the slide titles should be able to follow the whole deck.
- **A common structure is the pyramid:** the main message up front, an executive summary that previews the sections, the sections themselves, then a conclusion, usually with next steps that act on the findings.
- **Match the structure to the size of the deck.** A short deck might not need an introduction and a conclusion; a long deck might need dividers between topics.
- **Build toward what the deck is for:** a decision, consensus, a celebration, resolving a disagreement, or opening a discussion.
- **Build for how it will be used.** A live deck gets narration and possibly discussion; a pre-read has to carry the whole narrative itself. An executive audience in a live meeting needs few words and highly visual slides. Detailed, word-heavy slides are sometimes right for subject-matter experts or for a deck read offline. Analytical reports lean on charts and tables, with the titles carrying most of the narrative.
- **Size a live deck to the talk:** about 1.5 to 2 minutes per slide, with time left for questions if there will be any.

An example outline; the deck's own subject decides the titles:

1. Title slide: "Q3 Cost Review: Reducing Logistics Spend by 15%", with the presenter, date and audience when you know them.
2. Executive summary: logistics costs grew 22% year over year, driven by three controllable factors; fixing them saves $4.2M a year. Previews the deck and the recommendation.
3. "Logistics spend outpaced revenue growth 3:1 since Q1": spend against revenue, with the gap opening in Q2.
4. "Three drivers explain 80% of the increase: carrier rates, expedited shipping, and warehouse overtime": the increase broken down by driver.
5. "Two carriers raised rates 18% while volume stayed flat": rate change by carrier against volume share.
6. "Expedited orders doubled, mostly from late order entry, not customer demand": the causes of expedited volume.
7. "Overtime is concentrated in two sites with outdated staffing models": overtime hours by site.
8. "Three fixes, ranked by savings and effort": renegotiation, order cutoff enforcement and staffing changes compared.
9. "Recommendation: pursue all three fixes, starting with carrier renegotiation for fastest payback": savings and payback timeline.
10. Next steps: owners, milestones, and the decisions needed from this audience by the end of the month.

## Designing a slide

Design each slide before you build it, in this order: the message, the evidence, the layout. The layout comes last because it depends on what the slide has to hold.

### Message: the title

The title carries the slide's message, and most slides need one. There are three conventions for slide titles:

1. **Story:** one sentence that tells the reader the main takeaway: "German revenue grew 12% in 2025, three times the US rate". Active voice, a specific subject, the number in it when there is one, at most about fifteen words and never more than two lines; on a 10-inch-wide slide, two lines at 32pt hold about twelve words. Not "German market overview", and not "We analyzed the German market".
2. **Label only:** the general theme of the slide: "German revenue in 2025".
3. **Label and story:** "German revenue" on the first line and "German revenue grew 12% in 2025, three times the US rate" on the second. This shows both the theme and the takeaway.

Write every title in the deck the same way. If the deck already has a convention, use it. Otherwise default to story titles on content slides.

Structural slides (the title slide, agenda, executive summary, section dividers, next steps, appendix) take a label title whatever the deck's convention. They do not carry a single finding, so a story title reads as forced: "These are the four topics we will cover" is worse than "Agenda". The executive summary's takeaway goes in its body, not its title.

### Evidence

The content's only job is to make the reader believe the title. Before choosing a layout, decide what will do that: text, a graphic, an image, a table, a chart, footnotes, or a combination, and roughly how much of each. Most slides need one main element and a little supporting text:

- If the title is a number or a comparison, the main element is a chart ([charts.md](charts.md) picks the type).
- If it is a structure or a process, a graphic.
- If it is a claim with several reasons, short text, or a row of icons with labels when the reasons are parallel.

### Layout

Match the company's style and branding, as shown by the slide master, the finished slides already in the deck, and anything the user has said. Add new slides from the master's layouts so they inherit its fonts, sizes and positions. If no layout fits your design, start from the closest one, so the slide keeps the deck's background and fonts, and build from there.

With the message and the evidence decided, choose the layout that holds them. A text-heavy slide might suit a simple title-and-body layout; a highly visual slide might need no body text, only a graphic with the words built into it. Some common layouts:

- **Big text.** One message and nothing else. Rare; right for a quote, or a big message or number that deserves its own page.
- **Title on top and content below, or title on one side and content on the other.** Good for an agenda, an executive summary, or a key chart that speaks for itself and needs no commentary.
- **Title on top, a visual and commentary below.** The most common slide: a left/right split, with the visual on one side and the commentary on the other. A chart gets at least 60% of the width; another visual can take half or two-thirds.

Other layouts are fine if they follow the deck's design standards. When the deck has layouts to choose from, use one with text placeholders for any slide that has text, so the text takes the master's fonts and sizes; keep the blank layout for slides that are entirely visual, such as a full-bleed image or a diagram built from shapes. Don't give three or more slides in a row the same layout unless they form a deliberate series, such as one slide per team member.

## Starting from the deck's design

**A deck with its own template or theme.** Keep its design. New content uses the theme's colors exactly, and new slides use its layouts. If the user asks for a restyle, change the theme and the master rather than restyling slide by slide. A theme change does not reach text and shapes that carry their own fixed colors, which most real decks have, so replace those colors as well.

**A deck styled slide by slide on the default theme.** Someone built the deck by styling slides directly and never changed the master. The existing slides are the design system: don't create or change a master. Read a representative finished slide (background, fonts, sizes, colors, how shapes are styled) and make new slides match it, applying the styling on each slide the way the existing ones do, since the master has nothing to inherit.

**A new or blank deck.** Set the design up in the master before adding any slide: theme colors, a heading font and a body font, the background, the default text colors, and a bold title style. Text color is set in the master's text styles, not shape by shape. Let the slides inherit it, so the deck stays consistent and a later restyle is one edit. Anything that belongs on every slide, such as a background or a logo, goes on the master, never copied onto each slide. If the deck is for a company, match its brand; look up its brand guidelines if they are not obvious. Otherwise use what the user told you, and fill in the rest. Unless the palette you pick below says otherwise:

- an off-white background with no warm tint (such as #FAFAFA) and near-black text, rather than pure white and pure black;
- one or two accent colors at the same brightness;
- a look that fits this deck: a quarterly review, a pitch and a workshop deck should not look the same, and neither should two decks you make in a row.

Do not default to a dark-blue background. Pick a palette that matches the content:

- **Corporate neutral:** white or light gray background, one saturated accent, generous white space. For reports and proposals.
- **Warm editorial:** cream background with terracotta or olive accents. For case studies and narratives.
- **Bold startup:** near-white background with one high-contrast accent. For launches and pitches.
- **Academic muted:** paper-white background, steel blue and muted green, serif headings. For research and teaching.
- **Playful bright:** warm light background with several saturated accents. For events and creative work.

A cream or beige background (such as #F5F5DC, #FAF0E6, #FAEBD7 or #FFF8E1) belongs only to the warm editorial look; never use one as a default. A dark background suits the title slide and section dividers.

**Finished slides and rough slides.** Not every existing slide is a style reference. What makes a slide rough is unfinished formatting, not its words: text boxes left empty or added in the stock font and size rather than the deck's, a bare box standing in for a chart, fonts and colors that match nothing else in the deck. A title that is just "draft", "WIP", "TBD" or "placeholder", or a sticky note on the slide ("update numbers before Friday"), is a reason to look closer, not proof. Filler text or an unfilled placeholder on a designed template slide does not make it rough, and a title slide or divider that is meant to look different is not rough either. Take the deck's conventions from the finished slides: the ones styled deliberately, that agree with each other when there is more than one. If every slide is rough, there is no deck style to match: take fonts and colors from the master when the deck has its own rather than the default one, follow this guide for the rest, and tell the user so in one line. Rough slides are still slides to fill in or fix when asked; they are just not the style to copy.

## Text

Keep slide text brief. If you have more than one sentence, use bullet points.

- **Titles are bold**, in the heading font, and larger than any other text on the slide except a big number. A regular-weight title reads as body text, and the slide loses its hierarchy.
- **Structure for readability.** Keep parallel structure (all fragments or all sentences). Bold the words a reader needs to get the message. Keep each bullet to two lines.
- **Be direct.** Cut filler ("in order to", "key", "very").
- **Use active, concrete language.** Specific nouns and plain verbs: "customers left", not "we experienced customer attrition". Name the actor in every sentence.
- **Be consistent.** The title and the content must agree; if they don't, one of them is wrong.
- **Don't describe visuals.** Bullets add what the visual cannot show. If everything in a bullet is visible in the chart, cut the bullet.
- **Give data context.** Pair every standalone number with a comparison: a prior period, the plan, or a competitor. Round to the precision a decision needs ($4.2M, not $4,183,207), and use ratios or multiples ("doubled", "1 in 5") to make the size of a change clear. Keep formatting, units and abbreviations the same on every slide.
- **Claims must be defensible.** Every assertion must trace back to a verifiable data point or a clear, logical derivation. If you cannot find a direct path to the evidence, leave the claim out. When the user asks for figures you don't have ("add our financials"), ask for them; never invent figures.

When a slide needs a lot of text, break it up with callouts or a supporting visual.

## Graphics

A well-chosen graphic shows structure at a glance that a paragraph would take a while to describe: a diagram, flow chart, timeline, process map, org chart, funnel, pyramid, 2×2 matrix, Venn diagram, cycle, roadmap, before-and-after comparison, or icon-and-label layout.

- **Shape the graphic like the idea.** A sequence gets a flow or a timeline, a hierarchy a pyramid or an org chart, overlapping categories a Venn diagram, a tradeoff a 2×2, a recurring process a cycle. If the idea has no inherent structure, don't force it into one.
- **One idea per graphic.** If a graphic needs a paragraph to explain, simplify it. Cut elements until the takeaway is visible in a few seconds; details move to supporting text or a follow-up slide.
- **Label elements directly, not in a legend.** Put short labels (2–5 words) on or next to the elements themselves. Longer explanations live outside the graphic.
- **Give each color, shape and size one meaning,** the same everywhere it appears, within the graphic and across the deck. Use color to mark the element that matters, not to decorate; keep everything else neutral.
- **Flow left to right or top to bottom.** Arrows show a relationship (sequence, causation, dependency), never decoration, and all flow in one direction.
- **Size and space equal elements equally.** Equal-weight elements get equal sizes and even spacing, and alignment is exact, not approximate.

## Images

An image must carry information. A generic stock photo is worse than empty space. Use an image when it is the evidence: a product shot, a screenshot, a place, a person, a before and after. Otherwise leave it out.

- Viewers look where a pictured person is looking, so a person in a photo should face the content, not the edge of the slide.
- A photograph can fill its frame and be cropped. A screenshot or a diagram is shown whole, at its own aspect ratio, with no text laid over it.
- Text on top of a photo sits on a card or a darkened band so it stays legible.
- An image with a transparent background needs a backdrop that contrasts with its content, so its edges read.
- Never stretch or squash an image to fit a frame: crop it, or letterbox it on a neutral background.

## Icons

A small icon beside each point gives the reader something to scan before they read, and it is the simplest way to fix a slide that would otherwise be a wall of text. Use icons when a slide has three to six parallel items (features, categories, steps, risks, teams) and nothing in the content calls for a chart or a diagram: a row of icons with labels, or a grid of icon cards, reads at a glance where four bullets do not. Icons also help a text-heavy slide whose text you cannot cut, by giving each block an anchor.

- One icon per point, and the icon means the point: a shield for security, a clock for timing, a chart for growth. An icon that needs its label to make sense is decoration; leave it out.
- Every icon on a slide, and across the deck, is the same style (all filled or all outline), the same size (30–50pt beside text; larger only for a single hero icon), and aligned on one row or grid with even spacing, to the left of its label.
- Color icons in the deck's accent, or a neutral, with enough contrast against the background; not a different color per icon. An icon in a small filled circle of the accent color works well.
- Put a short label (2–5 words) next to each icon; the icon does not replace the label.
- Take icons from an icon set, never emoji, which render differently on every platform. When no icon set is available, use a filled circle with one simple symbolic shape or a number on it, and keep the same rules.

## Tables

A table is right when the reader looks up specific values across a few dimensions, or compares a small set of items on several attributes. If one comparison is the point, that is a chart, not a table. Keep the styling light so the numbers read first.

- **Borders:** thin (1pt or hairline), in the deck's light border color (about #E0E0E0 on a white background), between rows only, with one border under the header row. No column borders. A full grid looks like a spreadsheet, not a slide.
- **Header row:** bold text, no fill. That is the whole treatment. A colored header bar is the default table style in most slide tools and reads as unstyled.
- **Row labels (first column):** bold and left-aligned.
- **Alignment:** text columns left, number columns right so the digits line up. Put the unit on every value ("$42M", "61%"; a plain count such as 355 needs none), not in the row or column header, the same rule as bar labels. One number format per column, or per row in a table of metrics by period.
- **Highlighting:** the row or column that is the message gets a light tint of the deck's accent color; nothing else does. For a heat map, one hue from light to dark, never the red-yellow-green default. Bolding one cell is fine.
- **Density:** at most about six columns and eight rows on a full slide; past that, split the table or move it to an appendix. A cell that needs three or more sentences, or more than about 40 words, is too dense: shorten it to one sentence, move the detail to a footnote or a text box, or split the table.
- **Size:** text in a table you create is at least 14pt; in an existing dense template, keep the template's sizes. Give rows generous height, about 28–32pt for a one-line row and 48–56pt for a two-line row, and no zebra striping. Check that the whole table fits above the bottom margin before you build it; if it doesn't, split it across slides.
- Build it as a real table, never out of text boxes.

People read tables and charts differently. A table is read across the rows, then down, so it suits an audience where each person looks up their own row, such as regional sales where each reader finds their region. In a live presentation a table hides the point in detail. A full table in the appendix serves pre-reads and questions. Charts make a point faster and suit executive audiences. Use charts for the message and tables for reference.

## Footnotes and sources

Footnotes do two jobs.

The first is citing sources. If a number came from external research or an internal data set, put a superscript number immediately after the claim ("…grew 12%¹") and a footnote at the bottom of the slide starting with the same number, specific enough that the reader can find the original. Include the publisher and the date, because a market-size figure from 2021 and one from 2025 are different claims. Put hyperlinks behind the reference text rather than pasting raw URLs. Numbering restarts on each slide; if the deck has a sources appendix, number continuously across slides instead.

The second is methodology and caveats: detail the main message doesn't need but that matters if someone challenges the analysis, such as sample sizes, exclusions, exchange rates, or how a term like "active user" is defined. Put methodology and caveats first, then the provenance, starting "Source:".

Keep the citation format the same across the deck. Footnotes sit at the bottom of the slide at 10–12pt in a muted color. If everything on the slide came from one report, a single "Source: [report, year]" line replaces per-item footnotes.

Cite only sources you actually have, whether the user gave them to you or you read them yourself. Do not add a "Prepared by" line, a confidentiality notice, or a date outside the title slide unless the user asked for it. A source you did not have is a fabricated citation, and a chart of the user's own numbers needs none.

## Size, spacing and placement

**Visual hierarchy and size.** The reader's eye should land on the title first, then the main visual or the bold text, then the detail. Size and weight control that order. Slides are read from the back of a room, so sizes that look right on a web page are too small here. On a standard 16:9 slide:

| Element | Size |
|---|---|
| Slide title | 32–40pt bold, at least about 1.75× the body |
| Section header | 24–28pt |
| Body text | 16–18pt |
| Captions | 14pt |
| Footnotes and source lines | 10–12pt, muted |

Footnotes, source lines, the second line of a chart label, a chart's year row (11pt) and chart callouts (11–12pt) are the only text you add below 14pt, with one exception: a template whose own body text is smaller, which is common in banking and consulting decks. Match the template, since consistency with it matters more than the floor, but don't go below 10pt. Set sizes explicitly instead of leaving them to defaults.

**Fitting text.** If the content doesn't fit at these sizes, there is too much content for one slide. Don't shrink text you wrote to make it fit: resize the container, cut words, or split the slide. Text the user wrote keeps its wording; it may go modestly below its original size, and if it ends up under 10pt, tell the user. Never leave text overflowing its box or cut off.

**Use the slide.** Keep a margin of about half an inch on every side. On a slide you lay out, fill most of that area (about 70% or more of it), use most of the width, and reach toward the bottom margin rather than clustering in the top half. Open space under a short list is fine; a slide that is all margin is not. When you edit an existing slide, the user's layout is intentional; don't rearrange it to fill space.

**Spacing.** Leave 0.3–0.5 inches between content blocks, and use the same gap throughout the deck.

**The title band.** Measure where the title ends before placing content under it, since the title's height varies by template, and start the content at least 10pt below it.

**Insets.** Text on a shape or a card is inset 10–15pt from the shape's edges. Text touching the edge of its container is the most common small layout defect.

**Alignment.** Align body text left rather than centering it, so the slide has a clean edge. Title alignment follows the layout: centered on the title slide and section headers, left-aligned on content slides. A template's own title alignment always wins.

## Clutter, emphasis and variety

**Clutter.** Every element on a slide costs the audience attention. Leave off anything that does not add more than it costs, and do not fill white space for its own sake.

**Highlighting when a slide has to be dense.** Sometimes a slide or a chart has to be complicated. You can still get the message across by directing attention. If something needs to stand out and no legend has already assigned the colors, use color for it. Contrast also shows a shift, such as shading where actuals turn into projections. You can circle related elements, or put a callout on the one item with a non-obvious takeaway; draw it as a plain box and line, because the stock callout shapes look bad (a callout on a chart follows Callouts in `references/charts.md` instead, with no box). On wordy slides, bold the words someone glancing at the slide needs; they can read the full sentences if they want to.

**Variety.** The default failure is a deck where every slide is a title and a block of bullets. Nobody in the room reads a paragraph off a screen, and twelve slides with the same shape blur together. Bullets should be the minority. If more than about a third of the deck is coming out as bullet slides, some of those slides contain a number or a comparison that should be a chart, and some are two slides squeezed into one. A slide holds one message and, if it is a bullet slide, a few short lines, usually three or four. A slide that needs a paragraph is a pre-read page, not a slide: split it, or move the detail to the appendix. Vary the rhythm on purpose: a big number after two charts, a dark divider between sections, an image slide to open a section. Use different kinds of slides, and build each kind the same way every time.

## Writing slide copy

These rules cover the words you put on slides: titles, bullets, labels, callouts and footnotes.

Slide copy should read as though a person wrote it. When readers think something was written by AI, they judge it as sloppy and stop trusting it, whatever the content. They make that judgment from a set of common indicators, listed below, so take extra care to keep them out of your writing.

- Say what is true without first denying something else. "Revenue grew 12%, three times the US rate," not "This isn't a growth story, it's a market-share story." Do not open a title or bullet with "Here's the thing" or "The real story is". A title can be a question when the slide is there to raise it; when the slide answers it, the title is the answer.
- Match the number of bullets, examples, and adjectives to the content, not to a default of three. Two drivers get two bullets; five get five or a table. A list of exactly three ("fast, reliable, and scalable") usually means the third item was added for rhythm, not because there were three things to say, and readers read it as filler.
- Do not use a metaphor where a literal word will do. If a plain description exists ("the same construction," "the same pattern," "slowed," "fell"), use it. Metaphors are for when the literal version would be longer or less precise, which is rare in analytical writing. Test: if the metaphor can be replaced by a plain word without losing meaning, replace it. A metaphor makes the reader translate it back into the plain claim and carries meaning you did not choose. The ones that appear most are "north star", "move the needle", "double-click" (meaning look closer), "unpack", "journey", and "landscape" (meaning a market). Common ones in business writing: "moat", "headwind", "drag" (meaning a cost on results), "safety net", "clears the bar", and "land" meaning finish or total ("lands $4.4k under budget"). Examples:
  - Bad: "The ones it has are the same species." Good: "The ones it has follow the same pattern."
  - Bad: "A coordinated digestion pause would be visible immediately." Good: "If several large customers cut capex in the same quarter, it would show up in the next guide."
  - Bad: "Architecture transitions compressed margin on the way in and expanded it on the way out." Good: "Gross margin fell during the Hopper-to-Blackwell ramp and recovered once Blackwell shipped at volume."
  - Bad: "The lever that unlocks growth." Good: "The pricing change is what makes the target reachable."
- Cut words that claim importance without giving evidence: "genuinely", "truly", "actually", "clearly", "significantly", "robust", "leverage", "delve", "actionable insights", "learnings". Where one of them stood in for a fact, put the fact there ("margins fell 4 points", not "margins fell significantly"); otherwise delete it.
- Use full stops and commas, and a colon before a list. No emoji on slides.
- Use em dashes sparingly: at most one in a paragraph, and none in a heading, a title, or between a bold label and the text after it. Several em dashes in one paragraph is one of the first things readers use to spot machine writing. In place of one, use a comma, a colon, parentheses, or a new sentence, not an en dash or a spaced hyphen.
- On content slides, write headings as findings (see "Message: the title" above), not as a description of your process: "Europe missed plan by $1.9M", not "What I changed" or "The hard part". Structural slides (agenda, executive summary, next steps, appendix) keep a plain label.
- Keep the conversation out of the deck. When the user asks for a shorter or more formal version, make it shorter or more formal; do not title it "Executive Summary (Condensed)" or open with "Updated per your feedback" or "this streamlined deck focuses on". The audience did not see the request, so those lines mean nothing to them. Say what changed in your reply, not in the deck.
- Write in the language variety the deck already uses (US or UK English, for example), or the user's when the deck has no text yet; never mix varieties in one deck.

## Common mistakes

- **Accent lines under titles.** These are a hallmark of AI-generated slides; use white space or a background color instead.
- **Decorative color bars or accent stripes:** header or footer bars across the slide, vertical stripes down one edge, thin stripes along one edge of a card, single-side borders on rectangles. They read as filler. To set a card apart, use a light background tint, a soft shadow, or an icon.
- **Low contrast.** Icons and text need strong contrast against their background: no light text on a light background or dark text on a dark one.
- **Styling one slide and leaving the rest plain.** Apply the design to every slide, or keep every slide simple.

# Slides connector

This part covers the Slides connector: `read_presentation`, `read_slide_page`, `read_slide_page_thumbnail`, and `update_presentation`. Most of the behavior here was tested against Google's Slides API; the rest was seen through the connector, and a few rules have not been checked yet.

## Applying the design rules

The design rules are above. What follows is specific to building with `update_presentation`.

- **Building a new deck.** When you build a new deck with `update_presentation`, use two or three calls, not one call per slide. In the first call, fill the title slide's `i0` and `i1` placeholders (`insertText`, appended to `build`'s output) and add the first content slide with `build`, so the user has something to look at early; add the remaining slides in one or two more calls. Each call holds everything for its slides in one batch. Read the deck before every call, the first included, and run `build` with that read's `revisionId` so every call is guarded (see "Read before you edit, and guard the write" in SKILL.md); the read that checks one call's slides can supply the next call's `revisionId`.
- **Titles on the default page.** The type sizes above apply on the default 10 in wide page too, where a title line holds fewer words than on a wider slide. By `build`'s estimate, a bold 32 pt line in a 9 in wide box holds about 38 characters, so two lines hold about 75 characters, roughly twelve words. A two-line title needs a box about 1.3 in tall at 32 pt; if it needs more than two lines, cut words rather than shrink the font. `build` warns when a title needs more lines than its box holds.
- **Layouts.** `build` creates each new slide on the predefined layout the spec names (`BLANK` when it names none) and draws its own text boxes, without filling the layout's placeholders. For a slide with a title and text in a deck that has layouts, create the slide with the placeholder recipe in Edit recipes, so the title and body take the master's style, then add tables, cards and shapes with `build` and `"existing": true`. Use `build`'s `BLANK` slides for slides that are entirely visual, as the layout rules above say.
- **Masters.** This reference has no tested recipe for changing a deck's master or theme, so skip the master steps in "Starting from the deck's design". On a new deck, give the elements you add the same fonts and colors on every slide, and put a background or logo on each slide that needs it. For a restyle, change each slide directly and tell the user the master is unchanged.
- **Warnings.** `build` warns about text under 14 pt unless it is a footer line: a box at most 0.5 in tall that ends within 0.8 in of the bottom of the slide. The design rules allow some other small text: the second line of a chart label, a chart's year row and callouts, a source line that isn't a footer line, and text matched to a template's smaller size. Those warnings can stay; fix every other warning.
- **Fonts.** Use Google fonts, such as Arial, Roboto, Lato, Montserrat, or Merriweather.
- **Tables.** `"header": true` bolds the header row. Leave `header_fill` and `header_color` unset, because the design rules give the header row bold text and nothing else, and set `"col_align"` to `"END"` for number columns. Bold the first column with `updateTextStyle` and `cellLocation` (Tables in Edit recipes), appended after `build`'s requests, since `build` sets every cell outside the header row to not bold. This reference has no tested way to set the row-only borders the design rules ask for: `build` sets no borders, and no border request has been tested through the connector, so a new table keeps the theme's default borders.
- **Charts.** A linked Sheets chart takes its look from the chart in the Sheet, so build it there to the standard `references/charts.md` picks: the deck's chart style when its charts share one, otherwise the house standard. Under the house standard, leave the chart's title off and put its label in a text box above it on the slide. This reference has no tested way to label only chosen points in a Sheets chart, or to draw line-end names, a year row, callouts or growth arrows there, so put those on the slide as text boxes and shapes, and check their positions on the rendered slide.

## Create

Choose a route based on the deck.

- **A designed deck:** load the `pptx` skill, build a .pptx with it, and check it with that skill's QA steps. Then upload it with Drive `create_file` and let Drive convert it. The file's whole content goes inside the tool call, so the upload is slow and can fail for a large deck. You get the `pptx` skill's design tools and QA. Conversion can change fonts and spacing, so run the QA steps below on the result.
- **A few slides, or slides added to an existing deck:** create a blank presentation with Drive `create_file` and `contentMimeType: "application/vnd.google-apps.presentation"` (or open the existing deck), then build with `update_presentation`, using `slides_helper.py build` below. A new deck starts with one title slide whose placeholders are `i0` (title) and `i1` (subtitle). Fill them, or delete the slide with `deleteObject`.

## How a slide is addressed

- **Units are EMU:** 914400 per inch, 12700 per point. The default 16:9 page is 9144000 x 5143500 EMU (10 x 5.625 in). Read `pageSize` before placing anything; some decks are 4:3 or custom.
- **An element's real size is `size` times its transform scale.** The API often stores a 3000000 x 3000000 base size and scales it: a title that renders 9.32 in wide can report `size.width` of 3000000 (3.28 in) with `scaleX` 2.84. Position is `translateX` / `translateY`, the top-left corner. Always multiply before reasoning about layout.
- **A table's size comes from its columns and rows.** A table's `size` field is not its rendered size. Sum `tableColumns[].columnWidth` and `tableRows[].rowHeight` instead. Rows grow taller to fit their text, so a table can end up taller than requested.
- **Object IDs are yours to choose.** When creating a slide or element, set `objectId`: 5 to 50 characters, unique in the deck, letters, digits, `_`, `-` and `:`, starting with a letter, digit or `_`. Name them by slide and role (`s4_title`, `s4_chart`) so later requests in the same batch, and later turns, can target them.
- **Text inside a shape or table cell has its own index,** starting at 0. `textRange: {"type": "ALL"}` covers all of it and is the safest target for styling. `insertText` without `insertionIndex` inserts at 0, before the existing text; to append, pass the text's length in UTF-16 units, not counting the final newline the read shows. Unlike Docs, Slides gives no error for an index inside an emoji such as 🙂: it moves an insert past the emoji and widens a delete to the whole emoji.

## Read

- **Always pass a field mask.** An unmasked read returns every layout and master: 150 KB for a three-slide deck. This mask returns what editing and the helper need, about 5 KB for the same deck:

```json
["revisionId,pageSize,layouts(objectId,layoutProperties.name),slides(objectId,slideProperties.layoutObjectId,pageElements(objectId,size,transform,shape(shapeType,placeholder,text.textElements(textRun(content,style.fontSize,style.bold))),table(rows,columns,tableColumns,tableRows(rowHeight,tableCells(location,text.textElements.textRun.content))),image.contentUrl,sheetsChart(spreadsheetId,chartId),line.lineType,elementGroup.children.objectId))"]
```

  Unlike the Sheets connector, Slides accepts parentheses in masks.
- **One slide:** `read_slide_page` with a `pageId` and a mask starting at `pageElements(...)`.
- **Text only:** Drive `read_file_content` gives the deck's text compactly when you only need to know what it says.
- **Outline with real geometry:** save the masked read to a file and run:

```
python <skill>/scripts/slides_helper.py outline deck.json
[3] slide s4_slide  layout BLANK
  s4_title   shape  x=0.50 y=0.35 w=9.00 h=0.70  TEXT_BOX 32pt 'Revenue grew 42% year over year'
  s4_table   table  x=3.70 y=1.30 w=5.80 h=1.20  2x3 first row ['Metric', 'Q1', 'Q2']
  s4_note    shape  x=0.50 y=4.60 w=4.00 h=0.30  TEXT_BOX 12pt 'This footnote is...'  !! TEXT MAY OVERFLOW (needs ~0.80 in)
```

  It flags elements off the page, boxes that overlap, text that probably overflows its box, and empty placeholders. "inherited size" means the font size comes from the layout, so the overflow check is skipped for that box. An overlap flag means the boxes intersect; check the render to see whether the content actually collides.

## Build slides

Build new slides and elements from an inch-based spec with `slides_helper.py build`. It converts to EMU, sets unscaled transforms, checks IDs, styles text, fills tables, and warns about text that won't fit.

```json
{"slides": [
  {"id": "s4_slide", "layout": "BLANK", "index": 3,
   "elements": [
     {"id": "s4_title", "type": "text", "x": 0.5, "y": 0.35, "w": 9, "h": 0.7,
      "text": "Revenue grew 42% year over year", "size": 32, "bold": true, "color": "#1F2937"},
     {"id": "s4_card", "type": "round_rect", "x": 0.5, "y": 1.3, "w": 2.8, "h": 1.6,
      "fill": "#E8EEF7", "text": "ARR\n$4.2M", "size": 24, "bold": true, "color": "#1F3864", "align": "CENTER"},
     {"id": "s4_table", "type": "table", "x": 3.7, "y": 1.3, "w": 5.8, "size": 14,
      "rows": [["Metric", "Q1", "Q2"], ["ARR", "$3.0M", "$4.2M"]],
      "header": true, "col_align": ["START", "END", "END"]}]},
  {"id": "s3_slide", "existing": true,
   "elements": [{"id": "s3_label", "type": "text", "x": 0.5, "y": 2.1, "w": 4, "h": 0.5,
                 "text": "of pilots converted", "size": 16}]}]}
```

```
python <skill>/scripts/slides_helper.py build spec.json --revision <revisionId> [--page 10x5.625]
```

The output is the full `requests` and `writeControl` for `update_presentation`; warnings go to stderr. Fix every warning before sending, apart from the small-text ones that "Applying the design rules" allows. Slides never shrinks text to fit, so a warned box will spill. Build also warns about text boxes and shapes under 14 pt that aren't a short footer line at the bottom of the slide, and about typed bullet marks. Element types: `text`, `rect`, `round_rect`, `ellipse`, `table`. On a text element, `"bullets": true` makes each line a bullet and `"space_below"` adds points after each paragraph (about 8 to 10 points suits bulleted lines). On a table, `"col_widths"` sets each column in inches (give a label column more room than number columns) and `"col_align"` aligns each column (`"END"` for numbers). Set `"existing": true` to add elements to a slide that already exists. Pass `--page` when the deck isn't 10 x 5.625 in.

## Edit recipes

Each recipe is part of one `update_presentation` call. Send the call with `writeControl.requiredRevisionId` from a read taken after your last write, unless every request in it comes from **Change text everywhere**.

**Change text everywhere.** `replaceAllText` with `containsText: {"text": ..., "matchCase": true}` needs no IDs. Limit it with `pageObjectIds` to change only some slides. Use `{{placeholders}}` in templates for this.

**Replace one box's text.** `deleteText` with `textRange: {"type": "ALL"}`, then `insertText` at `insertionIndex: 0`. The new text keeps the box's style. Deleting from an already-empty box fails, so check the read first.

**Use a layout's placeholders.** `createSlide` with `slideLayoutReference: {"predefinedLayout": "TITLE_AND_BODY"}` and `placeholderIdMappings` naming the placeholders you'll fill:

```json
{"createSlide": {"objectId": "s2_slide", "insertionIndex": 1,
  "slideLayoutReference": {"predefinedLayout": "TITLE_AND_BODY"},
  "placeholderIdMappings": [
    {"layoutPlaceholder": {"type": "TITLE", "index": 0}, "objectId": "s2_title"},
    {"layoutPlaceholder": {"type": "BODY", "index": 0}, "objectId": "s2_body"}]}}
```

Then `insertText` into `s2_title` and `s2_body`. Placeholder text takes the theme's font and size, which keeps the deck consistent. Predefined layouts include `TITLE`, `TITLE_AND_BODY`, `TITLE_AND_TWO_COLUMNS`, `TITLE_ONLY`, `SECTION_HEADER`, `BIG_NUMBER`, and `BLANK`. A deck with a custom theme may name its layouts differently; the masked read lists them, and `slideLayoutReference: {"layoutId": ...}` picks one by ID. Fill or delete every placeholder you create, because an empty one shows prompt text in the editor.

**Bullets.** Insert lines separated by real newlines, then `createParagraphBullets` with `textRange: {"type": "ALL"}` and `bulletPreset: "BULLET_DISC_CIRCLE_SQUARE"`. Typed "- " is text, not a bullet, and `createParagraphBullets` keeps typed markers as text, so leave them out of the inserted lines.

**Style text.** `updateTextStyle` with `style` and a matching `fields` list, such as `"fontSize,bold,foregroundColor"`. Font size is `{"magnitude": 24, "unit": "PT"}`; color is `{"opaqueColor": {"rgbColor": {"red": ..., "green": ..., "blue": ...}}}` with values from 0 to 1. Alignment is a paragraph property: `updateParagraphStyle` with `style.alignment` (`START`, `CENTER`, `END`, `JUSTIFIED`).

**Shape fill and outline.** `updateShapeProperties` with `shapeBackgroundFill.solidFill.color` and `outline.propertyState: "NOT_RENDERED"` to drop the border.

**Move or resize.** `updatePageElementTransform` with `applyMode: "ABSOLUTE"` and a full transform. Remember that the element's base `size` stays the same, so set `scaleX` / `scaleY` to the rendered size divided by the base size. Moving is safer than resizing: to resize a text box, it is often simpler to delete it and create a new one at the right size.

**Tables.** `insertText` and `updateTextStyle` take `cellLocation: {"rowIndex": r, "columnIndex": c}`. `updateTableCellProperties` with a `tableRange` sets cell fills. `insertTableRows`, `deleteTableRow`, `insertTableColumns`, and `deleteTableColumn` change structure. `updateTableColumnProperties` sets column widths in EMU.

**Charts from Sheets.** `createSheetsChart` with the sheet's `spreadsheetId`, the `chartId` (from the Sheets `addChart` reply, or from `get_spreadsheet` with `fields: ["sheets.properties.title", "sheets.charts.chartId", "sheets.charts.spec.title"]`), `linkingMode: "LINKED"`, and `elementProperties`. A linked chart stays tied to its data; `refreshSheetsChart` updates it after the sheet changes. Don't paste a chart as an image.

**Images.** `createImage` needs a URL Google can fetch publicly. For a local image, build the slide in a .pptx with the `pptx` skill and upload it, or ask the user to insert the image.

**Reorder, copy, delete.** `updateSlidesPosition` with `slideObjectIds` and `insertionIndex`; `duplicateObject` for a slide or element (set `objectIds` to name the copies); `deleteObject` for either. List `slideObjectIds` in the slides' current order in the deck, or the whole batch is rejected; the listed slides move as a block and keep that order. `duplicateObject` puts each copy directly after the original, so copying one slide several times leaves the copies in the reverse of the order you sent the requests. To make several copies in a chosen order in one batch: duplicate the original once per copy, sending the requests in the reverse of that order, so the copies end up after it in the order you want. Fill them. If they belong elsewhere in the deck, move them as a block with one `updateSlidesPosition` that lists them in that order. Delete the original if it was a template.

## Verify

1. Read the deck with the mask above and run `slides_helper.py outline`. Check the text, slide order, and every flag.
2. Where you can run code, look at the rendered slides. Export with Drive `download_file_content` and `exportMimeType: "application/pdf"`; a large result is saved to a file. If the export comes back in the chat instead, skip the render rather than copying it into a file. Otherwise:

```
python <skill>/scripts/render_export.py <saved export> render --pages 3-4
```

   Open each page image and check for overflow, overlap, clipped text, and low contrast. `read_slide_page_thumbnail` returns an image URL instead; use it only if your surface can open image URLs, since some environments can't.
3. Fix the problems, then check again. If you can't run code or render, rely on step 1 and tell the user you couldn't check the layout visually.

## Slides failures

| Symptom | Cause | Fix |
|---|---|---|
| A read is 100 KB or more | No field mask, so layouts and masters came back | Use the mask in Read. |
| Elements land in the wrong place or size | Base `size` used without the transform scale | Use `slides_helper.py outline` for real geometry, and `build` for new elements. |
| A table is a different size than requested | Table size comes from columns and rows, and rows grow with text | Read `tableColumns` and `tableRows`; set widths with `updateTableColumnProperties`. |
| Text spills out of its box | Slides doesn't shrink text | Enlarge the box, cut the text, or split the slide (Fitting text above says when a smaller size is allowed). `build` warns before you send. |
| `The object ID (ab) length should not be less than 5`, or a duplicate ID error | IDs too short, reused, or with invalid characters | Use descriptive IDs such as `s4_title`, unique per deck. |
| `Unknown dimension unit UNIT_UNSPECIFIED` | A size or transform without `unit: "EMU"`, or a new shape with no size | Give every new element a full `size` and `transform` with units. `build` does this. |
| Prompt text such as "Click to add title" appears | An empty placeholder | Fill it or delete it. `outline` flags these. |
| `createImage` fails | The URL isn't publicly fetchable | Use a public URL, or the .pptx upload route. |
| `deleteText`: `The startIndex 0 must be less than the endIndex 0` | The box has no text to delete | Skip the delete when the read shows no text. |
| `createSlide`: `The placeholder (…) is not on the page` | `placeholderIdMappings` names a placeholder the layout doesn't have | Map only the placeholders that layout has; `TITLE_ONLY` has no `BODY`. |


---

## Ek: md dışındaki dosyalar

Aşağıdaki dosyalar `skills/google-workspace/` klasöründe özgün hâliyle yer alır:

- `scripts/docs_index.py`
- `scripts/render_export.py`
- `scripts/sheets_helper.py`
- `scripts/slides_helper.py`
