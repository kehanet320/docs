# word-ileri-ustasi

---
name: word-ileri-ustasi
description: Word'ün profesyonel otomasyon ve şablon mimarisi için kullanılır. Kullanıcı "Word makro", "VBA", "Word otomasyonu", ".dotm", ".dotx şablon", "Building Blocks", "Hızlı Parçalar", "Content Control", "form alanı", "Quick Parts", "Mail Merge", "adres mektup birleştirme", "toplu yazı", "StyleRef", "PAGEREF", "alan kodu yazımı", "AutoText", "şablonlu üretim", "Word XML", "Document Property", "Word Add-in", "Ribbon özelleştir" ifadelerinden birini kullandığında devreye girer. Mevcut word-ileri skill'inin üzerine kurulan uzman katman: kurumsal şablon mimarisi, makroyla otomatik belge üretimi, mail merge ile toplu yazışma, dağıtılabilir şablon paketleri.
---

# Word İleri Ustası

## Genel İlke

**Bir belgeyi yazmak başka, bir belge fabrikası kurmak başka.**

Bu skill, mevcut **word-ileri** skill'inin üzerine inşa edilir. Önkoşul: o skill'in stiller, içindekiler, üstbilgi/altbilgi, bölüm sonları ve temel alan kodları bölümlerine hâkim olmak. Burada anlatılanlar **gerçek üretim ortamı** içindir: bir kurumun aylarca kullanacağı şablonlar, makroyla saniyede üretilen 500 sayfalık raporlar, mail merge ile 1.000 personele kişiselleştirilmiş yazı, kontrollü form belgeleri.

**Hedef seviye:** Tek belge yazmak değil; **belge yazılışını otomatikleştirmek**. Memurun her seferinde aynı klavye hareketini yapmasını bitirmek.

---

## Bu Skill Ne Zaman Devreye Girer?

| Durum | Bu skill mi, word-ileri mi? |
|-------|----------------------------|
| "Bir Word belgesi düzgün biçimlendirilsin" | **word-ileri** |
| "İçindekiler nasıl yapılır" | **word-ileri** |
| "Şablon (.dotx) oluşturmak istiyorum, temel düzeyde" | **word-ileri** (Bölüm 9) |
| "Şablon kullanan kişi sadece belirli alanları doldursun" | **bu skill** (Bölüm 1 - Content Controls) |
| "Aynı yazıyı 200 kişiye, adlarıyla göndereceğim" | **bu skill** (Bölüm 3 - Mail Merge) |
| "Bir Word makrosu yazmam lazım" | **bu skill** (Bölüm 4 - VBA) |
| "Excel verisinden Word belgesi üretmek istiyorum" | **bu skill** (Bölüm 4.6 - Excel→Word) |
| "Şablonu 30 personele dağıtacağım, hepsi aynı görünsün" | **bu skill** (Bölüm 7 - Dağıtım) |
| "Üstte 'şu anki Başlık 1' yazsın" | **bu skill** (Bölüm 2 - StyleRef) |

---

## BÖLÜM 1: İçerik Denetimleri (Content Controls)

### 1.1 Nedir?

Şablona koyduğun **kontrollü doldurma alanları**. Kullanıcı belgeyi açar, sadece o alanlara tıklar, başka yere yazamaz. **EBYS şablon yönetiminde devrimsel.**

**Eski yöntem:** "[Tarih buraya]" yazıyorsun, kullanıcı silmeyi unutuyor, üzerine yazıyor ama biçim bozuluyor.

**Yeni yöntem:** "Tarih:" yazıp yanına bir **Date Picker Content Control** ekliyorsun. Kullanıcı tıklayıp tarihi seçiyor, biçim hep doğru.

### 1.2 Etkinleştirme

**Dosya → Seçenekler → Şeridi Özelleştir → Geliştirici** kutusunu işaretle.

Şeritte **Geliştirici** sekmesi çıkar. İçerik denetimleri buradadır.

### 1.3 Content Control Türleri

| Tür | Ne işe yarar | EBYS kullanım örneği |
|-----|--------------|----------------------|
| **Rich Text** | Biçimli metin girilebilir | Konu içeriği |
| **Plain Text** | Sadece düz metin (biçim alamaz) | Ad-soyad |
| **Picture** | Resim eklenir | Logo, imza taraması |
| **Building Block Gallery** | Önceden kayıtlı parçalardan seçer | Sonuç ifadesi seçimi |
| **Combo Box** | Açılır liste + yazılabilir | Birim adı |
| **Drop-Down List** | Sadece listeden seç | İl, kurum türü |
| **Date Picker** | Tarih seçici takvim | Yazı tarihi |
| **Check Box** | Onay kutusu | "Ekli/Eksiz" |
| **Repeating Section** | Çoğaltılabilir bölüm | İlgi maddeleri (1., 2., 3.) |

### 1.4 Drop-Down List Oluşturma — Pratik

Senaryo: Yazıyı imzalayacak makam birden fazla, her seferinde elle yazmak hatalı.

**Adımlar:**

1. İmza yerine tıkla, **Geliştirici → Drop-Down List Content Control** ikonuna bas.
2. Eklenen kutuya **sağ tık → Özellikler**.
3. **Title:** "İmzalayan Makam" — kullanıcıya görünen etiket.
4. **Tag:** "imzaMakam" — programatik erişim için ad.
5. **Drop-Down List Properties → Add** ile maddeleri ekle:
   - Daire Başkanı
   - Genel Müdür Yardımcısı
   - Genel Müdür
   - Müsteşar Yardımcısı
6. **Content control cannot be deleted** kutusunu işaretle (kullanıcı silemesin).
7. **Tamam**.

Artık o şablonu kullanan herkes listeden seçer, yazım hatası olmaz.

### 1.5 Repeating Section — Çoğaltılabilir Bölüm

EBYS yazısında **ilgi maddeleri** sayısı belirsiz. Kimi 1 ilgi, kimi 5 ilgi. Repeating Section bunun için yapılmıştır.

**Adımlar:**

1. Tek satır ilgi bloğu yaz (sıra numarası dahil):
   ```
   a) [Kurum adı]'nın [tarih] tarihli ve [sayı] sayılı yazısı.
   ```
2. Bu bloğu seç → **Geliştirici → Repeating Section Content Control**.
3. Kullanıcı belgeyi açtığında sağda artı (+) görür. Tıklayınca **aynı blok bir alt satıra** eklenir.

### 1.6 Locking — Belgeyi Kontrolle Sınırlama

Şablon güvenliği için **Restrict Editing** kullanılır:

**Geliştirici → Restrict Editing → "Allow only this type of editing"** → "Filling in forms" seç → **Yes, Start Enforcing Protection**.

Artık kullanıcı **sadece Content Control'lere** yazabilir. Belgenin geri kalanı dokunulmaz. Parola koyulabilir, koyulmaz da; her ikisi de çalışır.

**EBYS şablon kalitesi açısından kritik:** Memur belgenin "İlgi" yazısını yanlışlıkla silemez.

---

## BÖLÜM 2: İleri Alan Kodları

Mevcut **word-ileri** skill'i temel alan kodlarını (DATE, PAGE, NUMPAGES, TOC) gösterdi. Burada üretim ortamı için kritik olanları:

### 2.1 STYLEREF — Üst Bilgiyle Akıllı Başlık

Her sayfanın üstünde "Şu anki bölümün adı" yazsın. Kullanıcı sayfa çevirdikçe otomatik değişsin.

Üstbilgi alanına gir, **Ekle → Hızlı Parçalar → Alan → StyleRef** seç → "Başlık 1" stilini seç. Word'ün alan kodu görünümünde:

```
{ STYLEREF "Başlık 1" \* MERGEFORMAT }
```

Artık sayfanın üstünde o sayfanın **en son geçtiği "Başlık 1"** yazar. Kitaplarda, uzun raporlarda standart.

### 2.2 REF — Belgenin Başka Yerine Referans

Belgenin bir yerinde "Bkz: Bölüm 3" yazıyorsun ama Bölüm 3'ün numarası değişebilir (yeni bölüm araya girerse Bölüm 4 olur). Otomatik güncellensin.

**Adım 1:** Bölüm 3 başlığını seç → **Ekle → Yer İmi (Bookmark)** → ad ver: "Bolum3".

**Adım 2:** "Bkz:" cümlesinde:

```
Bkz: { REF Bolum3 \n }  
```

`\n` ekleyince başlık numarasını getirir. `\p` sayfa numarası, `\h` köprü olarak ekler.

### 2.3 PAGEREF — Sayfa Numarası Referansı

```
"Detaylı bilgi için bkz. sayfa { PAGEREF Bolum3 }."
```

Bölüm 3'ün bulunduğu sayfayı dinamik gösterir. Belge sayfalanması değiştikçe otomatik güncellenir.

### 2.4 SEQ — Otomatik Numaralandırma

Şekil, tablo, denklem için. "Şekil 1, Şekil 2, Şekil 3" otomatik.

```
Şekil { SEQ Sekil \* ARABIC } - Logo
Şekil { SEQ Sekil \* ARABIC } - Organigram
```

Arada yeni bir Şekil eklersen — sıralama otomatik kayar. Manuel numara hatalarını sıfıra indirir.

### 2.5 IF — Koşullu Metin

Mail merge senaryosunda kritik. Personelin medeni durumuna göre farklı metin:

```
{ IF { MERGEFIELD Medeni } = "Evli" "Eşinizle birlikte" "Sizin için" }
```

### 2.6 DOCPROPERTY — Belge Özelliği

Belgenin **kendi özellikleri** (yazar, başlık, konu) Word'ün **Dosya → Bilgi → Özellikler** kısmında tutulur. Bunlara alan kodu ile erişilir:

```
{ DOCPROPERTY "Author" }
{ DOCPROPERTY "Title" }
{ DOCPROPERTY "BirimAdi" }   ' Özel özellik
```

**Özel özellik tanımlama:** Dosya → Bilgi → Özellikler → **Gelişmiş Özellikler → Özel** → ad, tip, değer ver.

**Pratik kullanım:** Şablona koy → Yeni belge açıldığında kullanıcı sadece "Belge Özellikleri"nden birim adı yazar → tüm belgede otomatik yansır.

### 2.7 ASK ve FILLIN — Açılışta Soru Sor

Belge açılışında kullanıcıya soru sorulup cevabı belgeye yerleştirilir:

```
{ ASK BirimAdi "Birim adını girin" \d "Genel Müdürlük" }
{ BirimAdi }
```

Belge açılırken kullanıcıya bir dialog çıkar, cevabı `BirimAdi` adlı **yer imine** koyar. Sonra `{ BirimAdi }` ile belgenin istediğin yerinde kullanırsın.

**FILLIN** benzer ama her tetiklemede tekrar sorar:

```
{ FILLIN "Sayı numarasını girin" }
```

### 2.8 Alan Kodlarını Görme ve Düzenleme

| Tuş | Ne yapar |
|-----|----------|
| **Alt+F9** | Tüm alan kodlarını **kod olarak** veya **sonuç olarak** göster (toggle) |
| **F9** | Seçili alanı **güncelle** |
| **Ctrl+A → F9** | Tüm belgenin alanlarını güncelle |
| **Ctrl+F9** | İmlecin olduğu yere **boş alan parantezi `{ }`** ekle (manuel kod yazımı için) |
| **Shift+F9** | Bir alanın kodunu/sonucunu toggle (sadece o alan) |
| **F11** | Sonraki alana git |
| **Ctrl+F11** | Alanı **kilitle** (güncellenmesin) |
| **Ctrl+Shift+F11** | Alan kilidini aç |

**Manuel alan kodu yazımı:**

Doğrudan klavyeden `{` yazma — bu Word'e alan değil. **Ctrl+F9** ile gerçek alan parantezini ekle, içine yaz.

---

## BÖLÜM 3: Mail Merge (Adres Mektup Birleştirme)

### 3.1 Hedef

Tek bir mektup şablonu + Excel listesi → her satır için kişiselleştirilmiş ayrı belge. **EBYS dağıtımı**, davet yazısı, sertifika, etiket basımı için kullanılır.

### 3.2 Senaryo

Excel'de personel listesi:

| TCKN | Ad | Soyad | Unvan | Birim | Sicil No |

Word'de tek bir hizmet belgesi şablonu. Çıktı: 500 personel için 500 ayrı belge — her birine kendi bilgisi yazılı.

### 3.3 Adımlar

**Adım 1:** Word'de şablonu hazırla:

```
T.C.
KURUM ADI

HİZMET BELGESİ

Sicil No: «SicilNo»
Adı Soyadı: «Ad» «Soyad»
Unvanı: «Unvan»
Görev Yeri: «Birim»

Yukarıda kimliği belirtilen personel kurumumuzda görev yapmaktadır.

Tarih: ……………
İmza: ……………
```

Buradaki «…» işaretleri **MERGEFIELD** alan kodları. Henüz oluşmadı — sonra ekleyeceğiz.

**Adım 2: Mailings → Start Mail Merge → Letters**

**Adım 3: Mailings → Select Recipients → Use an Existing List** → Excel dosyasını seç.

**Adım 4:** Excel'de hangi sayfayı kullanacağını sor — seç. Word veri kaynağını bağlar.

**Adım 5: Mailings → Insert Merge Field** ile her alanı yerleştir. Şablon yerinde «Ad» «Soyad» «SicilNo» «Unvan» «Birim» görünür.

**Adım 6: Mailings → Preview Results** — gerçek verinin nasıl göründüğünü gör. Sağdaki ok ile satırlar arası gez.

**Adım 7: Mailings → Finish & Merge:**

- **Edit Individual Documents** → 500 sayfalık tek belge (her sayfada bir kişi)
- **Print Documents** → Doğrudan yazıcıya
- **Send Email Messages** → E-posta ile (Outlook ile entegre)

### 3.4 Filtreleme

500 kişiden sadece **belirli bir birimdeki**lere göndermek istersen:

**Mailings → Edit Recipient List → Filter** → "Birim alanı = X" filtresi koy. Sadece eşleşenler için belge üretilir.

### 3.5 Koşullu Metin Mail Merge'de

Erkek ve kadın personele farklı hitap:

```
Sayın { IF { MERGEFIELD Cinsiyet } = "K" "Bayan" "Bay" } { MERGEFIELD Soyad },
```

### 3.6 Toplu E-posta Gönderimi

Mail Merge → Finish & Merge → **Send Email Messages**:

- **To:** Excel listesindeki "E-posta" sütununu seç
- **Subject:** "Hizmet Belgeniz Hk."
- **Mail format:** HTML

500 personele 500 ayrı kişisel e-posta otomatik gider. **Outlook açık olmalı** ve varsayılan e-posta istemcisi olarak ayarlanmalı.

**Uyarı:** Toplu e-postada Outlook bazen güvenlik uyarısı verir. Kurumsal ortamda **SMTP Add-in** kullanmak gerekebilir.

### 3.7 Mail Merge Sorunları

| Sorun | Çözüm |
|-------|-------|
| Sayılar yanlış görünüyor (1.000 yerine 1) | Excel'de hücreyi **Metin** olarak formatla VEYA alan kodunda `\# "#,##0"` ekle |
| Tarih yanlış (4/15/2026 → 15.4.2026 istiyorum) | Alan kodunda `\@ "dd.MM.yyyy"` ekle |
| Türkçe karakter bozuluyor | Excel'i **UTF-8** olarak kaydet veya Excel doğrudan kaynak yap, CSV kullanma |
| 0 ile başlayan sicil no (0123) → 123 oluyor | Excel'de hücreyi metin olarak işaretle, başında **kesme işareti** koy: `'0123` |

---

## BÖLÜM 4: Word VBA Makro

### 4.1 Niye Word'de VBA?

Word'ün makro dili Excel ile **aynı** (VBA). Ama nesne modeli farklı: **Document, Range, Selection, Paragraph, Style**.

Tipik kullanım senaryoları:
- Excel'den veri alıp Word belgesi üretmek
- Belgedeki bütün başlıkları büyük harfe çevirmek
- Şablonu otomatik doldurup PDF'e çıkarıp e-posta eklentisine koymak
- Belgedeki tablodan veri okuyup Excel'e yazmak

### 4.2 Geliştirici Sekmesi ve Editor

**Dosya → Seçenekler → Şeridi Özelleştir → Geliştirici** açık olsun.

**Alt+F11** ile VBA Editör açılır. **Insert → Module** ile yeni modül.

### 4.3 Word Nesne Modeli — Temel

```vba
' Aktif belge
ActiveDocument
ActiveDocument.Paragraphs.Count
ActiveDocument.Sections.Count

' Belgenin tüm metni
ActiveDocument.Range.Text

' Belirli paragraf
ActiveDocument.Paragraphs(1).Range.Text

' Seçili alan
Selection.Text
Selection.Font.Bold = True

' Yeni belge oluştur
Dim yeni As Document
Set yeni = Documents.Add

' Şablondan yeni belge
Set yeni = Documents.Add("C:\Sablonlar\YaziSablonu.dotx")
```

### 4.4 Bulma ve Değiştirme (VBA ile)

Manuel "Bul ve Değiştir" diyaloğu ile aynı, ama **toplu** ve **koşullu** yapılabilir:

```vba
Sub ToplupDegistir()
    With ActiveDocument.Content.Find
        .ClearFormatting
        .Replacement.ClearFormatting
        .Text = "[KURUM]"
        .Replacement.Text = "Genel Müdürlük"
        .Forward = True
        .Wrap = wdFindContinue
        .Execute Replace:=wdReplaceAll
    End With
End Sub
```

**Düzenli ifade (RegEx) ile:**

```vba
.MatchWildcards = True
.Text = "([0-9]{4})\.([0-9]{2})\.([0-9]{2})"   ' YYYY.MM.DD tarih
.Replacement.Text = "\3.\2.\1"                  ' DD.MM.YYYY'e çevir
```

### 4.5 Stil Uygulama — Otomatik

Belgedeki tüm "BÜYÜK HARFLE BAŞLAYAN" satırları "Başlık 1" yap:

```vba
Sub OtomatikBaslik()
    Dim p As Paragraph
    For Each p In ActiveDocument.Paragraphs
        Dim s As String
        s = Trim(p.Range.Text)
        ' Sondaki paragraf işaretini at
        If Right(s, 1) = vbCr Then s = Left(s, Len(s) - 1)
        
        ' Tamamı büyük harfli, kısa ve sayıyla başlamayan paragraflar
        If s = UCase(s) And Len(s) > 0 And Len(s) < 80 And Not IsNumeric(Left(s, 1)) Then
            p.Style = ActiveDocument.Styles("Başlık 1")
        End If
    Next p
End Sub
```

### 4.6 Excel Verisinden Word Belgesi — Hayat Kurtarıcı

EBYS'de en sık ihtiyaç: Excel'de personel listen var, her birine kişisel bir belge üret.

```vba
Sub PersonelBelgeleriUret()
    On Error GoTo HataYakala
    
    Application.ScreenUpdating = False
    
    ' Excel uygulamasını başlat (Late Binding)
    Dim xlApp As Object, xlKitap As Object, xlSayfa As Object
    Set xlApp = CreateObject("Excel.Application")
    Set xlKitap = xlApp.Workbooks.Open("C:\Veriler\Personel.xlsx")
    Set xlSayfa = xlKitap.Worksheets("Liste")
    
    ' Son satır
    Dim sonSatir As Long
    sonSatir = xlSayfa.Cells(xlSayfa.Rows.Count, 1).End(-4162).Row   ' xlUp
    
    ' Çıktı klasörü
    Dim cikti As String
    cikti = "C:\Cikti\HizmetBelgeleri\"
    If Dir(cikti, vbDirectory) = "" Then MkDir cikti
    
    ' Şablon
    Dim sablonYolu As String
    sablonYolu = "C:\Sablonlar\HizmetBelgesi.dotx"
    
    Dim i As Long
    For i = 2 To sonSatir
        Dim tckn As String, ad As String, soyad As String
        Dim unvan As String, birim As String, sicil As String
        
        tckn = CStr(xlSayfa.Cells(i, 1).Value)
        ad = CStr(xlSayfa.Cells(i, 2).Value)
        soyad = CStr(xlSayfa.Cells(i, 3).Value)
        unvan = CStr(xlSayfa.Cells(i, 4).Value)
        birim = CStr(xlSayfa.Cells(i, 5).Value)
        sicil = CStr(xlSayfa.Cells(i, 6).Value)
        
        ' Şablondan yeni belge
        Dim doc As Document
        Set doc = Documents.Add(sablonYolu)
        
        ' Yer tutucuları doldur
        Replace_All doc, "[AD_SOYAD]", ad & " " & soyad
        Replace_All doc, "[TCKN]", tckn
        Replace_All doc, "[UNVAN]", unvan
        Replace_All doc, "[BIRIM]", birim
        Replace_All doc, "[SICIL]", sicil
        Replace_All doc, "[TARIH]", Format(Date, "dd.MM.yyyy")
        
        ' Kaydet
        Dim dosyaAdi As String
        dosyaAdi = cikti & sicil & "_" & ad & "_" & soyad & ".docx"
        doc.SaveAs2 dosyaAdi
        doc.Close False
    Next i
    
    xlKitap.Close False
    xlApp.Quit
    Set xlApp = Nothing
    
TemizCikis:
    Application.ScreenUpdating = True
    MsgBox (sonSatir - 1) & " belge oluşturuldu." & vbCrLf & "Konum: " & cikti, vbInformation
    Exit Sub

HataYakala:
    MsgBox "Hata: " & Err.Description, vbCritical
    Resume TemizCikis
End Sub

' Yardımcı: Belgede toplu değiştirme
Private Sub Replace_All(doc As Document, eski As String, yeni As String)
    With doc.Content.Find
        .ClearFormatting
        .Replacement.ClearFormatting
        .Text = eski
        .Replacement.Text = yeni
        .Forward = True
        .Wrap = wdFindContinue
        .MatchCase = True
        .Execute Replace:=wdReplaceAll
    End With
End Sub
```

**Bu makro 500 kişilik listeyi 2-3 dakikada 500 ayrı .docx olarak diske yazar.**

### 4.7 PDF Çıkarma — Otomatik

```vba
doc.ExportAsFixedFormat _
    OutputFileName:=cikti & sicil & "_" & ad & "_" & soyad & ".pdf", _
    ExportFormat:=wdExportFormatPDF, _
    OptimizeFor:=wdExportOptimizeForPrint, _
    Range:=wdExportAllDocument, _
    Item:=wdExportDocumentContent, _
    IncludeDocProps:=True, _
    CreateBookmarks:=wdExportCreateHeadingBookmarks
```

Hem .docx hem PDF çıkmasını istersen makroya bu satırı ekle.

### 4.8 Tablo Okuma — Word İçinden Excel'e

Word belgesindeki bir tablodan veri okuyup Excel'e aktarma:

```vba
Sub WordTablosunuExceleAt()
    Dim tbl As Table
    Set tbl = ActiveDocument.Tables(1)
    
    Dim xlApp As Object, xlKitap As Object, xlSayfa As Object
    Set xlApp = CreateObject("Excel.Application")
    Set xlKitap = xlApp.Workbooks.Add
    Set xlSayfa = xlKitap.Worksheets(1)
    xlApp.Visible = True
    
    Dim i As Long, j As Long
    For i = 1 To tbl.Rows.Count
        For j = 1 To tbl.Columns.Count
            ' Word tablo hücresi sonunda Chr(13)+Chr(7) var, temizle
            Dim hucre As String
            hucre = tbl.Cell(i, j).Range.Text
            hucre = Replace(hucre, Chr(13), "")
            hucre = Replace(hucre, Chr(7), "")
            xlSayfa.Cells(i, j).Value = hucre
        Next j
    Next i
End Sub
```

---

## BÖLÜM 5: Building Blocks ve Quick Parts

### 5.1 Nedir?

**Building Block** = Word'ün hafızasında tuttuğu **hazır metin/şekil parçası**. Aynı paragrafı her belgede yeniden yazma — bir kez kaydet, her belgede tek tıkla ekle.

**Quick Parts**, Building Block'ların erişim noktasıdır (Ekle → Hızlı Parçalar).

### 5.2 Building Block Oluşturma

1. Belgede tekrar kullanılacak bloğu seç (paragraf, tablo, üstbilgi, ne olursa).
2. **Alt+F3** veya **Ekle → Hızlı Parçalar → Seçimi Hızlı Parçalar Galerisine Kaydet**.
3. Dialog açılır:
   - **Name:** Erişim için kullanılacak ad
   - **Gallery:** Quick Parts (çoğunlukla)
   - **Category:** Kendi kategorin (örn. "EBYS Sonuç Cümleleri")
   - **Save in:** Building Blocks.dotx (genel) veya kendi şablonun
4. Kaydet.

### 5.3 Eklenme

Belgenin istediğin yerinde:
- Adın ilk birkaç harfini yaz, **F3** bas → Building Block ekleniyor
- Veya **Ekle → Hızlı Parçalar** menüsünden seç

### 5.4 EBYS İçin İdeal Kullanım

Bir kurumun standart sonuç ifadelerini kaydet:

| Kısa Ad | İçerik |
|---------|--------|
| `arzederim` | "Bilgilerinize arz ederim." |
| `arzrica` | "Gereğini arz ve rica ederim." |
| `gerekrica` | "Gereğinin yapılmasını rica ederim." |
| `bilgirica` | "Bilgilerinizi rica ederim." |
| `imzablok` | İmza bloğu (4 satırlı, hazır) |

Memur "arzederim" yazıp F3 basıyor — tam ifade geliyor. Onlarca cümleyi ezberlemekten kurtuluyor, tutarlılık sağlanıyor.

### 5.5 Building Block Galerisi Content Control İçinde

Yukarıda Bölüm 1.3'te bahsedilen **Building Block Gallery Content Control** = Şablonda kullanıcıya "sonuç ifadelerinden birini seç" dropdown'ı.

1. Building Block'larını ortak bir **Category** altında kaydet (örn. "Sonuç Cümleleri").
2. Şablonda kullanıcının seçeceği yere **Geliştirici → Building Block Gallery Content Control**.
3. Kontrolün **Properties → Category** kısmından "Sonuç Cümleleri" seç.
4. Kullanıcı belgede tıklayınca dropdown açılır, kayıtlı ifadelerden birini seçer.

### 5.6 AutoText — Building Block'un Özel Hâli

**AutoText** = belirli kelimeyi yazınca otomatik tamamlanan kısayol. Şu farkla:

- Building Block: F3 ile tetiklenir
- AutoText: Yazarken Word otomatik öneri çıkarır (eğer Otomatik Düzeltme etkinse)

Kullanıma açmak: **Dosya → Seçenekler → Yazım Denetleme → Otomatik Düzeltme Seçenekleri → AutoCorrect**. AutoText burada değil — Quick Parts altında AutoText alt galerisi bulunur.

---

## BÖLÜM 6: Şablon (.dotx ve .dotm)

### 6.1 .dotx vs .dotm

| Uzantı | İçerir | Kullanım |
|--------|--------|----------|
| **.dotx** | Sadece içerik + biçim | Standart şablon, makrosuz |
| **.dotm** | İçerik + biçim + **VBA makro** | Otomasyon eklenmiş şablon |

### 6.2 Şablon Oluşturma — Profesyonel

**Adım 1:** Boş belge aç. Tüm yapıyı kur:
- Stilleri tasarla (Başlık 1, 2, 3; Gövde; Alıntı; ...)
- Üstbilgi/altbilgi yerleştir
- Logo, antet ekle
- Sayfa numarası ekle
- Bölüm sonları koy
- Content Control'leri yerleştir (Bölüm 1)
- Building Block'ları kaydet (Bölüm 5)
- Alan kodları ekle (Bölüm 2)

**Adım 2:** Tüm yer tutucu metinleri ekle:
- "[Tarih buraya - tıklayıp seçin]"
- "[İlgili kurum adı]"
- "[Konu yazısı]"

**Adım 3: Dosya → Farklı Kaydet → Tür: Word Şablonu (.dotx)** veya **Makro Etkin Şablon (.dotm)**.

**Varsayılan kayıt yeri:** `C:\Users\[kullanici]\Documents\Custom Office Templates\`

**Adım 4:** Word'de **Dosya → Yeni** dediğinde "Kişisel" sekmesinde şablonun görünür. Tıklayan **kopyasını alır**, orijinal şablon değişmez.

### 6.3 Tüm Yeni Belgeler İçin Varsayılan: Normal.dotm

Word açıldığında varsayılan boş belge **Normal.dotm** şablonundan gelir. Tüm Word açılışlarında değişmesini istediğin şeyleri buraya koy:
- Varsayılan font
- Varsayılan stil
- Belge geneline ait makrolar

**Yolu:** `%AppData%\Microsoft\Templates\Normal.dotm`

**Uyarı:** Bu dosyayı doğrudan düzenleme — Word kapanırken otomatik kaydeder, çakışır. Word açık değilken yedek aldıktan sonra düzenle.

### 6.4 Şablonu Kilitleme

Şablonu kullanıcılar açtığında **belgenin yapısını değiştirememeli**, sadece Content Control'leri doldurmalı:

**Geliştirici → Restrict Editing → "Allow only this type of editing" → Filling in forms → Yes, Start Enforcing Protection**.

Parola koy (kullanıcının korumayı kaldırmasını engeller).

---

## BÖLÜM 7: Kurumsal Dağıtım

### 7.1 Şablonu 30 Kişiye Dağıtmak

**Yöntem 1 — Ortak Klasör:**

1. Şablonu ortak sunucuya koy: `\\sunucu\sablonlar\EBYS_Sablonlari\`
2. Her kullanıcı **Dosya → Seçenekler → Gelişmiş → Dosya Konumları → Çalışma Grubu Şablonları** alanına bu yolu yaz.
3. Şablon güncellendiğinde herkes etkilenir.

**Yöntem 2 — GPO ile Dağıtım:**

Sistem yöneticisi tarafından **Group Policy** ile her kullanıcının Templates klasörüne şablon kopyalanır. Logon scripti her açılışta günceller.

**Yöntem 3 — Manuel Kurulum Paketi:**

`.dotx` dosyasını, bir batch dosyası ile birlikte zip yaparsın:

```batch
@echo off
copy /Y "EBYS_UstYazi.dotx" "%USERPROFILE%\Documents\Custom Office Templates\"
echo Sablon kuruldu.
pause
```

Memur zip'i açar, batch'i çalıştırır, şablon hazır.

### 7.2 Şablonun Güncellenmesi — Sürüm Yönetimi

Şablonda **sürüm numarası** tut. Footer'a alan kodu ile yerleştir:

```
Sürüm: { DOCPROPERTY "Surum" }
```

Word'ün Dosya → Bilgi → Gelişmiş Özellikler → Özel sekmesinde "Surum" özelliği tanımla, değerini ver: "2026.1.0".

Kullanıcı belgeye baktığında üretilen şablon sürümünü görür. Eski sürümlü belge gelirse "Şu an 2026.2.0 var, bunu güncelle" denebilir.

### 7.3 Add-in Olarak Dağıtım (.dotm)

Makrolu şablon = sadece o şablondan açılan belgeler makroyu kullanabilir. **Add-in** yaparsan Word her açıldığında makro aktif olur — kullanıcı herhangi bir belgede özellikleri kullanabilir.

**Adımlar:**

1. .dotm dosyasını şu klasöre koy: `%AppData%\Microsoft\Word\STARTUP\`
2. Word açılışında **otomatik yüklenir**, makrolar kullanılabilir hale gelir.
3. **Geliştirici → Eklentiler → Şablonlar ve Eklentiler** ile yüklü add-in'leri görebilirsin.

### 7.4 Şerit Özelleştirme — Kurum Sekmesi

Excel'deki gibi Word'de de **Custom UI XML** ile kurumun kendi şerit sekmesi yapılır.

`customUI14.xml` dosyası (Office Custom UI Editor ile):

```xml
<customUI xmlns="http://schemas.microsoft.com/office/2009/07/customui">
  <ribbon>
    <tabs>
      <tab id="EBYSSekmesi" label="EBYS Araçları">
        <group id="grpSablon" label="Şablonlar">
          <button id="btnYeniUstYazi"
                  label="Yeni Üst Yazı"
                  size="large"
                  imageMso="FileNew"
                  onAction="cmdYeniUstYazi"/>
          <button id="btnYeniCevapYazi"
                  label="Cevap Yazısı"
                  size="large"
                  imageMso="ReviewReplyToReviewer"
                  onAction="cmdYeniCevapYazi"/>
        </group>
        <group id="grpAraclar" label="Araçlar">
          <button id="btnTopluUret"
                  label="Toplu Belge Üret"
                  imageMso="MailMergeStartMailMerge"
                  onAction="cmdTopluUret"/>
          <button id="btnPDFCikar"
                  label="PDF Çıkar"
                  imageMso="ExportPdf"
                  onAction="cmdPDFCikar"/>
        </group>
      </tab>
    </tabs>
  </ribbon>
</customUI>
```

VBA tarafında her `onAction` için bir Sub yazılır:

```vba
Sub cmdYeniUstYazi(control As IRibbonControl)
    Documents.Add Template:="C:\Sablonlar\UstYazi.dotx"
End Sub

Sub cmdYeniCevapYazi(control As IRibbonControl)
    Documents.Add Template:="C:\Sablonlar\CevapYazisi.dotx"
End Sub

Sub cmdTopluUret(control As IRibbonControl)
    UserForm_TopluBelgeUretici.Show
End Sub
```

Bu add-in'i `STARTUP` klasörüne koyarsan kurumdaki herkes Word'ü açtığında "EBYS Araçları" sekmesini görür.

---

## BÖLÜM 8: Modüler Mimari

### 8.1 Modül Ayrımı (Word VBA Projesi)

| Modül | İçeriği |
|-------|---------|
| `mod_Ana` | Şerit düğmelerinin Sub'ları (giriş noktası) |
| `mod_Belge` | Belge oluşturma, kaydetme, PDF çıkarma |
| `mod_Replace` | Find/Replace yardımcıları |
| `mod_TabloIslem` | Word tablosu okuma/yazma |
| `mod_ExcelKopru` | Excel ile veri alışverişi |
| `mod_Ayarlar` | Sabit yollar, sürüm bilgisi |
| `mod_Log` | Log yazma |
| `cls_BelgeUreticisi` | Class Module — belge üretim mantığı |

### 8.2 Hata Yönetimi Şablonu

```vba
Sub AnaIslem()
    On Error GoTo HataYakala
    
    Application.ScreenUpdating = False
    Application.DisplayAlerts = False
    
    ' --- Asıl iş ---
    BelgeUret
    Loga "Belge üretildi"
    
TemizCikis:
    Application.ScreenUpdating = True
    Application.DisplayAlerts = True
    Exit Sub

HataYakala:
    Loga "HATA: " & Err.Number & " - " & Err.Description
    MsgBox "Hata: " & Err.Description, vbCritical
    Resume TemizCikis
End Sub
```

### 8.3 Log Modülü

```vba
' --- mod_Log ---
Public Sub Loga(mesaj As String)
    On Error Resume Next
    
    Dim klasor As String
    klasor = Environ("APPDATA") & "\WordEBYSAraclari"
    If Dir(klasor, vbDirectory) = "" Then MkDir klasor
    
    Dim dosya As String
    dosya = klasor & "\log.txt"
    
    Dim no As Integer
    no = FreeFile
    Open dosya For Append As #no
    Print #no, Format(Now, "yyyy-mm-dd hh:nn:ss") & vbTab & mesaj
    Close #no
End Sub
```

### 8.4 Sabit Modülü

```vba
' --- mod_Ayarlar ---
Public Const VERSIYON As String = "2026.1.0"
Public Const SABLON_KLASORU As String = "\\sunucu\sablonlar\EBYS\"
Public Const CIKTI_KLASORU As String = "C:\EBYS_Cikti\"

Public Const SABLON_UST_YAZI As String = "UstYazi.dotx"
Public Const SABLON_CEVAP_YAZISI As String = "CevapYazisi.dotx"
Public Const SABLON_HIZMET_BELGESI As String = "HizmetBelgesi.dotx"
```

---

## BÖLÜM 9: XML Mapping (İleri)

### 9.1 Hedef

Bir XML dosyasından Word belgesindeki Content Control'leri **otomatik doldurmak**. Sistem entegrasyonu için kullanılır (EBYS'nin XML çıktısı → otomatik Word belgesi).

### 9.2 Custom XML Parts

Word belgeleri (.docx) zip dosyalarıdır. İçinde özel XML parçaları (Custom XML Parts) tutulabilir.

**Şema:** XML, Content Control etiketlerine bağlanır. XML değiştiğinde Content Control değişir, tersi de doğru.

### 9.3 Pratik Yaklaşım — VBA ile XML Bağlama

```vba
Sub XMLBagla()
    ' XML'i belgeye ekle
    ActiveDocument.CustomXMLParts.Add _
        XML:="<personel><ad>Ahmet</ad><soyad>Yılmaz</soyad><sicil>1234</sicil></personel>"
    
    ' Content Control'ü XML'e bağla
    Dim cc As ContentControl
    For Each cc In ActiveDocument.ContentControls
        Select Case cc.Tag
            Case "ad"
                cc.XMLMapping.SetMapping "/personel/ad", _
                    "", ActiveDocument.CustomXMLParts(ActiveDocument.CustomXMLParts.Count)
            Case "soyad"
                cc.XMLMapping.SetMapping "/personel/soyad", _
                    "", ActiveDocument.CustomXMLParts(ActiveDocument.CustomXMLParts.Count)
        End Select
    Next cc
End Sub
```

XML'i değiştirdiğinde belgedeki ilgili Content Control de değişir. Sistem entegrasyonu için güçlü.

### 9.4 Word Belgesini Manuel Açıp İçindeki XML'i Görme

1. .docx uzantısını **.zip** yap (yedek al önce!)
2. ZIP'i aç → `word/` klasörü altında `document.xml`, `customXml/item1.xml` vs.
3. XML'leri görür, düzenler, geri zip yaparsın → .docx olarak çalışır

**Bu yaklaşım Python ile programatik belge üretiminin temelidir** (python-docx kütüphanesi bu yapıyı kullanır).

---

## Kontrol Listesi — Üretim Hazır Şablon

Bir şablonu kuruma dağıtmadan önce:

- [ ] Tüm başlıklar **stil** kullanıyor mu (Başlık 1, 2, 3)?
- [ ] Stil tanımları **kuruma uygun** mu (font, boyut, boşluk)?
- [ ] Üstbilgi/altbilgi sayfa numarası ve kurum logosu içeriyor mu?
- [ ] **Content Control**'ler doğru tipte ve etiketli mi (Tag dolu)?
- [ ] Şablon **kilitli** mi (Restrict Editing açık)?
- [ ] **Building Block** kütüphanesi dolu mu (sık kullanılan ifadeler)?
- [ ] **Document Properties** (Author, Title, BirimAdi) tanımlı mı?
- [ ] **Versiyon** bilgisi belgenin görünür bir yerinde mi?
- [ ] Şablon **.dotx** veya **.dotm** olarak kaydedildi mi (.docx değil)?
- [ ] Test verisiyle **3 farklı belge** üretip kontrol ettin mi?
- [ ] **Yazım denetimi** çalıştı mı (Türkçe ayarlı mı)?
- [ ] **Mail merge** denendi mi (filtreleme ve koşullu metin dahil)?
- [ ] Makrolu şablon ise **VBA Project parolası** ekli mi?
- [ ] Şablon dosyasının **yedeği** alındı mı?

---

## Sık Yapılan Hatalar

| Hata | Belirti | Çözüm |
|------|---------|-------|
| Manuel biçimlendirme | Belge dağınık, içindekiler bozuk | Tümünü "Normal" stiline döndür, baştan stil ata |
| Boşluklarla hizalama | Yeni yazıcıda kayar | Tab, paragraf girintisi, tablo kullan |
| Alan kodları güncellenmemiş | PDF'te yanlış sayfa numarası | Ctrl+A, F9 (tüm alanları güncelle) |
| Content Control silinmiş | Şablon işlevsiz | "Content control cannot be deleted" işaretle |
| Mail merge tarihinde format | "4/15/2026" istemiyoruz | Alan koduna `\@ "dd.MM.yyyy"` ekle |
| Mail merge sayı formatı | "1000" yerine "1.000,00" | Alan koduna `\# "#,##0.00"` ekle |
| Şablon ortak klasörden açılırken yavaş | Ağ gecikmesi | Kullanıcının yereline kopyalanan kopya kullan |
| .dotm makro çalışmıyor | Makro etkin değil | Trust Center → Trusted Locations'a klasörü ekle |
| Türkçe karakter bozulması | Mail merge'de ş, ğ, ı bozuk | Excel dosyasını UTF-8 kaydet, CSV kullanma |
| Building Block bulunamıyor | F3 ile gelmiyor | Building Block'u doğru şablona kaydet (Normal.dotm değil, ortak şablon) |

---

## Hangi Aracı Ne Zaman Kullan?

| Durum | Tavsiye |
|-------|---------|
| Tek seferlik yazı | Doğrudan Word'de yaz |
| Sık kullanılan yapı | Şablon (.dotx) |
| 5 farklı kullanıcı aynı şablon | Content Control'lü kilitli şablon |
| Şablon + otomatik aksiyonlar | .dotm + VBA |
| 100 kişiye kişisel mektup | Mail Merge |
| Excel verisinden 500 belge | VBA + Documents.Add + Replace |
| Kurum geneli (50+ kullanıcı) | Add-in (.dotm) + Ribbon + Ortak şablon klasörü |
| Sistem entegrasyonu (EBYS XML) | Custom XML Parts + XMLMapping |
| Tekrarlanan cümleler | Building Block / AutoText |

---

## Son Söz

Word'ün gerçek gücü "yazmak" değil, "yazılmasını otomatikleştirmek"tir.

Memurun her seferinde aynı klavye hareketini yapması zaman israfıdır, hata kaynağıdır. **Doğru şablon + doğru makro = sıfır hata + saniyelerle üretim**.

Bu skill bir kurumun belge üretim hattını **fabrika seviyesine** çıkarır. Memur şablonu açar, sadece dolması gereken yerleri doldurur, çıktıyı alır. Geri kalan her şey otomatik.
