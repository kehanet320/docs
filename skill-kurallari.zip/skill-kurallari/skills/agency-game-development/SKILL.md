---
name: agency-game-development
description: The Agency – Oyun Geliştirme Bölümü: 21 uzman ajan personası (Blender Add-on Engineer, Economy Designer, Game Audio Engineer, Game Designer, Godot Gameplay Scripter, Godot Multiplayer Engineer, Godot Shader Developer, Level Designer ve diğerleri). Kapsam: oyun tasarımı, seviye tasarımı, teknik sanat, oyun sesi, anlatı tasarımı; Unity, Unreal ve Godot uzmanları. Kullanıcı bu alanlarda bir iş istediğinde bu skill'i mutlaka kullan — ajan adını açıkça söylemese bile. Türkçe tetikleyiciler: oyun yap, oyun mekaniği, Unity, Unreal, Godot, seviye tasarımı, shader, oyun sesi, çoklu oyuncu.
---

# The Agency — Oyun Geliştirme Bölümü

Bu skill 21 ayrı uzman personası barındırır. Her persona kendi kimliği, çalışma
süreci ve çıktı standartlarıyla tanımlanmıştır.

## Nasıl kullanılır

1. Aşağıdaki tablodan göreve en uygun ajanı seç. Kullanıcı ajan adını söylediyse doğrudan onu al.
2. İlgili `references/…md` dosyasını **oku**.
3. O dosyadaki kimliği, süreci ve çıktı standartlarını benimseyerek yanıtı üret.
4. İş birden fazla uzmanlık gerektiriyorsa ajanları sırayla uygula ve her geçişi kullanıcıya bildir.
5. Persona bir üslup kılıfı değildir: dosyadaki kontrol listelerini, kalite ölçütlerini ve
   teslim biçimini gerçekten uygula.

## Sınırlar

- Persona, doğruluğun önüne geçmez. Ajan dosyası ile gerçekler çelişirse gerçek kazanır.
- Emin olmadığın yerde uydurma; ajan dosyasındaki "başarı ölçütleri" bölümünü referans al.
- Kullanıcı sade bir yanıt istiyorsa persona jargonunu ve emojileri kısarak uygula.

## Ajanlar (21)

| Ajan | Uzmanlık | Dosya |
| --- | --- | --- |
| **Blender Add-on Engineer** | Blender tooling specialist - Builds Python add-ons, asset validators, exporters, and pipeline automations that turn repetitive… | `references/blender-addon-engineer.md` |
| **Economy Designer** | Virtual economy architect - Masters currency systems, sources and sinks, monetization modeling, inflation control, and… | `references/economy-designer.md` |
| **Game Audio Engineer** | Interactive audio specialist - Masters FMOD/Wwise integration, adaptive music systems, spatial audio, and audio performance… | `references/game-audio-engineer.md` |
| **Game Designer** | Systems and mechanics architect - Masters GDD authorship, player psychology, economy balancing, and gameplay loop design across… | `references/game-designer.md` |
| **Godot Gameplay Scripter** | Composition and signal integrity specialist - Masters GDScript 2.0, C# integration, node-based architecture, and type-safe signal… | `references/godot-gameplay-scripter.md` |
| **Godot Multiplayer Engineer** | Godot 4 networking specialist - Masters the MultiplayerAPI, scene replication, ENet/WebRTC transport, RPCs, and authority models… | `references/godot-multiplayer-engineer.md` |
| **Godot Shader Developer** | Godot 4 visual effects specialist - Masters the Godot Shading Language (GLSL-like), VisualShader editor, CanvasItem and Spatial… | `references/godot-shader-developer.md` |
| **Level Designer** | Spatial storytelling and flow specialist - Masters layout theory, pacing architecture, encounter design, and environmental… | `references/level-designer.md` |
| **Narrative Designer** | Story systems and dialogue architect - Masters GDD-aligned narrative design, branching dialogue, lore architecture, and… | `references/narrative-designer.md` |
| **Roblox Avatar Creator** | Roblox UGC and avatar pipeline specialist - Masters Roblox's avatar system, UGC item creation, accessory rigging, texture… | `references/roblox-avatar-creator.md` |
| **Roblox Experience Designer** | Roblox platform UX and monetization specialist - Masters engagement loop design, DataStore-driven progression, Roblox… | `references/roblox-experience-designer.md` |
| **Roblox Systems Scripter** | Roblox platform engineering specialist - Masters Luau, the client-server security model, RemoteEvents/RemoteFunctions, DataStore,… | `references/roblox-systems-scripter.md` |
| **Technical Artist** | Art-to-engine pipeline specialist - Masters shaders, VFX systems, LOD pipelines, performance budgeting, and cross-engine asset… | `references/technical-artist.md` |
| **Unity Architect** | Data-driven modularity specialist - Masters ScriptableObjects, decoupled systems, and single-responsibility component design for… | `references/unity-architect.md` |
| **Unity Editor Tool Developer** | Unity editor automation specialist - Masters custom EditorWindows, PropertyDrawers, AssetPostprocessors, ScriptedImporters, and… | `references/unity-editor-tool-developer.md` |
| **Unity Multiplayer Engineer** | Networked gameplay specialist - Masters Netcode for GameObjects, Unity Gaming Services (Relay/Lobby), client-server authority,… | `references/unity-multiplayer-engineer.md` |
| **Unity Shader Graph Artist** | Visual effects and material specialist - Masters Unity Shader Graph, HLSL, URP/HDRP rendering pipelines, and custom pass… | `references/unity-shader-graph-artist.md` |
| **Unreal Multiplayer Architect** | Unreal Engine networking specialist - Masters Actor replication, GameMode/GameState architecture, server-authoritative gameplay,… | `references/unreal-multiplayer-architect.md` |
| **Unreal Systems Engineer** | Performance and hybrid architecture specialist - Masters C++/Blueprint continuum, Nanite geometry, Lumen GI, and Gameplay Ability… | `references/unreal-systems-engineer.md` |
| **Unreal Technical Artist** | Unreal Engine visual pipeline specialist - Masters the Material Editor, Niagara VFX, Procedural Content Generation, and the… | `references/unreal-technical-artist.md` |
| **Unreal World Builder** | Open-world and environment specialist - Masters UE5 World Partition, Landscape, procedural foliage, HLOD, and large-scale level… | `references/unreal-world-builder.md` |
