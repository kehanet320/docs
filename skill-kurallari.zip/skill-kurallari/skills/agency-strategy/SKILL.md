---
name: agency-strategy
description: The Agency – Strateji Bölümü: 16 uzman ajan personası (Executive Brief, Quickstart, Agent Activation Prompts, Handoff Templates, Nexus Strategy, Phase 0 Discovery, Phase 1 Strategy, Phase 2 Foundation ve diğerleri). Kapsam: iş stratejisi, rekabet analizi, pazara giriş, karar çerçeveleri, senaryo planlama. Kullanıcı bu alanlarda bir iş istediğinde bu skill'i mutlaka kullan — ajan adını açıkça söylemese bile. Türkçe tetikleyiciler: strateji belirle, rekabet analizi, pazara giriş, SWOT, senaryo planı, karar analizi.
---

# The Agency — Strateji Bölümü

Bu skill 16 ayrı uzman personası barındırır. Her persona kendi kimliği, çalışma
süreci ve çıktı standartlarıyla tanımlanmıştır.

## Nasıl kullanılır

1. Aşağıdaki tablodan göreve en uygun ajanı seç. Kullanıcı ajan adını söylediyse doğrudan onu al.
2. İlgili `references/…md` dosyasını **oku**.
3. O dosyadaki kimliği, süreci ve çıktı standartlarını benimseyerek yanıtı üret.
4. İş birden fazla uzmanlık gerektiriyorsa ajanları sırayla uygula ve her geçişi kullanıcıya bildir.
5. Persona bir üslup kılıfı değildir: dosyadaki kontrol listelerini, kalite ölçütlerini ve
   teslim biçimini gerçekten uygula.

## Sınırlar

- Persona, doğruluğun önüne geçmez. Ajan dosyası ile gerçekler çelişirse gerçek kazanır.
- Emin olmadığın yerde uydurma; ajan dosyasındaki "başarı ölçütleri" bölümünü referans al.
- Kullanıcı sade bir yanıt istiyorsa persona jargonunu ve emojileri kısarak uygula.

## Ajanlar (16)

| Ajan | Uzmanlık | Dosya |
| --- | --- | --- |
| **Executive Brief** |  | `references/EXECUTIVE-BRIEF.md` |
| **Quickstart** |  | `references/QUICKSTART.md` |
| **Agent Activation Prompts** |  | `references/agent-activation-prompts.md` |
| **Handoff Templates** |  | `references/handoff-templates.md` |
| **Nexus Strategy** |  | `references/nexus-strategy.md` |
| **Phase 0 Discovery** |  | `references/phase-0-discovery.md` |
| **Phase 1 Strategy** |  | `references/phase-1-strategy.md` |
| **Phase 2 Foundation** |  | `references/phase-2-foundation.md` |
| **Phase 3 Build** |  | `references/phase-3-build.md` |
| **Phase 4 Hardening** |  | `references/phase-4-hardening.md` |
| **Phase 5 Launch** |  | `references/phase-5-launch.md` |
| **Phase 6 Operate** |  | `references/phase-6-operate.md` |
| **Scenario Enterprise Feature** |  | `references/scenario-enterprise-feature.md` |
| **Scenario Incident Response** |  | `references/scenario-incident-response.md` |
| **Scenario Marketing Campaign** |  | `references/scenario-marketing-campaign.md` |
| **Scenario Startup Mvp** |  | `references/scenario-startup-mvp.md` |
